# Visual style: data-journalism

Bloomberg / Economist news-infographic — publication-grade information density: multi-column grids, inline micro-charts, data tables, editorial sidebars, source lines. Cool and restrained, read like a financial long-read rather than a keynote. For finance, market reviews, research, annual data reports, data-driven explainers.

---

## 1. Shape & decoration

- Shape language: a dense multi-column grid carrying many small charts and data tables inline; editorial sidebars and pull-stats; hairline dividers; hero numbers; a running source / footnote line. Information density is the look — kept legible by a rigorous grid.
- Composition geometry: the chart as the page's spine — layout wraps the visualization instead of boxing it; a hero number at full column scale; a full-width spanner rule dropping into a stat band; a sidebar cut into the grid; small-multiple strips instead of one boxed chart.
- Decoration: minimal beyond the data — a single accent rule, sparing annotation. Charts and numbers are the visual interest, not ornament.
- Whitespace: tight but structured; the grid earns density without clutter.

## 2. Typography character

- Serif headline / hero-number for authority × a clean sans or monospace with lining figures for numeric precision in tables and chart labels. Small captions and source lines; tight, deliberate hierarchy.

> Families are chosen at confirmation `g`; this style asks for a serif-headline × precise-sans/mono-data *character*. This governs editable native text; decorative-lettering eligibility remains a separate carrier decision.

## 3. Using the deck's colors

- A restrained field — light publication paper or dark graphite both fit (Economist vs Bloomberg-terminal); the deck's accent marks risk / key figures, an optional secondary distinguishes a second series; charts use tints of the same family, never a rainbow.
- Numbers are colored to *mean* (up / down / risk / focus), not to decorate.

> HEX values come from confirmation `e`; this style only governs the restrained-field, meaning-coded-data discipline — it names no colors.

## 4. Texture / elevation

- Flat, publication-grade — when either carries the relationship, favor hairline rules over heavy cards. Flatness governs visual weight, not contour vocabulary; outlined or compound page fields remain compatible. Optional scrim on any image; no glow, no decorative shadow.

## 5. Paired image-rendering

`editorial` — magazine-style infographic imagery sharing the data-publication aesthetic.

## 6. Illustration propensity

**sparse** — charts, sidebars, and evidence lead. Use illustration selectively for orientation, narrative framing, or emphasis without obscuring values or source authority; form and scale follow the page job. An explicit user request wins either way, and `image_usage: none` writes no illustration rows.
