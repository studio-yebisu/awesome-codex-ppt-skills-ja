#!/usr/bin/env python3
"""
PPT Master - Template Structure Metadata

Parse and validate explicit SVG metadata consumed by structured PPTX export.

Usage:
    Imported by svg_to_pptx.pptx_package.builder and svg_quality_checker.py.

Examples:
    parse_template_slides([Path("projects/demo/svg_output/01_cover.svg")])

Dependencies:
    None (only uses standard library)
"""

from __future__ import annotations

import base64
import binascii
import copy
import hashlib
import json
import math
import re
import zipfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any
from xml.etree import ElementTree as ET

from native_payloads import NativePayloadError, hydrate_native_payload_refs
from pptx_to_svg.preset_authoring import (
    authored_preset_encoding,
    validate_authored_preset_group,
)

from ..drawingml.utils import (
    is_picture_effect_carrier,
    parse_inline_style,
    parse_opacity,
    parse_project_geometry_length,
    project_geometry_length_errors,
)
from ..canvas_contract import CanvasContractError, parse_project_viewbox
from ..geometry_properties import (
    GeometryStyleError,
    materialize_inline_geometry_properties,
)
from ..native_objects import (
    NativeMarkerAttributeError,
    native_json_is_authoritative,
    native_replacement_kind,
)


_NON_VISUAL_TAGS = frozenset({"defs", "title", "desc", "metadata", "style"})
_STRUCTURE_ATTRS = frozenset({
    "data-pptx-layer",
    "data-pptx-layout",
    "data-pptx-layout-kind",
    "data-pptx-layout-name",
    "data-pptx-master",
    "data-pptx-master-name",
    "data-pptx-show-inherited-shapes",
    "data-pptx-show-master-shapes",
    "data-pptx-placeholder",
    "data-pptx-binding",
    "data-pptx-carrier",
    "data-pptx-idx",
    "data-pptx-editable",
})
_FLAT_FORBIDDEN_STRUCTURE_ATTRS = frozenset(
    _STRUCTURE_ATTRS - {"data-pptx-editable"}
)
_LAYERS = frozenset({"master", "layout", "slide"})
_PLACEHOLDERS = frozenset({
    "title",
    "subtitle",
    "body",
    "picture",
    "chart",
    "table",
    "object",
    "media",
    "date",
    "footer",
    "slide-number",
})
TEMPLATE_PLACEHOLDER_TYPES = {
    "title": "title",
    "subtitle": "subTitle",
    "body": "body",
    "picture": "pic",
    "chart": "chart",
    "table": "tbl",
    "object": "obj",
    "media": "media",
    "date": "dt",
    "footer": "ftr",
    "slide-number": "sldNum",
}
_TEXT_PLACEHOLDERS = frozenset({
    "title",
    "subtitle",
    "body",
    "date",
    "footer",
    "slide-number",
})
_OBJECT_PLACEHOLDER_TAGS = frozenset({
    "rect",
    "circle",
    "ellipse",
    "line",
    "path",
    "polygon",
    "polyline",
    "text",
    "image",
    "svg",
    "use",
})
_LAYOUT_KEY_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}$")
_MASTER_KEY_RE = _LAYOUT_KEY_RE
# Parse Markdown row syntax before validating each section's key grammar. Keeping
# those concerns separate prevents malformed keys from disappearing silently.
_LOCK_ROW_RE = re.compile(r"^-\s+([^:]+?)\s*:\s*(.*?)\s*$")
_LOCK_PAGE_RE = re.compile(r"^P(\d+)$")
PPTX_STRUCTURE_MODES = frozenset({"structured", "preserve", "flat"})
TEMPLATE_ADHERENCE_MODES = frozenset({"strict", "adaptive"})
TEMPLATE_REUSE_SCOPES = frozenset({"mirror", "layout", "style"})
PLACEHOLDER_BINDING_MODES = frozenset({"carrier", "proxy"})
SOURCE_THEMES_FILENAME = "source_themes.json"
SOURCE_THEMES_SCHEMA = "ppt-master.source-themes.v1"
_DML_NS = "http://schemas.openxmlformats.org/drawingml/2006/main"
_REL_NS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
_TEMPLATE_SKIN_ATTRS = frozenset({
    "baseline-shift",
    "color",
    "fill",
    "fill-opacity",
    "filter",
    "font-family",
    "font-size",
    "font-style",
    "font-weight",
    "letter-spacing",
    "opacity",
    "paint-order",
    "stop-color",
    "stop-opacity",
    "stroke",
    "stroke-dasharray",
    "stroke-dashoffset",
    "stroke-linecap",
    "stroke-linejoin",
    "stroke-miterlimit",
    "stroke-opacity",
    "stroke-width",
    "style",
    "text-decoration",
    "word-spacing",
})
_CSS_RULE_RE = re.compile(r"(?s)([^{}]+)\{([^{}]*)\}")
_CSS_COMMENT_RE = re.compile(r"/\*.*?\*/", re.DOTALL)
_CSS_ID_RE = re.compile(r"#([A-Za-z_][A-Za-z0-9_-]*)")
_CSS_CLASS_RE = re.compile(r"\.([A-Za-z_][A-Za-z0-9_-]*)")
_CSS_ATTR_RE = re.compile(
    r"\[\s*([A-Za-z_:][A-Za-z0-9_.:-]*)"
    r"(?:\s*(?:[~|^$*]?=)\s*(['\"]?)([^\]'\"]+)\2)?\s*\]"
)
_CSS_URL_RE = re.compile(r"url\(\s*(['\"]?)(.*?)\1\s*\)", re.IGNORECASE)
_CSS_TAG_RE = re.compile(r"(?:^|[\s>+~])([A-Za-z_][A-Za-z0-9_-]*|\*)")
NATIVE_STRUCTURE_SCHEMA = "ppt-master.native-structure.v1"
OOXML_UINT32_MAX = (1 << 32) - 1


class TemplateStructureError(RuntimeError):
    """Reject invalid or ambiguous template-structure metadata."""


@dataclass(frozen=True)
class PptxLayoutReference:
    """One spec_lock page-to-PowerPoint-layout assignment."""

    slide_num: int
    layout_key: str
    layout_name: str | None = None
    master_key: str | None = None


@dataclass(frozen=True)
class PptxLayoutDefinition:
    """One reusable PowerPoint Layout declared by a structured project lock."""

    layout_key: str
    master_key: str
    layout_name: str
    prototype_slide_num: int | None = None
    prototype_svg_path: Path | None = None


@dataclass(frozen=True)
class PptxMasterReference:
    """One named Master declared by the structured project lock."""

    master_key: str
    master_name: str


@dataclass(frozen=True)
class PptxPrototypeReference:
    """One spec_lock page-to-template-SVG prototype declaration."""

    slide_num: int
    template_basename: str
    svg_path: Path
    replication_mode: str | None = None


@dataclass(frozen=True)
class PptxStructureLock:
    """Optional project-level PPTX structure export policy."""

    mode: str
    template_reuse_scope: str | None = None
    template_adherence: str | None = None
    masters: tuple[PptxMasterReference, ...] = ()
    layout_definitions: tuple[PptxLayoutDefinition, ...] = ()
    layouts: tuple[PptxLayoutReference, ...] = ()
    prototypes: tuple[PptxPrototypeReference, ...] = ()
    source_template: Path | None = None
    native_structure: Path | None = None


@dataclass(frozen=True)
class NativePlaceholderSpec:
    """One placeholder exposed by a preserved source layout."""

    semantic_role: str
    placeholder_type: str
    idx: int | None
    geometry: tuple[float, float, float, float] | None = None

    @property
    def effective_idx(self) -> int:
        """Return the OOXML index after applying the omitted-value default."""
        return self.idx if self.idx is not None else 0


@dataclass(frozen=True)
class NativeLayoutSpec:
    """One named layout retained from the source PPTX package."""

    key: str
    name: str
    package_part: str
    master_key: str
    placeholders: tuple[NativePlaceholderSpec, ...] = ()


@dataclass(frozen=True)
class NativeSlideSpec:
    """One source slide retained by index for exact round-trip passthrough."""

    index: int
    package_part: str
    layout_key: str


@dataclass(frozen=True)
class NativeStructureContract:
    """Validated portable contract for a preserved source PPTX package."""

    source_template: Path
    contract_path: Path
    source_sha256: str
    slide_size_emu: tuple[int, int]
    layouts: tuple[NativeLayoutSpec, ...]
    slides: tuple[NativeSlideSpec, ...]

    def layout(self, key: str) -> NativeLayoutSpec:
        for layout in self.layouts:
            if layout.key == key:
                return layout
        raise TemplateStructureError(
            f"native_structure.json has no layout key {key!r}"
        )

    def slide(self, index: int) -> NativeSlideSpec:
        """Return one source slide contract by presentation-order index."""
        for slide in self.slides:
            if slide.index == index:
                return slide
        raise TemplateStructureError(
            f"native_structure.json has no source slide {index}"
        )


@dataclass(frozen=True)
class TemplateElementSpec:
    """One direct SVG child carrying explicit PPTX structure metadata."""

    element_id: str
    order: int
    tag: str
    layer: str | None = None
    placeholder: str | None = None
    placeholder_bounds: tuple[float, float, float, float] | None = None
    placeholder_idx: int | None = None
    placeholder_binding: str | None = None
    placeholder_carrier_tag: str | None = None
    is_background: bool = False

    def contract_signature(self) -> tuple[object, ...]:
        """Return metadata that must agree across slides sharing a structure."""
        return (
            self.element_id,
            self.tag,
            self.layer,
            self.placeholder,
            self.placeholder_bounds,
            self.placeholder_idx,
            self.placeholder_binding,
            self.placeholder_carrier_tag,
            self.is_background,
        )


@dataclass(frozen=True)
class TemplateSlideSpec:
    """Explicit structure contract parsed from one SVG slide."""

    slide_num: int
    svg_path: Path
    master_key: str
    master_name: str
    layout_key: str
    layout_name: str
    layout_show_master_shapes: bool
    slide_show_inherited_shapes: bool
    elements: tuple[TemplateElementSpec, ...]

    @property
    def master_elements(self) -> tuple[TemplateElementSpec, ...]:
        return tuple(item for item in self.elements if item.layer == "master")

    @property
    def layout_elements(self) -> tuple[TemplateElementSpec, ...]:
        return tuple(item for item in self.elements if item.layer == "layout")

    @property
    def placeholders(self) -> tuple[TemplateElementSpec, ...]:
        return tuple(item for item in self.elements if item.placeholder)

    @property
    def layout_contract(self) -> tuple[tuple[object, ...], ...]:
        return tuple(
            item.contract_signature()
            for item in self.elements
            if item.layer == "layout" or item.placeholder
        )


def is_proxy_placeholder(item: TemplateElementSpec) -> bool:
    """Return whether a visible composite slot uses an invisible binding proxy."""
    return item.placeholder_binding == "proxy"


@dataclass(frozen=True)
class TemplatePlaceholderBinding:
    """Resolved PowerPoint identity for one template placeholder."""

    element: TemplateElementSpec
    placeholder_type: str
    assigned_idx: int | None

    @property
    def effective_idx(self) -> int:
        """Return the OOXML idx value after applying its default of zero."""
        return self.assigned_idx if self.assigned_idx is not None else 0


def template_placeholder_bindings(
    spec: TemplateSlideSpec,
) -> tuple[TemplatePlaceholderBinding, ...]:
    """Assign deterministic, collision-free PowerPoint placeholder identities."""
    next_idx = 1
    used_indices: dict[int, str] = {}
    bindings: list[TemplatePlaceholderBinding] = []
    for item in spec.placeholders:
        placeholder_type = TEMPLATE_PLACEHOLDER_TYPES.get(item.placeholder or "")
        if placeholder_type is None:
            raise TemplateStructureError(
                f"{spec.svg_path.name}: unsupported placeholder type "
                f"{item.placeholder!r}"
            )
        if item.placeholder == "title" and item.placeholder_idx is None:
            assigned_idx = None
        else:
            assigned_idx = (
                item.placeholder_idx
                if item.placeholder_idx is not None
                else next_idx
            )
        effective_idx = assigned_idx if assigned_idx is not None else 0
        if effective_idx > OOXML_UINT32_MAX:
            raise TemplateStructureError(
                f"{spec.svg_path.name}: layout {spec.layout_key!r} placeholder "
                f"{item.element_id!r} idx exceeds the OOXML UInt32 maximum "
                f"{OOXML_UINT32_MAX}"
            )
        previous = used_indices.get(effective_idx)
        if previous is not None:
            raise TemplateStructureError(
                f"{spec.svg_path.name}: layout {spec.layout_key!r} gives "
                f"placeholders {previous!r} and {item.element_id!r} the same "
                f"effective idx {effective_idx}; omitted idx defaults to 0 in OOXML"
            )
        used_indices[effective_idx] = item.element_id
        if assigned_idx is not None:
            next_idx = max(next_idx, assigned_idx + 1)
        bindings.append(TemplatePlaceholderBinding(
            element=item,
            placeholder_type=placeholder_type,
            assigned_idx=assigned_idx,
        ))
    return tuple(bindings)


def _local_tag(elem: ET.Element) -> str:
    return elem.tag.rsplit("}", 1)[-1] if isinstance(elem.tag, str) else ""


def _parse_svg_root(svg_path: Path) -> ET.Element:
    """Parse one SVG and hydrate compact native metadata in memory."""
    root = ET.parse(svg_path).getroot()
    hydrate_native_payload_refs(root, svg_path)
    return root


def _is_authored_preset_atom(elem: ET.Element) -> bool:
    """Return whether one group is a valid compact authored-shape atom."""
    return (
        authored_preset_encoding(elem) == "compact"
        and not validate_authored_preset_group(elem)
    )


def _svg_canvas(root: ET.Element) -> tuple[float, float, float, float]:
    viewbox = parse_project_viewbox(root.get("viewBox"))
    return 0.0, 0.0, float(viewbox.width), float(viewbox.height)


def _is_full_canvas_solid_rect(
    elem: ET.Element,
    canvas: tuple[float, float, float, float],
    *,
    root: ET.Element | None = None,
) -> bool:
    """Return whether a direct rect is eligible for scoped p:bg compilation."""
    if canvas[2] <= 0 or canvas[3] <= 0:
        return False
    if _local_tag(elem) != "rect":
        return False
    if any(elem.get(attr) for attr in ("transform", "filter", "clip-path")):
        return False
    style = parse_inline_style(elem.get("style"))
    root_style = parse_inline_style(root.get("style")) if root is not None else {}

    def root_value(name: str) -> str | None:
        return root_style.get(name, root.get(name)) if root is not None else None

    try:
        fill_opacity = style.get("fill-opacity", elem.get("fill-opacity"))
        if fill_opacity in {None, "inherit"}:
            fill_opacity = root_value("fill-opacity")
        opacity = style.get("opacity", elem.get("opacity"))
        if opacity == "inherit":
            opacity = root_value("opacity")
        if any(parse_opacity(value, allow_percentage=True) < 1
               for value in (fill_opacity, opacity, root_value("opacity"))):
            return False
    except ValueError:
        return False
    try:
        geometry = (
            parse_project_geometry_length(elem.get("x", "0"), "x"),
            parse_project_geometry_length(elem.get("y", "0"), "y"),
            parse_project_geometry_length(elem.get("width", "0"), "width"),
            parse_project_geometry_length(elem.get("height", "0"), "height"),
        )
        corner_radius = (
            parse_project_geometry_length(elem.get("rx", "0"), "rx"),
            parse_project_geometry_length(elem.get("ry", "0"), "ry"),
        )
    except ValueError:
        return False
    if not all(math.isfinite(value) for value in (*geometry, *corner_radius)):
        return False
    if corner_radius != (0.0, 0.0):
        return False
    if any(abs(actual - expected) > 0.5 for actual, expected in zip(geometry, canvas)):
        return False
    fill = (elem.get("fill") or "").strip().lower()
    if not fill or fill == "none" or fill.startswith("url("):
        return False
    stroke = (elem.get("stroke") or "none").strip().lower()
    if stroke != "none":
        try:
            if float(elem.get("stroke-opacity", "1")) != 0:
                return False
        except ValueError:
            return False
    return True


def _portable_project_file(
    project_path: Path,
    raw_value: str,
    field_name: str,
    suffix: str,
) -> Path:
    """Resolve a project-relative structure file without allowing escape."""
    value = raw_value.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
        value = value[1:-1].strip()
    if not value:
        raise TemplateStructureError(
            f"spec_lock.md pptx_structure.{field_name} cannot be empty"
        )
    candidate = Path(value)
    if candidate.is_absolute():
        raise TemplateStructureError(
            f"spec_lock.md pptx_structure.{field_name} must be project-relative"
        )
    root = project_path.resolve()
    resolved = (root / candidate).resolve()
    try:
        resolved.relative_to(root)
    except ValueError as exc:
        raise TemplateStructureError(
            f"spec_lock.md pptx_structure.{field_name} escapes the project directory"
        ) from exc
    if resolved.suffix.lower() != suffix:
        raise TemplateStructureError(
            f"spec_lock.md pptx_structure.{field_name} must reference a {suffix} file"
        )
    if not resolved.is_file():
        raise TemplateStructureError(
            f"spec_lock.md pptx_structure.{field_name} does not exist: {candidate}"
        )
    return resolved


def _template_replication_mode(template_dir: Path) -> str | None:
    """Read the optional replication mode from template design frontmatter."""
    spec_path = template_dir / "design_spec.md"
    try:
        lines = spec_path.read_text(encoding="utf-8").splitlines()
    except OSError:
        return None
    if not lines or lines[0].strip() != "---":
        return None
    for line in lines[1:]:
        stripped = line.strip()
        if stripped == "---":
            return None
        match = re.fullmatch(
            r"replication_mode\s*:\s*[\"']?(standard|fidelity|mirror)[\"']?",
            stripped,
            flags=re.IGNORECASE,
        )
        if match:
            return match.group(1).lower()
    return None


def load_template_source_themes(
    template_dir: Path,
) -> dict[str, bytes] | None:
    """Load exact per-Master themes carried by a Type A mirror workspace."""
    path = template_dir / SOURCE_THEMES_FILENAME
    if not path.exists():
        return None
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise TemplateStructureError(
            f"Cannot read template source themes {path}: {exc}"
        ) from exc
    schema = payload.get("schema") if isinstance(payload, dict) else None
    if not isinstance(payload, dict) or schema != SOURCE_THEMES_SCHEMA:
        raise TemplateStructureError(
            f"Unsupported template source theme schema: {schema!r}"
        )
    masters = payload.get("masters")
    if not isinstance(masters, dict) or not masters:
        raise TemplateStructureError(
            f"{SOURCE_THEMES_FILENAME} requires a non-empty masters object"
        )

    themes: dict[str, bytes] = {}
    for master_key, record in masters.items():
        if (
            not isinstance(master_key, str)
            or not _MASTER_KEY_RE.fullmatch(master_key)
        ):
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} has invalid Master key {master_key!r}"
            )
        if not isinstance(record, dict):
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} Master {master_key!r} must be an object"
            )
        if record.get("encoding") != "base64":
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} Master {master_key!r} must use base64"
            )
        encoded = record.get("payload")
        expected_sha256 = record.get("sha256")
        if (
            not isinstance(encoded, str)
            or not isinstance(expected_sha256, str)
        ):
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} Master {master_key!r} lacks payload/hash"
            )
        try:
            raw = base64.b64decode(encoded, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} Master {master_key!r} has invalid base64"
            ) from exc
        if base64.b64encode(raw).decode("ascii") != encoded:
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} Master {master_key!r} base64 is not canonical"
            )
        if hashlib.sha256(raw).hexdigest() != expected_sha256.strip().lower():
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} Master {master_key!r} hash differs"
            )
        try:
            root = ET.fromstring(raw)
        except ET.ParseError as exc:
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} Master {master_key!r} theme is malformed"
            ) from exc
        if root.tag != f"{{{_DML_NS}}}theme":
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} Master {master_key!r} is not a:theme"
            )
        if any(
            isinstance(name, str) and name.startswith(f"{{{_REL_NS}}}")
            for node in root.iter()
            for name in node.attrib
        ):
            raise TemplateStructureError(
                f"{SOURCE_THEMES_FILENAME} Master {master_key!r} has relationships"
            )
        themes[master_key] = raw
    return themes


def _template_svg_path(
    template_dir: Path,
    raw_basename: str,
    context: str,
) -> tuple[str, Path]:
    """Resolve one flat template SVG basename inside the project workspace."""
    basename = (
        raw_basename[:-4]
        if raw_basename.lower().endswith(".svg")
        else raw_basename
    )
    if (
        not basename
        or basename in {".", ".."}
        or "/" in basename
        or "\\" in basename
        or any(ord(char) < 0x20 for char in basename)
    ):
        raise TemplateStructureError(
            f"spec_lock.md {context} has invalid template SVG basename "
            f"{raw_basename!r}"
        )
    svg_path = (template_dir / f"{basename}.svg").resolve()
    if svg_path.parent != template_dir or not svg_path.is_file():
        raise TemplateStructureError(
            f"spec_lock.md {context} references missing template SVG "
            f"templates/{basename}.svg"
        )
    return basename, svg_path


def load_pptx_structure_lock(project_path: Path) -> PptxStructureLock | None:
    """Load optional native-structure sections from spec_lock.md."""
    lock_path = project_path / "spec_lock.md"
    if not lock_path.is_file():
        return None
    try:
        lines = lock_path.read_text(encoding="utf-8").splitlines()
    except OSError as exc:
        raise TemplateStructureError(f"Cannot read {lock_path}: {exc}") from exc

    sections: dict[str, list[tuple[str, str]]] = {}
    current_section: str | None = None
    for line_number, raw_line in enumerate(lines, start=1):
        line = raw_line.strip()
        if line.startswith("## "):
            current_section = line[3:].strip()
            sections.setdefault(current_section, [])
            continue
        if current_section not in {
            "pptx_structure",
            "pptx_masters",
            "pptx_layouts",
            "page_pptx_layouts",
            "page_layouts",
        }:
            continue
        match = _LOCK_ROW_RE.fullmatch(line)
        if match:
            sections[current_section].append((
                match.group(1).strip(),
                match.group(2).strip(),
            ))
        elif re.match(r"^-\s+", line):
            raise TemplateStructureError(
                f"spec_lock.md {current_section} line {line_number} must use "
                "'- <key>: <value>' syntax"
            )

    structure_rows = sections.get("pptx_structure", [])
    master_rows = sections.get("pptx_masters", [])
    layout_rows = sections.get("pptx_layouts", [])
    page_layout_rows = sections.get("page_pptx_layouts", [])
    prototype_rows = sections.get("page_layouts", [])
    structure_section_present = "pptx_structure" in sections
    master_section_present = "pptx_masters" in sections
    layout_section_present = "pptx_layouts" in sections
    page_layout_section_present = "page_pptx_layouts" in sections
    prototype_section_present = "page_layouts" in sections
    if (
        not structure_rows
        and not master_rows
        and not layout_rows
        and not page_layout_rows
        and not prototype_rows
        and not structure_section_present
        and not master_section_present
        and not layout_section_present
        and not page_layout_section_present
        and not prototype_section_present
    ):
        return None
    mode_rows = [value.strip().lower() for key, value in structure_rows if key == "mode"]
    if len(mode_rows) != 1:
        raise TemplateStructureError(
            "spec_lock.md pptx_structure requires exactly one '- mode:' row"
        )
    mode = mode_rows[0]
    if mode not in PPTX_STRUCTURE_MODES:
        allowed = ", ".join(sorted(PPTX_STRUCTURE_MODES))
        raise TemplateStructureError(
            f"spec_lock.md pptx_structure.mode must be one of: {allowed}"
        )

    adherence_rows = [
        value.strip().lower()
        for key, value in structure_rows
        if key == "template_adherence"
    ]
    if len(adherence_rows) > 1:
        raise TemplateStructureError(
            "spec_lock.md pptx_structure allows at most one "
            "'- template_adherence:' row"
        )
    template_adherence = adherence_rows[0] if adherence_rows else None
    if template_adherence and template_adherence not in TEMPLATE_ADHERENCE_MODES:
        allowed = ", ".join(sorted(TEMPLATE_ADHERENCE_MODES))
        raise TemplateStructureError(
            "spec_lock.md pptx_structure.template_adherence must be one of: "
            f"{allowed}"
        )
    if mode == "preserve" and template_adherence == "adaptive":
        raise TemplateStructureError(
            "spec_lock.md preserve mode requires template_adherence: strict; "
            "adaptive template use must export through structured mode"
        )
    if template_adherence and mode not in {"structured", "preserve"}:
        raise TemplateStructureError(
            "spec_lock.md template_adherence is allowed only in structured or "
            "preserve mode"
        )

    reuse_scope_rows = [
        value.strip().lower()
        for key, value in structure_rows
        if key == "template_reuse_scope"
    ]
    if len(reuse_scope_rows) > 1:
        raise TemplateStructureError(
            "spec_lock.md pptx_structure allows at most one "
            "'- template_reuse_scope:' row"
        )
    template_reuse_scope = reuse_scope_rows[0] if reuse_scope_rows else None
    if (
        template_reuse_scope
        and template_reuse_scope not in TEMPLATE_REUSE_SCOPES
    ):
        allowed = ", ".join(sorted(TEMPLATE_REUSE_SCOPES))
        raise TemplateStructureError(
            "spec_lock.md pptx_structure.template_reuse_scope must be one of: "
            f"{allowed}"
        )
    if mode == "preserve" and template_reuse_scope:
        raise TemplateStructureError(
            "spec_lock.md preserve mode does not use template_reuse_scope; "
            "the source PPTX structure is already authoritative"
        )
    if mode == "flat" and template_reuse_scope not in {None, "style"}:
        raise TemplateStructureError(
            "spec_lock.md flat mode permits only template_reuse_scope: style"
        )
    if mode == "structured" and template_reuse_scope == "style":
        raise TemplateStructureError(
            "spec_lock.md template_reuse_scope: style requires mode: flat and "
            "must omit structured template mappings"
        )
    if any(key == "layout_strategy" for key, _value in structure_rows):
        raise TemplateStructureError(
            "spec_lock.md pptx_structure.layout_strategy is obsolete; SVG pages "
            "must declare their final structured Master/Layout contract directly"
        )

    source_rows = [
        value for key, value in structure_rows if key == "source_template"
    ]
    contract_rows = [
        value for key, value in structure_rows if key == "native_structure"
    ]
    source_template = None
    native_structure = None
    if mode == "preserve":
        if len(source_rows) != 1 or len(contract_rows) != 1:
            raise TemplateStructureError(
                "spec_lock.md preserve mode requires exactly one '- source_template:' "
                "row and one '- native_structure:' row"
            )
        source_template = _portable_project_file(
            project_path,
            source_rows[0],
            "source_template",
            ".pptx",
        )
        native_structure = _portable_project_file(
            project_path,
            contract_rows[0],
            "native_structure",
            ".json",
        )
    elif source_rows or contract_rows:
        raise TemplateStructureError(
            "spec_lock.md source_template/native_structure rows are allowed only "
            "when pptx_structure.mode is preserve"
        )

    masters: list[PptxMasterReference] = []
    seen_master_keys: set[str] = set()
    for master_key, raw_name in master_rows:
        master_name = raw_name.strip()
        if not _MASTER_KEY_RE.fullmatch(master_key):
            raise TemplateStructureError(
                f"spec_lock.md has invalid Master key {master_key!r}; use 1-64 "
                "characters, start with an ASCII letter or digit, and use only "
                "ASCII letters, digits, dots, underscores, or hyphens"
            )
        if master_key in seen_master_keys:
            raise TemplateStructureError(
                f"spec_lock.md pptx_masters repeats Master key {master_key!r}"
            )
        if not master_name:
            raise TemplateStructureError(
                f"spec_lock.md Master {master_key!r} has an empty name"
            )
        seen_master_keys.add(master_key)
        masters.append(PptxMasterReference(master_key, master_name))

    if mode == "structured":
        if not master_rows:
            raise TemplateStructureError(
                "spec_lock.md structured mode requires a non-empty pptx_masters section"
            )
    elif master_section_present:
        raise TemplateStructureError(
            "spec_lock.md pptx_masters is allowed only when "
            "pptx_structure.mode is structured"
        )

    prototypes: list[PptxPrototypeReference] = []
    seen_prototype_slides: set[int] = set()
    template_dir = (project_path / "templates").resolve()
    template_replication_mode = _template_replication_mode(template_dir)
    if mode != "structured" and prototype_section_present:
        raise TemplateStructureError(
            "spec_lock.md page_layouts section is allowed only when pptx_structure.mode "
            "is structured"
        )
    for page_key, raw_value in prototype_rows:
        page_match = _LOCK_PAGE_RE.fullmatch(page_key)
        if not page_match or int(page_match.group(1)) <= 0:
            raise TemplateStructureError(
                f"spec_lock.md page_layouts key {page_key!r} must be P<NN>"
            )
        slide_num = int(page_match.group(1))
        if slide_num in seen_prototype_slides:
            raise TemplateStructureError(
                f"spec_lock.md page_layouts repeats page P{slide_num:02d}"
            )
        seen_prototype_slides.add(slide_num)
        raw_basename = raw_value.strip()
        basename, svg_path = _template_svg_path(
            template_dir,
            raw_basename,
            f"page_layouts P{slide_num:02d}",
        )
        if basename.startswith("layout_"):
            raise TemplateStructureError(
                f"spec_lock.md page_layouts P{slide_num:02d} cannot select "
                f"obsolete definition-only template SVG {basename!r}; create "
                "and select a complete Slide prototype"
            )
        prototypes.append(PptxPrototypeReference(
            slide_num=slide_num,
            template_basename=basename,
            svg_path=svg_path,
            replication_mode=template_replication_mode,
        ))

    if mode == "structured" and template_adherence and not prototypes:
        raise TemplateStructureError(
            "spec_lock.md structured template use requires one page_layouts row per page"
        )
    if prototypes and not template_adherence:
        raise TemplateStructureError(
            "spec_lock.md page_layouts requires template_adherence: strict or adaptive"
        )
    if template_reuse_scope in {"mirror", "layout"} and not prototypes:
        raise TemplateStructureError(
            "spec_lock.md template_reuse_scope mirror/layout requires one "
            "page_layouts row per page"
        )
    if template_reuse_scope == "style" and prototypes:
        raise TemplateStructureError(
            "spec_lock.md template_reuse_scope: style must omit page_layouts"
        )
    if template_reuse_scope == "mirror":
        non_mirror = sorted({
            reference.template_basename
            for reference in prototypes
            if reference.replication_mode != "mirror"
        })
        if non_mirror:
            raise TemplateStructureError(
                "spec_lock.md template_reuse_scope: mirror requires a mirror "
                "template workspace; non-mirror prototype(s): "
                + ", ".join(non_mirror)
            )
    if mode == "structured" and template_reuse_scope is None and prototypes:
        # Backward compatibility: projects created before the explicit reuse
        # axis inherit their former behavior. Mirror workspaces stay literal;
        # standard/fidelity workspaces remain structural layout references.
        template_reuse_scope = (
            "mirror"
            if all(
                reference.replication_mode == "mirror"
                for reference in prototypes
            )
            else "layout"
        )

    layout_definitions: list[PptxLayoutDefinition] = []
    references: list[PptxLayoutReference] = []
    if mode == "structured":
        if not layout_rows:
            raise TemplateStructureError(
                "spec_lock.md structured mode requires a non-empty "
                "pptx_layouts definition section"
            )
        seen_layout_keys: set[str] = set()
        for layout_key, raw_value in layout_rows:
            if not _LAYOUT_KEY_RE.fullmatch(layout_key):
                raise TemplateStructureError(
                    f"spec_lock.md has invalid Layout key {layout_key!r}; use 1-64 "
                    "characters, start with an ASCII letter or digit, and use only "
                    "ASCII letters, digits, dots, underscores, or hyphens"
                )
            if layout_key in seen_layout_keys:
                raise TemplateStructureError(
                    f"spec_lock.md pptx_layouts repeats Layout key {layout_key!r}"
                )
            seen_layout_keys.add(layout_key)
            parts = [part.strip() for part in raw_value.split("|")]
            if len(parts) != 3 or not all(parts):
                raise TemplateStructureError(
                    f"spec_lock.md Layout {layout_key!r} must be "
                    "'<master_key> | <PowerPoint layout name> | "
                    "<P<NN> or template:<basename>>'"
                )
            master_key, layout_name, raw_source = parts
            if not _MASTER_KEY_RE.fullmatch(master_key):
                raise TemplateStructureError(
                    f"spec_lock.md Layout {layout_key!r} has invalid Master key "
                    f"{master_key!r}"
                )
            if master_key not in seen_master_keys:
                raise TemplateStructureError(
                    f"spec_lock.md Layout {layout_key!r} references undeclared "
                    f"Master {master_key!r}"
                )
            prototype_slide_num: int | None = None
            prototype_svg_path: Path | None = None
            page_match = _LOCK_PAGE_RE.fullmatch(raw_source)
            if page_match and int(page_match.group(1)) > 0:
                prototype_slide_num = int(page_match.group(1))
            elif raw_source.startswith("template:"):
                raw_basename = raw_source.split(":", 1)[1].strip()
                basename, prototype_svg_path = _template_svg_path(
                    template_dir,
                    raw_basename,
                    f"pptx_layouts Layout {layout_key!r}",
                )
                if basename.startswith("layout_"):
                    raise TemplateStructureError(
                        f"spec_lock.md Layout {layout_key!r} cannot use obsolete "
                        f"definition-only template SVG {basename!r}; use a "
                        "complete Slide prototype"
                    )
            else:
                raise TemplateStructureError(
                    f"spec_lock.md Layout {layout_key!r} prototype source must be "
                    f"P<NN> or template:<basename>; found {raw_source!r}"
                )
            layout_definitions.append(PptxLayoutDefinition(
                layout_key=layout_key,
                master_key=master_key,
                layout_name=layout_name,
                prototype_slide_num=prototype_slide_num,
                prototype_svg_path=prototype_svg_path,
            ))

        seen_slides: set[int] = set()
        for page_key, raw_value in page_layout_rows:
            page_match = _LOCK_PAGE_RE.fullmatch(page_key)
            if not page_match or int(page_match.group(1)) <= 0:
                raise TemplateStructureError(
                    f"spec_lock.md page_pptx_layouts key {page_key!r} must be P<NN>"
                )
            slide_num = int(page_match.group(1))
            if slide_num in seen_slides:
                raise TemplateStructureError(
                    "spec_lock.md page_pptx_layouts repeats page "
                    f"P{slide_num:02d}"
                )
            seen_slides.add(slide_num)
            layout_key = raw_value.strip()
            if not _LAYOUT_KEY_RE.fullmatch(layout_key):
                raise TemplateStructureError(
                    f"spec_lock.md P{slide_num:02d} has invalid Layout key "
                    f"{layout_key!r}"
                )
            if layout_key not in seen_layout_keys:
                raise TemplateStructureError(
                    f"spec_lock.md P{slide_num:02d} references undeclared Layout "
                    f"{layout_key!r}"
                )
            references.append(PptxLayoutReference(
                slide_num=slide_num,
                layout_key=layout_key,
            ))
        if not references:
            raise TemplateStructureError(
                "spec_lock.md structured mode requires one page_pptx_layouts "
                "assignment per generated page"
            )
        unused_masters = sorted(
            seen_master_keys - {
                definition.master_key for definition in layout_definitions
            }
        )
        if unused_masters:
            raise TemplateStructureError(
                "spec_lock.md pptx_masters contains Master key(s) without a "
                "Layout definition: " + ", ".join(unused_masters)
            )
    elif mode == "preserve":
        if page_layout_section_present:
            raise TemplateStructureError(
                "spec_lock.md page_pptx_layouts is reserved for structured mode; "
                "preserve mode maps source Layouts directly in pptx_layouts"
            )
        seen_slides: set[int] = set()
        for page_key, raw_value in layout_rows:
            page_match = _LOCK_PAGE_RE.fullmatch(page_key)
            if not page_match or int(page_match.group(1)) <= 0:
                raise TemplateStructureError(
                    f"spec_lock.md pptx_layouts key {page_key!r} must be P<NN>"
                )
            slide_num = int(page_match.group(1))
            if slide_num in seen_slides:
                raise TemplateStructureError(
                    f"spec_lock.md pptx_layouts repeats page P{slide_num:02d}"
                )
            seen_slides.add(slide_num)
            parts = [part.strip() for part in raw_value.split("|")]
            if len(parts) not in {1, 2} or not parts[0]:
                raise TemplateStructureError(
                    f"spec_lock.md P{slide_num:02d} preserve mapping must be "
                    "'<layout_key>' or '<layout_key> | <PowerPoint layout name>'"
                )
            layout_key = parts[0]
            if not _LAYOUT_KEY_RE.fullmatch(layout_key):
                raise TemplateStructureError(
                    f"spec_lock.md P{slide_num:02d} has invalid Layout key "
                    f"{layout_key!r}"
                )
            references.append(PptxLayoutReference(
                slide_num=slide_num,
                layout_key=layout_key,
                layout_name=parts[1] if len(parts) == 2 else None,
            ))
        if not references:
            raise TemplateStructureError(
                "spec_lock.md preserve mode requires one pptx_layouts row per page"
            )
    else:
        if layout_section_present or page_layout_section_present:
            raise TemplateStructureError(
                "spec_lock.md pptx_layouts/page_pptx_layouts sections are not "
                "allowed when pptx_structure.mode is flat"
            )
    return PptxStructureLock(
        mode=mode,
        template_reuse_scope=template_reuse_scope,
        template_adherence=template_adherence,
        masters=tuple(masters),
        layout_definitions=tuple(layout_definitions),
        layouts=tuple(sorted(references, key=lambda item: item.slide_num)),
        prototypes=tuple(sorted(prototypes, key=lambda item: item.slide_num)),
        source_template=source_template,
        native_structure=native_structure,
    )


def _file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _native_geometry(raw: Any, context: str) -> tuple[float, float, float, float] | None:
    if raw is None:
        return None
    if not isinstance(raw, dict):
        raise TemplateStructureError(f"{context} geometry must be an object or null")
    try:
        values = tuple(float(raw[key]) for key in ("x", "y", "width", "height"))
    except (KeyError, TypeError, ValueError) as exc:
        raise TemplateStructureError(f"{context} geometry is invalid") from exc
    if not all(math.isfinite(value) for value in values) or values[2] < 0 or values[3] < 0:
        raise TemplateStructureError(f"{context} geometry must be finite and non-negative")
    if values[2] == 0 or values[3] == 0:
        # PowerPoint writes <a:ext cx="0" cy="0"/> for a collapsed placeholder
        # (built-in vertical-text layouts do this); it carries no usable box.
        return None
    return values


def load_native_structure_contract(
    structure_lock: PptxStructureLock,
) -> NativeStructureContract:
    """Load and verify the native structure bundle selected by preserve mode."""
    if structure_lock.mode != "preserve":
        raise TemplateStructureError(
            "native structure contracts are available only in preserve mode"
        )
    source_template = structure_lock.source_template
    contract_path = structure_lock.native_structure
    if source_template is None or contract_path is None:
        raise TemplateStructureError(
            "preserve mode is missing source_template or native_structure"
        )
    try:
        raw = json.loads(contract_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise TemplateStructureError(
            f"Cannot read native structure contract {contract_path}: {exc}"
        ) from exc
    if not isinstance(raw, dict) or raw.get("schema") != NATIVE_STRUCTURE_SCHEMA:
        raise TemplateStructureError(
            f"{contract_path.name} must use schema {NATIVE_STRUCTURE_SCHEMA!r}"
        )

    source = raw.get("source")
    expected_sha = source.get("sha256") if isinstance(source, dict) else None
    if not isinstance(expected_sha, str) or not re.fullmatch(r"[0-9a-f]{64}", expected_sha):
        raise TemplateStructureError(
            f"{contract_path.name} source.sha256 must be a lowercase SHA-256 digest"
        )
    actual_sha = _file_sha256(source_template)
    if actual_sha != expected_sha:
        raise TemplateStructureError(
            f"{source_template.name} does not match {contract_path.name} source.sha256"
        )

    slide_size = raw.get("slideSize")
    try:
        slide_size_emu = (
            int(slide_size["width_emu"]),
            int(slide_size["height_emu"]),
        )
    except (KeyError, TypeError, ValueError) as exc:
        raise TemplateStructureError(
            f"{contract_path.name} slideSize must contain width_emu/height_emu"
        ) from exc
    if slide_size_emu[0] <= 0 or slide_size_emu[1] <= 0:
        raise TemplateStructureError(
            f"{contract_path.name} slideSize values must be positive"
        )

    raw_layouts = raw.get("layouts")
    if not isinstance(raw_layouts, list) or not raw_layouts:
        raise TemplateStructureError(
            f"{contract_path.name} must contain at least one layout"
        )
    layouts: list[NativeLayoutSpec] = []
    seen_keys: set[str] = set()
    seen_parts: set[str] = set()
    for index, item in enumerate(raw_layouts):
        context = f"{contract_path.name} layouts[{index}]"
        if not isinstance(item, dict):
            raise TemplateStructureError(f"{context} must be an object")
        key = str(item.get("key") or "")
        name = str(item.get("name") or "").strip()
        package_part = str(item.get("packagePart") or "")
        master_key = str(item.get("masterKey") or "")
        if not _LAYOUT_KEY_RE.fullmatch(key):
            raise TemplateStructureError(f"{context} has invalid key {key!r}")
        if key in seen_keys:
            raise TemplateStructureError(f"{context} repeats layout key {key!r}")
        if not name:
            raise TemplateStructureError(f"{context} name cannot be empty")
        if (
            not package_part.startswith("ppt/slideLayouts/")
            or ".." in Path(package_part).parts
            or not package_part.endswith(".xml")
        ):
            raise TemplateStructureError(
                f"{context} packagePart must be a ppt/slideLayouts/*.xml part"
            )
        if package_part in seen_parts:
            raise TemplateStructureError(
                f"{context} repeats package part {package_part!r}"
            )
        if not master_key:
            raise TemplateStructureError(f"{context} masterKey cannot be empty")

        raw_placeholders = item.get("placeholders", [])
        if not isinstance(raw_placeholders, list):
            raise TemplateStructureError(f"{context} placeholders must be a list")
        placeholders: list[NativePlaceholderSpec] = []
        for ph_index, placeholder in enumerate(raw_placeholders):
            ph_context = f"{context} placeholders[{ph_index}]"
            if not isinstance(placeholder, dict):
                raise TemplateStructureError(f"{ph_context} must be an object")
            semantic_role = str(placeholder.get("semanticRole") or "other")
            placeholder_type = str(placeholder.get("type") or "obj")
            raw_idx = placeholder.get("idx")
            try:
                placeholder_idx = int(raw_idx) if raw_idx is not None else None
            except (TypeError, ValueError) as exc:
                raise TemplateStructureError(
                    f"{ph_context} idx must be an integer or null"
                ) from exc
            if placeholder_idx is not None and placeholder_idx < 0:
                raise TemplateStructureError(f"{ph_context} idx cannot be negative")
            placeholders.append(NativePlaceholderSpec(
                semantic_role=semantic_role,
                placeholder_type=placeholder_type,
                idx=placeholder_idx,
                geometry=_native_geometry(placeholder.get("geometry"), ph_context),
            ))
        layouts.append(NativeLayoutSpec(
            key=key,
            name=name,
            package_part=package_part,
            master_key=master_key,
            placeholders=tuple(placeholders),
        ))
        seen_keys.add(key)
        seen_parts.add(package_part)

    raw_slides = raw.get("slides")
    if not isinstance(raw_slides, list) or not raw_slides:
        raise TemplateStructureError(
            f"{contract_path.name} must contain at least one source slide"
        )
    slides: list[NativeSlideSpec] = []
    seen_slide_indices: set[int] = set()
    slide_parts: set[str] = set()
    for position, item in enumerate(raw_slides, start=1):
        context = f"{contract_path.name} slides[{position}]"
        if not isinstance(item, dict):
            raise TemplateStructureError(f"{context} must be an object")
        try:
            slide_index = int(item.get("index"))
        except (TypeError, ValueError) as exc:
            raise TemplateStructureError(f"{context} index must be an integer") from exc
        if slide_index <= 0 or slide_index in seen_slide_indices:
            raise TemplateStructureError(
                f"{context} index must be unique and positive"
            )
        layout_key = str(item.get("layoutKey") or "")
        if layout_key not in seen_keys:
            raise TemplateStructureError(
                f"{context} references unknown layout key {layout_key!r}"
            )
        raw_package_part = item.get("packagePart")
        if not isinstance(raw_package_part, str) or not raw_package_part:
            raise TemplateStructureError(
                f"{context} packagePart must be a non-empty string"
            )
        package_part = raw_package_part
        if (
            not package_part.startswith("ppt/slides/")
            or ".." in Path(package_part).parts
            or not package_part.endswith(".xml")
            or package_part in slide_parts
        ):
            raise TemplateStructureError(
                f"{context} packagePart must be a unique ppt/slides/*.xml part"
            )
        slides.append(NativeSlideSpec(
            index=slide_index,
            package_part=package_part,
            layout_key=layout_key,
        ))
        seen_slide_indices.add(slide_index)
        slide_parts.add(package_part)
    expected_indices = set(range(1, len(slides) + 1))
    if seen_slide_indices != expected_indices:
        raise TemplateStructureError(
            f"{contract_path.name} source slide indices must be contiguous from 1"
        )

    try:
        with zipfile.ZipFile(source_template, "r") as package:
            package_parts = set(package.namelist())
    except (OSError, zipfile.BadZipFile) as exc:
        raise TemplateStructureError(
            f"Cannot open preserved source template {source_template}: {exc}"
        ) from exc
    missing_parts = sorted((seen_parts | slide_parts) - package_parts)
    if missing_parts:
        raise TemplateStructureError(
            f"{source_template.name} is missing layout part(s): " + ", ".join(missing_parts)
        )

    return NativeStructureContract(
        source_template=source_template,
        contract_path=contract_path,
        source_sha256=expected_sha,
        slide_size_emu=slide_size_emu,
        layouts=tuple(layouts),
        slides=tuple(sorted(slides, key=lambda item: item.index)),
    )


def _parse_placeholder_bounds(
    raw: str | None,
    *,
    svg_path: Path,
    element_id: str,
) -> tuple[float, float, float, float] | None:
    if raw is None:
        return None
    parts = [part for part in re.split(r"[\s,]+", raw.strip()) if part]
    if len(parts) != 4:
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} data-pptx-bounds must be "
            "'x y width height'"
        )
    try:
        x, y, width, height = (float(part) for part in parts)
    except ValueError as exc:
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} placeholder bounds must be numeric"
        ) from exc
    if not all(math.isfinite(value) for value in (x, y, width, height)):
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} placeholder bounds must be finite"
        )
    if width <= 0 or height <= 0:
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} placeholder width/height must be positive"
        )
    return x, y, width, height


def _parse_placeholder_idx(
    raw: str | None,
    *,
    svg_path: Path,
    element_id: str,
) -> int | None:
    if raw is None:
        return None
    value = raw.strip()
    if not value or not value.isdigit():
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} data-pptx-idx must be "
            "a non-negative integer"
        )
    parsed = int(value)
    if parsed > OOXML_UINT32_MAX:
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} data-pptx-idx must be "
            f"at most {OOXML_UINT32_MAX}"
        )
    return parsed


def _validate_placeholder_carrier(
    carrier: ET.Element,
    placeholder: str,
    *,
    svg_path: Path,
    element_id: str,
) -> None:
    tag = _local_tag(carrier)
    if placeholder in _TEXT_PLACEHOLDERS and tag != "text":
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} placeholder '{placeholder}' must be "
            "carried by one direct <text> child"
        )
    picture_carrier = (
        tag in {"image", "svg"}
        or (tag == "g" and is_picture_effect_carrier(carrier))
    )
    if placeholder == "picture" and not picture_carrier:
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} picture placeholder must be declared "
            "with one direct <image>, crop <svg>, or exact clipped-picture "
            "effect carrier"
        )
    if placeholder == "media" and not picture_carrier:
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} media placeholder must be declared "
            "with one direct <image>, crop <svg>, or exact clipped-picture "
            "effect carrier"
        )
    if (
        placeholder == "object"
        and tag not in _OBJECT_PLACEHOLDER_TAGS
        and not _is_authored_preset_atom(carrier)
    ):
        raise TemplateStructureError(
            f"{svg_path.name}: {element_id} object placeholder carrier must be "
            "one direct text, image, basic SVG shape, or authored preset atom"
        )
    if placeholder in {"chart", "table"}:
        try:
            native_kind = native_replacement_kind(carrier)
        except NativeMarkerAttributeError as exc:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id} placeholder '{placeholder}' has "
                f"conflicting chart/table replacement metadata: {exc}"
            ) from exc
        if tag != "g" or native_kind != placeholder:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id} placeholder '{placeholder}' must be "
                f"carried by one direct <g data-pptx-replace-with=\"{placeholder}\"> "
                "marker"
            )


def _structure_attrs(elem: ET.Element) -> list[str]:
    return sorted(attr for attr in _STRUCTURE_ATTRS if elem.get(attr) is not None)


def _parse_root_boolean(
    root: ET.Element,
    attribute: str,
    *,
    svg_path: Path,
) -> bool:
    """Parse one optional root boolean with a backward-compatible true default."""
    raw = root.get(attribute)
    if raw is None:
        return True
    if raw not in {"true", "false"}:
        raise TemplateStructureError(
            f"{svg_path.name}: root {attribute} must be exactly 'true' or 'false'"
        )
    return raw == "true"


def parse_template_slide(
    svg_path: Path,
    slide_num: int,
    *,
    structured: bool = True,
) -> TemplateSlideSpec:
    """Parse one SVG's explicit template layout and structure elements."""
    try:
        root = _parse_svg_root(svg_path)
    except (OSError, ET.ParseError, NativePayloadError) as exc:
        raise TemplateStructureError(
            f"{svg_path.name}: unable to parse SVG structure metadata: {exc}"
        ) from exc

    try:
        materialize_inline_geometry_properties(root)
    except GeometryStyleError as exc:
        raise TemplateStructureError(
            f"{svg_path.name}: invalid inline geometry: {exc}"
        ) from exc

    if _local_tag(root) != "svg":
        raise TemplateStructureError(f"{svg_path.name}: root element must be <svg>")
    try:
        parse_project_viewbox(
            root.get("viewBox"),
            context=f"{svg_path.name} root viewBox",
        )
    except CanvasContractError as exc:
        raise TemplateStructureError(str(exc)) from exc

    geometry_errors = project_geometry_length_errors(root)
    if geometry_errors:
        preview = "; ".join(geometry_errors[:8])
        suffix = (
            "" if len(geometry_errors) <= 8
            else f"; +{len(geometry_errors) - 8} more"
        )
        raise TemplateStructureError(
            f"{svg_path.name}: invalid project geometry length(s): "
            f"{preview}{suffix}"
        )

    master_key = (root.get("data-pptx-master") or "").strip()
    master_name = (root.get("data-pptx-master-name") or "").strip()
    if structured and not master_key:
        raise TemplateStructureError(
            f"{svg_path.name}: structured export requires root data-pptx-master"
        )
    if structured and not master_name:
        raise TemplateStructureError(
            f"{svg_path.name}: structured export requires root data-pptx-master-name"
        )
    if not master_key:
        master_key = "preserved-source"
    if not master_name:
        master_name = "Preserved Source Master"
    if not _MASTER_KEY_RE.fullmatch(master_key):
        raise TemplateStructureError(
            f"{svg_path.name}: invalid data-pptx-master {master_key!r}; use 1-64 "
            "ASCII letters, digits, dots, underscores, or hyphens"
        )

    layout_key = (root.get("data-pptx-layout") or "").strip()
    if not layout_key:
        raise TemplateStructureError(
            f"{svg_path.name}: explicit Layout export requires root data-pptx-layout"
        )
    if not _LAYOUT_KEY_RE.fullmatch(layout_key):
        raise TemplateStructureError(
            f"{svg_path.name}: invalid data-pptx-layout {layout_key!r}; use 1-64 "
            "ASCII letters, digits, dots, underscores, or hyphens"
        )
    layout_name = (root.get("data-pptx-layout-name") or "").strip()
    if structured and not layout_name:
        raise TemplateStructureError(
            f"{svg_path.name}: structured export requires root data-pptx-layout-name"
        )
    if not layout_name:
        layout_name = re.sub(r"[-_.]+", " ", layout_key).strip().title() or layout_key
    layout_show_master_shapes = _parse_root_boolean(
        root,
        "data-pptx-show-master-shapes",
        svg_path=svg_path,
    )
    slide_show_inherited_shapes = _parse_root_boolean(
        root,
        "data-pptx-show-inherited-shapes",
        svg_path=svg_path,
    )
    if structured and root.get("data-pptx-layout-kind") is not None:
        raise TemplateStructureError(
            f"{svg_path.name}: data-pptx-layout-kind is obsolete; the root "
            "Master/Layout identity is already final"
        )

    illegal_root_attrs = sorted(
        attr for attr in _STRUCTURE_ATTRS
        if (
            attr not in {
                "data-pptx-layout",
                "data-pptx-layout-name",
                "data-pptx-master",
                "data-pptx-master-name",
                "data-pptx-show-inherited-shapes",
                "data-pptx-show-master-shapes",
            }
            and root.get(attr) is not None
        )
    )
    if illegal_root_attrs:
        raise TemplateStructureError(
            f"{svg_path.name}: root <svg> cannot use {', '.join(illegal_root_attrs)}"
        )

    id_counts: dict[str, int] = {}
    for elem in root.iter():
        element_id = elem.get("id")
        if element_id:
            id_counts[element_id] = id_counts.get(element_id, 0) + 1
    duplicate_ids = sorted(element_id for element_id, count in id_counts.items() if count > 1)
    if duplicate_ids:
        raise TemplateStructureError(
            f"{svg_path.name}: duplicate SVG id(s) are not allowed in explicit Layout mode: "
            + ", ".join(duplicate_ids)
        )

    elements: list[TemplateElementSpec] = []
    canvas = _svg_canvas(root)
    last_order_rank = -1
    visual_order = 0
    for elem in root:
        tag = _local_tag(elem)
        if tag in _NON_VISUAL_TAGS:
            continue

        element_id = (elem.get("id") or "").strip()
        layer_raw = elem.get("data-pptx-layer")
        layer = (layer_raw or "").strip().lower() or None
        placeholder_raw = elem.get("data-pptx-placeholder")
        placeholder = (
            (placeholder_raw or "").strip().lower() or None
        )
        bounds_raw = elem.get("data-pptx-bounds")
        placeholder_idx_raw = elem.get("data-pptx-idx")
        binding_raw = elem.get("data-pptx-binding")
        carrier_raw = elem.get("data-pptx-carrier")
        editable_raw = elem.get("data-pptx-editable")
        is_background = _is_full_canvas_solid_rect(elem, canvas, root=root)
        effective_layer = layer or ("slide" if is_background else None)

        if (
            elem.get("data-pptx-layout") is not None
            or elem.get("data-pptx-layout-name") is not None
            or elem.get("data-pptx-master") is not None
            or elem.get("data-pptx-master-name") is not None
            or elem.get("data-pptx-show-inherited-shapes") is not None
            or elem.get("data-pptx-show-master-shapes") is not None
        ):
            raise TemplateStructureError(
                f"{svg_path.name}: Master/Layout identity and visibility "
                "attributes belong on the root <svg> only"
            )
        if layer and layer not in _LAYERS:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} has unsupported "
                f"data-pptx-layer={layer!r}"
            )
        if layer_raw is not None and layer is None:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} has empty data-pptx-layer"
            )
        if placeholder and placeholder not in _PLACEHOLDERS:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} has unsupported "
                f"data-pptx-placeholder={placeholder!r}"
            )
        if placeholder_raw is not None and placeholder is None:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} has empty "
                "data-pptx-placeholder"
            )
        if effective_layer and placeholder:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} cannot be both a static "
                "structure/background layer and a content placeholder"
            )
        if layer == "slide" and not is_background:
            raise TemplateStructureError(
                f"{svg_path.name}: data-pptx-layer='slide' is allowed only on a "
                "direct full-canvas solid background rect"
            )
        if (
            structured
            and layer in {"master", "layout"}
            and tag == "g"
            and not _is_authored_preset_atom(elem)
            and not is_picture_effect_carrier(elem)
        ):
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} is a <g> on the {layer} "
                "layer; Master/Layout fixed elements must be root-level atoms"
            )
        if placeholder_idx_raw is not None and not placeholder:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} has placeholder idx without "
                "data-pptx-placeholder"
            )
        if binding_raw is not None and not placeholder:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} has placeholder binding "
                "without data-pptx-placeholder"
            )
        if carrier_raw is not None:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} declares "
                "data-pptx-carrier on a root child; the marker belongs "
                "on the direct child inside a placeholder <g>"
            )
        if (effective_layer or placeholder) and not element_id:
            raise TemplateStructureError(
                f"{svg_path.name}: direct <{tag}> with Layout metadata requires an id"
            )
        if editable_raw is not None:
            if not effective_layer or editable_raw.strip().lower() != "false":
                raise TemplateStructureError(
                    f"{svg_path.name}: data-pptx-editable currently supports only "
                    "'false' on master/layout elements or slide backgrounds"
                )

        if is_background:
            order_rank = {"master": 0, "layout": 1, "slide": 2}[effective_layer]
        elif effective_layer == "master":
            order_rank = 3
        elif effective_layer == "layout":
            order_rank = 4
        else:
            order_rank = 5
        if order_rank < last_order_rank:
            raise TemplateStructureError(
                f"{svg_path.name}: {element_id or tag} violates template paint order; "
                "use Master background, Layout background, Slide background, "
                "Master shapes, Layout shapes, then Slide content/placeholders. "
                "Full-canvas solid rects are treated as backgrounds; translucent overlays are not backgrounds"
            )
        last_order_rank = order_rank

        placeholder_bounds = _parse_placeholder_bounds(
            bounds_raw if placeholder else None,
            svg_path=svg_path,
            element_id=element_id or tag,
        )
        if structured and placeholder and placeholder_bounds is None:
            raise TemplateStructureError(
                f"{svg_path.name}: Layout placeholder {element_id!r} requires "
                "explicit data-pptx-bounds; define the "
                "reusable frame from the design zone, not the current text bounds"
            )
        placeholder_idx = _parse_placeholder_idx(
            placeholder_idx_raw,
            svg_path=svg_path,
            element_id=element_id or tag,
        )

        placeholder_binding: str | None = None
        placeholder_carrier_tag: str | None = None
        if placeholder and structured:
            if tag != "g":
                raise TemplateStructureError(
                    f"{svg_path.name}: placeholder {element_id!r} must be declared "
                    "on a root-level <g> authoring boundary"
                )
            wrapper_visual_attrs = sorted(
                name
                for name in elem.attrib
                if name != "id" and not name.startswith("data-pptx-")
            )
            if wrapper_visual_attrs:
                raise TemplateStructureError(
                    f"{svg_path.name}: placeholder group {element_id!r} must be a "
                    "render-neutral authoring boundary; move these attributes to "
                    "its content: " + ", ".join(wrapper_visual_attrs)
                )
            placeholder_binding = (binding_raw or "carrier").strip().lower()
            if binding_raw is not None and not binding_raw.strip():
                raise TemplateStructureError(
                    f"{svg_path.name}: placeholder {element_id!r} has an empty "
                    "data-pptx-binding"
                )
            if placeholder_binding not in PLACEHOLDER_BINDING_MODES:
                allowed = ", ".join(sorted(PLACEHOLDER_BINDING_MODES))
                raise TemplateStructureError(
                    f"{svg_path.name}: placeholder {element_id!r} binding must be "
                    f"one of: {allowed}"
                )
            visual_children = [
                child for child in elem if _local_tag(child) not in _NON_VISUAL_TAGS
            ]
            carrier_children = [
                child
                for child in visual_children
                if (child.get("data-pptx-carrier") or "")
                .strip()
                .lower()
                == "true"
            ]
            for child in elem:
                marker = child.get("data-pptx-carrier")
                if marker is not None and marker.strip().lower() != "true":
                    raise TemplateStructureError(
                        f"{svg_path.name}: placeholder {element_id!r} carrier marker "
                        "must be exactly 'true'"
                    )
                illegal_child_attrs = [
                    attr
                    for attr in _structure_attrs(child)
                    if attr != "data-pptx-carrier"
                ]
                if illegal_child_attrs:
                    raise TemplateStructureError(
                        f"{svg_path.name}: placeholder {element_id!r} child uses "
                        "nested structure metadata: " + ", ".join(illegal_child_attrs)
                    )
                for descendant in child.iter():
                    if descendant is child:
                        continue
                    nested_attrs = _structure_attrs(descendant)
                    if nested_attrs:
                        nested_id = descendant.get("id") or _local_tag(descendant)
                        raise TemplateStructureError(
                            f"{svg_path.name}: {nested_id} uses nested structure "
                            "metadata: " + ", ".join(nested_attrs)
                        )
            if placeholder_binding == "proxy":
                if placeholder != "object":
                    raise TemplateStructureError(
                        f"{svg_path.name}: placeholder {element_id!r} may use proxy "
                        "binding only with data-pptx-placeholder='object'"
                    )
                if carrier_children:
                    raise TemplateStructureError(
                        f"{svg_path.name}: proxy placeholder {element_id!r} must not "
                        "declare a carrier child"
                    )
                if not visual_children:
                    raise TemplateStructureError(
                        f"{svg_path.name}: proxy placeholder {element_id!r} must "
                        "contain visible Slide-local content"
                    )
            else:
                if len(visual_children) != 1 or len(carrier_children) != 1:
                    composite_hint = (
                        " For composite object content, declare "
                        "data-pptx-binding='proxy' in the prototype "
                        "and page, or create an adaptive Layout; never add a tiny "
                        "or transparent dummy carrier."
                        if placeholder == "object" else ""
                    )
                    raise TemplateStructureError(
                        f"{svg_path.name}: carrier placeholder {element_id!r} must "
                        "contain exactly one visual direct child and mark it "
                        "data-pptx-carrier='true'."
                        f"{composite_hint}"
                    )
                carrier = carrier_children[0]
                placeholder_carrier_tag = _local_tag(carrier)
                _validate_placeholder_carrier(
                    carrier,
                    placeholder,
                    svg_path=svg_path,
                    element_id=element_id,
                )
        elif placeholder:
            placeholder_binding = "carrier"
            placeholder_carrier_tag = tag
            _validate_placeholder_carrier(
                elem,
                placeholder,
                svg_path=svg_path,
                element_id=element_id,
            )
        else:
            for descendant in elem.iter():
                if descendant is elem:
                    continue
                nested_attrs = _structure_attrs(descendant)
                if nested_attrs:
                    nested_id = descendant.get("id") or _local_tag(descendant)
                    raise TemplateStructureError(
                        f"{svg_path.name}: {nested_id} uses structure metadata below "
                        "the SVG root: " + ", ".join(nested_attrs)
                    )

        if effective_layer or placeholder:
            elements.append(TemplateElementSpec(
                element_id=element_id,
                order=visual_order,
                tag=tag,
                layer=effective_layer,
                placeholder=placeholder,
                placeholder_bounds=placeholder_bounds,
                placeholder_idx=placeholder_idx,
                placeholder_binding=placeholder_binding,
                placeholder_carrier_tag=placeholder_carrier_tag,
                is_background=is_background,
            ))
        visual_order += 1

    for scope in ("master", "layout", "slide"):
        backgrounds = [
            item for item in elements
            if item.layer == scope and item.is_background
        ]
        if len(backgrounds) > 1:
            raise TemplateStructureError(
                f"{svg_path.name}: explicit Layout mode allows at most one {scope} "
                "solid background"
            )

    spec = TemplateSlideSpec(
        slide_num=slide_num,
        svg_path=svg_path,
        master_key=master_key,
        master_name=master_name,
        layout_key=layout_key,
        layout_name=layout_name,
        layout_show_master_shapes=layout_show_master_shapes,
        slide_show_inherited_shapes=slide_show_inherited_shapes,
        elements=tuple(elements),
    )
    return spec


def _validate_template_slide_contracts(
    specs: list[TemplateSlideSpec],
) -> None:
    """Enforce cross-prototype Master and Layout structure identity."""
    by_master: dict[str, list[TemplateSlideSpec]] = {}
    for spec in specs:
        by_master.setdefault(spec.master_key, []).append(spec)
    for master_key, master_specs in by_master.items():
        prototype = master_specs[0]
        expected_master = tuple(
            item.contract_signature() for item in prototype.master_elements
        )
        for spec in master_specs[1:]:
            if spec.master_name != prototype.master_name:
                raise TemplateStructureError(
                    f"{spec.svg_path.name}: Master {master_key!r} uses name "
                    f"{spec.master_name!r}, expected {prototype.master_name!r}"
                )
            actual_master = tuple(
                item.contract_signature() for item in spec.master_elements
            )
            if actual_master != expected_master:
                raise TemplateStructureError(
                    f"{spec.svg_path.name}: Master {master_key!r} contract differs "
                    f"from {prototype.svg_path.name}; slides sharing one Master must "
                    "repeat the same root-level atoms in the same order"
                )

    by_layout: dict[str, list[TemplateSlideSpec]] = {}
    for spec in specs:
        by_layout.setdefault(spec.layout_key, []).append(spec)
    for layout_key, layout_specs in by_layout.items():
        prototype = layout_specs[0]
        template_placeholder_bindings(prototype)
        for spec in layout_specs[1:]:
            if spec.layout_name != prototype.layout_name:
                raise TemplateStructureError(
                    f"{spec.svg_path.name}: layout {layout_key!r} uses name "
                    f"{spec.layout_name!r}, expected {prototype.layout_name!r}"
                )
            if spec.master_key != prototype.master_key:
                raise TemplateStructureError(
                    f"{spec.svg_path.name}: globally unique layout {layout_key!r} "
                    f"belongs to Master {spec.master_key!r}, expected "
                    f"{prototype.master_key!r}"
                )
            if (
                spec.layout_show_master_shapes
                != prototype.layout_show_master_shapes
            ):
                raise TemplateStructureError(
                    f"{spec.svg_path.name}: layout {layout_key!r} uses "
                    "data-pptx-show-master-shapes="
                    f"{str(spec.layout_show_master_shapes).lower()}, expected "
                    f"{str(prototype.layout_show_master_shapes).lower()}"
                )
            if spec.layout_contract != prototype.layout_contract:
                raise TemplateStructureError(
                    f"{spec.svg_path.name}: layout {layout_key!r} structure differs "
                    f"from prototype {prototype.svg_path.name}; repeat the same layout "
                    "layers and placeholder ids/types in the same order"
                )


def parse_template_slides(svg_files: list[Path]) -> list[TemplateSlideSpec]:
    """Parse a deck and enforce cross-slide master/layout contracts."""
    specs = [
        parse_template_slide(svg_path, slide_num)
        for slide_num, svg_path in enumerate(svg_files, start=1)
    ]
    if not specs:
        raise TemplateStructureError(
            "Explicit Layout export requires at least one SVG slide"
        )
    _validate_template_slide_contracts(specs)
    return specs


def parse_optional_layout_slides(
    svg_files: list[Path],
) -> list[TemplateSlideSpec] | None:
    """Parse an all-or-none structured Layout contract, or return no metadata."""
    roots: list[tuple[Path, ET.Element]] = []
    has_structure_metadata = False
    for svg_path in svg_files:
        try:
            root = _parse_svg_root(svg_path)
        except (OSError, ET.ParseError, NativePayloadError) as exc:
            raise TemplateStructureError(
                f"{svg_path.name}: unable to inspect SVG Layout metadata: {exc}"
            ) from exc
        roots.append((svg_path, root))
        has_structure_metadata = has_structure_metadata or any(
            elem.get(attr) is not None
            for elem in root.iter()
            for attr in _STRUCTURE_ATTRS
        )

    if not has_structure_metadata:
        return None

    missing_master_keys = [
        svg_path.name
        for svg_path, root in roots
        if not (root.get("data-pptx-master") or "").strip()
    ]
    missing_master_names = [
        svg_path.name
        for svg_path, root in roots
        if not (root.get("data-pptx-master-name") or "").strip()
    ]
    missing_keys = [
        svg_path.name
        for svg_path, root in roots
        if not (root.get("data-pptx-layout") or "").strip()
    ]
    missing_names = [
        svg_path.name
        for svg_path, root in roots
        if not (root.get("data-pptx-layout-name") or "").strip()
    ]
    if missing_master_keys or missing_master_names or missing_keys or missing_names:
        missing_fields: list[str] = []
        if missing_master_keys:
            missing_fields.append(
                "data-pptx-master: " + ", ".join(missing_master_keys)
            )
        if missing_master_names:
            missing_fields.append(
                "data-pptx-master-name: " + ", ".join(missing_master_names)
            )
        if missing_keys:
            missing_fields.append(
                "data-pptx-layout: " + ", ".join(missing_keys)
            )
        if missing_names:
            missing_fields.append(
                "data-pptx-layout-name: " + ", ".join(missing_names)
            )
        raise TemplateStructureError(
            "Explicit Layout metadata is all-or-none: once any SVG uses PPTX "
            "structure metadata, every generated page root must declare "
            "Master/Layout keys and names with non-empty values; "
            "missing "
            + "; ".join(missing_fields)
        )
    return parse_template_slides(svg_files)


def flat_structure_metadata_errors(svg_files: list[Path]) -> list[str]:
    """Return every Master/Layout marker forbidden by flat export."""
    errors: list[str] = []
    for svg_path in svg_files:
        try:
            root = _parse_svg_root(svg_path)
        except (OSError, ET.ParseError, NativePayloadError) as exc:
            errors.append(
                f"{svg_path.name}: unable to inspect flat-mode metadata: {exc}"
            )
            continue
        for elem in root.iter():
            attrs = sorted(
                attr
                for attr in _FLAT_FORBIDDEN_STRUCTURE_ATTRS
                if elem.get(attr) is not None
            )
            if not attrs:
                continue
            element_id = (elem.get("id") or _local_tag(elem)).strip()
            errors.append(
                f"{svg_path.name}: flat mode forbids Master/Layout structure "
                f"metadata on {element_id!r}: " + ", ".join(attrs)
            )
    return errors


def parse_preserve_slides(svg_files: list[Path]) -> list[TemplateSlideSpec]:
    """Parse preserve-mode slides before source master grouping is known."""
    specs = [
        parse_template_slide(svg_path, slide_num, structured=False)
        for slide_num, svg_path in enumerate(svg_files, start=1)
    ]
    if not specs:
        raise TemplateStructureError("Preserve export requires at least one SVG slide")
    return specs


def structured_layout_definition_files(
    specs: list[TemplateSlideSpec],
    structure_lock: PptxStructureLock,
) -> list[Path]:
    """Validate the explicit registered Layout set and return unused carriers.

    A generated page can be the carrier for a used Layout definition. A Layout
    with no generated page must point at one installed template SVG; the builder
    converts that SVG on an internal trailing slide and removes the carrier slide
    after registering the reusable Layout.
    Installed prototypes absent from ``pptx_layouts`` are never compiled.
    Lockless Quick export compiles only its public pages' Layouts.
    """
    if structure_lock.mode != "structured":
        return []
    definitions = {
        definition.layout_key: definition
        for definition in structure_lock.layout_definitions
    }
    specs_by_slide = {spec.slide_num: spec for spec in specs}
    used_layout_keys = {spec.layout_key for spec in specs}
    master_names = {
        master.master_key: master.master_name
        for master in structure_lock.masters
    }
    combined_specs = list(specs)
    definition_files: list[Path] = []
    next_slide_num = max(specs_by_slide, default=0) + 1
    for definition in structure_lock.layout_definitions:
        if definition.prototype_slide_num is not None:
            prototype = specs_by_slide.get(definition.prototype_slide_num)
            if prototype is None:
                raise TemplateStructureError(
                    f"spec_lock.md Layout {definition.layout_key!r} uses missing "
                    f"prototype page P{definition.prototype_slide_num:02d}"
                )
        elif definition.prototype_svg_path is not None:
            prototype = parse_template_slide(
                definition.prototype_svg_path,
                next_slide_num,
            )
            next_slide_num += 1
            combined_specs.append(prototype)
            if definition.layout_key not in used_layout_keys:
                definition_files.append(definition.prototype_svg_path)
        else:
            raise TemplateStructureError(
                f"spec_lock.md Layout {definition.layout_key!r} has no prototype"
            )
        expected_master_name = master_names.get(definition.master_key)
        if (
            prototype.layout_key != definition.layout_key
            or prototype.layout_name != definition.layout_name
            or prototype.master_key != definition.master_key
            or prototype.master_name != expected_master_name
        ):
            raise TemplateStructureError(
                f"spec_lock.md Layout {definition.layout_key!r} definition does "
                f"not match prototype {prototype.svg_path.name} root identity"
            )
    missing_definitions = sorted(used_layout_keys - set(definitions))
    if missing_definitions:
        raise TemplateStructureError(
            "spec_lock.md pptx_layouts is missing generated Layout key(s): "
            + ", ".join(missing_definitions)
        )
    _validate_template_slide_contracts(combined_specs)
    return definition_files


def template_prototype_lock_errors(
    structure_lock: PptxStructureLock,
) -> list[str]:
    """Validate selected input prototypes before generated pages exist.

    ``page_layouts`` records authoring-input provenance. Strict execution keeps
    that prototype's Layout identity, while adaptive execution may declare a
    new Layout under the same Master. Final generated SVGs remain subject to
    :func:`template_lock_errors` and :func:`template_prototype_errors`.
    """
    if structure_lock.mode != "structured":
        return []

    errors: list[str] = []
    specs: list[TemplateSlideSpec] = []
    for prototype in structure_lock.prototypes:
        try:
            specs.append(
                parse_template_slide(prototype.svg_path, prototype.slide_num)
            )
        except TemplateStructureError as exc:
            errors.append(str(exc))
    if errors:
        return list(dict.fromkeys(errors))

    try:
        _validate_template_slide_contracts(specs)
    except TemplateStructureError as exc:
        errors.append(str(exc))

    assignments = {
        reference.slide_num: reference
        for reference in structure_lock.layouts
    }
    definitions = {
        definition.layout_key: definition
        for definition in structure_lock.layout_definitions
    }
    master_names = {
        master.master_key: master.master_name
        for master in structure_lock.masters
    }
    prototype_pages = {spec.slide_num for spec in specs}
    assignment_pages = set(assignments)
    missing_assignments = sorted(prototype_pages - assignment_pages)
    missing_prototypes = sorted(assignment_pages - prototype_pages)
    if missing_assignments:
        errors.append(
            "spec_lock.md page_pptx_layouts is missing generated page(s): "
            + ", ".join(
                f"P{slide_num:02d}" for slide_num in missing_assignments
            )
        )
    if missing_prototypes:
        errors.append(
            "spec_lock.md page_layouts is missing generated page(s): "
            + ", ".join(f"P{slide_num:02d}" for slide_num in missing_prototypes)
        )

    adherence = structure_lock.template_adherence or "strict"
    for spec in specs:
        assignment = assignments.get(spec.slide_num)
        if assignment is None:
            continue
        definition = definitions.get(assignment.layout_key)
        if definition is None:
            errors.append(
                f"spec_lock.md P{spec.slide_num:02d} references undeclared "
                f"Layout {assignment.layout_key!r}"
            )
            continue
        expected_master_name = master_names.get(definition.master_key)
        if (
            spec.master_key != definition.master_key
            or spec.master_name != expected_master_name
        ):
            errors.append(
                f"{spec.svg_path.name}: input prototype Master "
                f"{spec.master_key!r} / {spec.master_name!r} does not match "
                f"assigned Layout {definition.layout_key!r} Master "
                f"{definition.master_key!r} / {expected_master_name!r}"
            )

        reuses_input_layout = spec.layout_key == definition.layout_key
        must_match_layout = (
            adherence == "strict"
            or reuses_input_layout
            or definition.prototype_svg_path is not None
        )
        if must_match_layout and (
            spec.layout_key != definition.layout_key
            or spec.layout_name != definition.layout_name
        ):
            errors.append(
                f"{spec.svg_path.name}: input prototype Layout "
                f"{spec.layout_key!r} / {spec.layout_name!r} does not match "
                f"assigned Layout {definition.layout_key!r} / "
                f"{definition.layout_name!r}"
            )
        elif (
            adherence == "adaptive"
            and not reuses_input_layout
            and spec.layout_name == definition.layout_name
        ):
            errors.append(
                f"{spec.svg_path.name}: adaptive output Layout "
                f"{definition.layout_key!r} must use a new picker name instead "
                f"of input prototype name {spec.layout_name!r}"
            )

    definition_specs = list(specs)
    next_slide_num = max(prototype_pages, default=0) + 1
    for definition in structure_lock.layout_definitions:
        if definition.prototype_slide_num is not None:
            source_assignment = assignments.get(definition.prototype_slide_num)
            if source_assignment is None:
                errors.append(
                    f"spec_lock.md Layout {definition.layout_key!r} uses missing "
                    f"prototype page P{definition.prototype_slide_num:02d}"
                )
            elif source_assignment.layout_key != definition.layout_key:
                errors.append(
                    f"spec_lock.md Layout {definition.layout_key!r} uses "
                    f"P{definition.prototype_slide_num:02d}, but that page is "
                    f"assigned to Layout {source_assignment.layout_key!r}"
                )
            continue
        if definition.prototype_svg_path is None:
            errors.append(
                f"spec_lock.md Layout {definition.layout_key!r} has no prototype"
            )
            continue
        try:
            definition_spec = parse_template_slide(
                definition.prototype_svg_path,
                next_slide_num,
            )
            next_slide_num += 1
        except TemplateStructureError as exc:
            errors.append(str(exc))
            continue
        definition_specs.append(definition_spec)
        expected_master_name = master_names.get(definition.master_key)
        if (
            definition_spec.layout_key != definition.layout_key
            or definition_spec.layout_name != definition.layout_name
            or definition_spec.master_key != definition.master_key
            or definition_spec.master_name != expected_master_name
        ):
            errors.append(
                f"spec_lock.md Layout {definition.layout_key!r} definition does "
                f"not match prototype {definition_spec.svg_path.name} root identity"
            )

    try:
        _validate_template_slide_contracts(definition_specs)
    except TemplateStructureError as exc:
        errors.append(str(exc))
    return list(dict.fromkeys(errors))


def template_lock_errors(
    specs: list[TemplateSlideSpec],
    structure_lock: PptxStructureLock,
) -> list[str]:
    """Return mismatches between parsed SVG layouts and the project lock."""
    if structure_lock.mode not in {"structured", "preserve"}:
        return []
    errors: list[str] = []
    references = {
        reference.slide_num: reference
        for reference in structure_lock.layouts
    }
    actual_slides = {spec.slide_num for spec in specs}
    expected_slides = set(references)
    missing = sorted(actual_slides - expected_slides)
    extra = sorted(expected_slides - actual_slides)
    assignment_section = (
        "page_pptx_layouts"
        if structure_lock.mode == "structured"
        else "pptx_layouts"
    )
    if missing:
        pages = ", ".join(f"P{slide_num:02d}" for slide_num in missing)
        errors.append(
            f"spec_lock.md {assignment_section} is missing generated page(s): "
            f"{pages}"
        )
    if extra:
        pages = ", ".join(f"P{slide_num:02d}" for slide_num in extra)
        errors.append(
            f"spec_lock.md {assignment_section} references absent page(s): "
            f"{pages}"
        )
    for spec in specs:
        reference = references.get(spec.slide_num)
        if reference is None:
            continue
        if spec.layout_key != reference.layout_key:
            errors.append(
                f"{spec.svg_path.name}: data-pptx-layout={spec.layout_key!r} "
                f"does not match spec_lock P{spec.slide_num:02d} Layout key "
                f"{reference.layout_key!r}"
            )
        if structure_lock.mode == "preserve":
            if reference.layout_name and spec.layout_name != reference.layout_name:
                errors.append(
                    f"{spec.svg_path.name}: data-pptx-layout-name="
                    f"{spec.layout_name!r} does not match spec_lock "
                    f"P{spec.slide_num:02d} Layout name "
                    f"{reference.layout_name!r}"
                )
    if structure_lock.mode == "structured":
        definitions = {
            definition.layout_key: definition
            for definition in structure_lock.layout_definitions
        }
        master_names = {
            master.master_key: master.master_name for master in structure_lock.masters
        }
        for spec in specs:
            definition = definitions.get(spec.layout_key)
            if definition is not None:
                if spec.layout_name != definition.layout_name:
                    errors.append(
                        f"{spec.svg_path.name}: data-pptx-layout-name="
                        f"{spec.layout_name!r} does not match Layout "
                        f"{spec.layout_key!r} name {definition.layout_name!r}"
                    )
                if spec.master_key != definition.master_key:
                    errors.append(
                        f"{spec.svg_path.name}: data-pptx-master="
                        f"{spec.master_key!r} does not match Layout "
                        f"{spec.layout_key!r} Master {definition.master_key!r}"
                    )
            expected_name = master_names.get(spec.master_key)
            if expected_name is not None and spec.master_name != expected_name:
                errors.append(
                    f"{spec.svg_path.name}: data-pptx-master-name="
                    f"{spec.master_name!r} does not match spec_lock Master "
                    f"{spec.master_key!r} name {expected_name!r}"
                )
        try:
            structured_layout_definition_files(specs, structure_lock)
        except TemplateStructureError as exc:
            errors.append(str(exc))
    return errors


def _signature_attr_value(
    name: str,
    value: str,
    *,
    svg_path: Path | None,
    asset_identity: bool,
) -> str:
    """Normalize portable asset references without weakening visual identity."""
    if name.rsplit("}", 1)[-1] != "href":
        return value
    if asset_identity:
        if value.startswith("#") or "://" in value:
            return value
        if value.startswith("data:"):
            return "data-sha256:" + hashlib.sha256(
                value.encode("utf-8")
            ).hexdigest()
        if svg_path is None:
            raise TemplateStructureError(
                "literal asset comparison requires the source SVG path"
            )
        asset_path = (svg_path.parent / value).resolve()
        if not asset_path.is_file():
            raise TemplateStructureError(
                f"{svg_path.name}: mirror asset reference does not resolve: "
                f"{value!r}"
            )
        return "file-sha256:" + _file_sha256(asset_path)
    if value.startswith("data:") or "://" in value:
        return value
    return value.replace("\\", "/").rsplit("/", 1)[-1]


def _element_tree_signature(
    elem: ET.Element,
    *,
    include_skin: bool = False,
    include_text: bool = True,
    svg_path: Path | None = None,
    asset_identity: bool = False,
    ignore_structure_attrs: bool = False,
    ignore_json_native_preview: bool = False,
) -> tuple[object, ...]:
    """Return a stable structural or literal-visual SVG subtree signature."""
    text = (elem.text or "") if include_text else ""
    if _local_tag(elem) not in {"text", "tspan"} and not text.strip():
        text = ""
    attrs = tuple(sorted(
        (
            name,
            _signature_attr_value(
                name,
                value,
                svg_path=svg_path,
                asset_identity=asset_identity,
            ),
        )
        for name, value in elem.attrib.items()
        if (
            not (
                ignore_structure_attrs
                and name.rsplit("}", 1)[-1] in _STRUCTURE_ATTRS
            )
            and (
                include_skin
                or name.rsplit("}", 1)[-1] not in _TEMPLATE_SKIN_ATTRS
            )
        )
    ))
    children = (
        _mirror_comparison_children(elem)
        if ignore_json_native_preview
        else tuple(elem)
    )
    json_native_marker = (
        ignore_json_native_preview and _is_json_first_native_marker(elem)
    )
    return (
        elem.tag,
        attrs,
        text,
        tuple(
            _element_tree_signature(
                child,
                include_skin=include_skin,
                include_text=(
                    include_text
                    or (
                        json_native_marker
                        and _local_tag(child) == "metadata"
                    )
                ),
                svg_path=svg_path,
                asset_identity=asset_identity,
                ignore_structure_attrs=ignore_structure_attrs,
                ignore_json_native_preview=ignore_json_native_preview,
            )
            for child in children
        ),
    )


def _is_json_first_native_marker(elem: ET.Element) -> bool:
    """Return whether this element directly owns JSON-first Chart/Table data."""
    try:
        replacement_kind = native_replacement_kind(elem)
    except NativeMarkerAttributeError:
        return False
    return (
        native_json_is_authoritative(elem)
        and replacement_kind in {"chart", "table"}
    )


def _mirror_comparison_children(elem: ET.Element) -> tuple[ET.Element, ...]:
    """Exclude only the derived preview below a JSON-first native marker."""
    if not _is_json_first_native_marker(elem):
        return tuple(elem)
    return tuple(child for child in elem if _local_tag(child) == "metadata")


def _mirror_resource_projection(elem: ET.Element) -> ET.Element:
    """Copy one comparison subtree without JSON-first derived previews."""
    projected = copy.deepcopy(elem)

    def prune(node: ET.Element) -> None:
        if _is_json_first_native_marker(node):
            for child in list(node):
                if _local_tag(child) != "metadata":
                    node.remove(child)
            return
        for child in node:
            prune(child)

    prune(projected)
    return projected


def _svg_reference_ids(elem: ET.Element) -> set[str]:
    """Return fragment ids referenced anywhere in one SVG subtree."""
    references: set[str] = set()
    for node in elem.iter():
        for name, value in node.attrib.items():
            if name.rsplit("}", 1)[-1] == "href" and value.startswith("#"):
                references.add(value[1:])
            references.update(
                match.group(2)[1:]
                for match in _CSS_URL_RE.finditer(value)
                if match.group(2).startswith("#")
            )
    return references


def _font_family_names(raw_value: str) -> set[str]:
    """Return normalized CSS font-family names from one declaration value."""
    return {
        value.strip().strip("'\"")
        for value in raw_value.split(",")
        if value.strip().strip("'\"")
    }


def _font_families_from_declarations(raw: str) -> set[str]:
    """Return font families assigned by one inline or stylesheet declaration."""
    families: set[str] = set()
    for match in re.finditer(
        r"font-family\s*:\s*([^;{}]+)",
        raw,
        flags=re.IGNORECASE,
    ):
        families.update(_font_family_names(match.group(1)))
    return families


def _scope_selector_tokens(
    root: ET.Element,
    elements: tuple[ET.Element, ...],
) -> tuple[set[str], set[str], set[str], list[dict[str, str]], set[str]]:
    """Collect the small selector vocabulary needed to filter SVG CSS rules."""
    ids: set[str] = set()
    classes: set[str] = set()
    tags: set[str] = set()
    attributes: list[dict[str, str]] = []
    font_families: set[str] = set()
    nodes = [root]
    for element in elements:
        nodes.extend(element.iter())
    for node in nodes:
        tags.add(_local_tag(node))
        node_id = (node.get("id") or "").strip()
        if node_id:
            ids.add(node_id)
        classes.update((node.get("class") or "").split())
        local_attrs = {
            name.rsplit("}", 1)[-1]: value
            for name, value in node.attrib.items()
        }
        attributes.append(local_attrs)
        if local_attrs.get("font-family"):
            font_families.update(
                _font_family_names(local_attrs["font-family"])
            )
        if local_attrs.get("style"):
            font_families.update(
                _font_families_from_declarations(local_attrs["style"])
            )
    return ids, classes, tags, attributes, font_families


def _css_selector_matches_scope(
    selector: str,
    *,
    ids: set[str],
    classes: set[str],
    tags: set[str],
    attributes: list[dict[str, str]],
) -> bool:
    """Conservatively decide whether one simple SVG selector can affect scope."""
    selector_ids = set(_CSS_ID_RE.findall(selector))
    if selector_ids and not selector_ids.issubset(ids):
        return False
    selector_classes = set(_CSS_CLASS_RE.findall(selector))
    if selector_classes and not selector_classes.issubset(classes):
        return False
    for match in _CSS_ATTR_RE.finditer(selector):
        attr_name = match.group(1).rsplit(":", 1)[-1]
        expected = (match.group(3) or "").strip()
        if not any(
            attr_name in attrs
            and (not expected or attrs[attr_name].strip() == expected)
            for attrs in attributes
        ):
            return False
    selector_tags = {
        tag.lower()
        for tag in _CSS_TAG_RE.findall(selector)
        if tag != "*"
    }
    if selector_tags and not selector_tags.issubset(
        {tag.lower() for tag in tags}
    ):
        return False
    return True


def _css_asset_signature(value: str, svg_path: Path) -> str:
    """Replace CSS URL assets with byte identities while retaining fragments."""
    def replace(match: re.Match[str]) -> str:
        target = match.group(2).strip()
        if target.startswith("#"):
            return f"url({target})"
        identity = _signature_attr_value(
            "href",
            target,
            svg_path=svg_path,
            asset_identity=True,
        )
        return f"url({identity})"

    return _CSS_URL_RE.sub(replace, value)


def _normalize_css_declarations(raw: str, svg_path: Path) -> str:
    """Normalize formatting-only CSS differences without changing cascade order."""
    declarations: list[str] = []
    for raw_declaration in raw.split(";"):
        declaration = raw_declaration.strip()
        if not declaration:
            continue
        if ":" not in declaration:
            declarations.append(" ".join(declaration.split()))
            continue
        name, value = declaration.split(":", 1)
        normalized_value = " ".join(
            _css_asset_signature(value.strip(), svg_path).split()
        )
        declarations.append(f"{name.strip().lower()}:{normalized_value}")
    return ";".join(declarations)


def _scope_css_signature(
    root: ET.Element,
    elements: tuple[ET.Element, ...],
    svg_path: Path,
) -> tuple[tuple[str, str], ...]:
    """Return only stylesheet rules that can affect the selected visual scope."""
    ids, classes, tags, attributes, font_families = _scope_selector_tokens(
        root,
        elements,
    )
    parsed_rules: list[tuple[str, str]] = []
    for style in root.iter():
        if _local_tag(style) != "style":
            continue
        css = _CSS_COMMENT_RE.sub("", style.text or "")
        for match in _CSS_RULE_RE.finditer(css):
            parsed_rules.append((match.group(1).strip(), match.group(2)))

    matched_selectors: dict[int, tuple[str, ...]] = {}
    for index, (raw_selector, body) in enumerate(parsed_rules):
        if raw_selector.startswith("@"):
            continue
        selectors = tuple(
            " ".join(selector.split())
            for selector in raw_selector.split(",")
            if _css_selector_matches_scope(
                selector,
                ids=ids,
                classes=classes,
                tags=tags,
                attributes=attributes,
            )
        )
        if selectors:
            matched_selectors[index] = selectors
            font_families.update(_font_families_from_declarations(body))

    rules: list[tuple[str, str]] = []
    for index, (raw_selector, body) in enumerate(parsed_rules):
        selectors = matched_selectors.get(index)
        if selectors is None:
            if not raw_selector.lower().startswith("@font-face"):
                continue
            declared_families = _font_families_from_declarations(body)
            if not declared_families.intersection(font_families):
                continue
            selectors = ("@font-face",)
        rules.append((
            ",".join(selectors),
            _normalize_css_declarations(body, svg_path),
        ))
    return tuple(rules)


def _scope_visual_resources_signature(
    root: ET.Element,
    elements: tuple[ET.Element, ...],
    svg_path: Path,
    *,
    ignore_json_native_preview: bool = False,
) -> tuple[object, ...]:
    """Capture root inheritance, relevant CSS, and the referenced defs closure."""
    if not elements:
        return ()
    comparison_elements = (
        tuple(_mirror_resource_projection(element) for element in elements)
        if ignore_json_native_preview
        else elements
    )
    root_attrs = tuple(sorted(
        (
            name,
            _signature_attr_value(
                name,
                value,
                svg_path=svg_path,
                asset_identity=True,
            ),
        )
        for name, value in root.attrib.items()
        if (
            name.rsplit("}", 1)[-1] not in _STRUCTURE_ATTRS
            and not name.rsplit("}", 1)[-1].startswith("data-")
        )
    ))
    css_rules = _scope_css_signature(root, comparison_elements, svg_path)
    references: set[str] = set()
    for element in comparison_elements:
        references.update(_svg_reference_ids(element))
    for _selector, declarations in css_rules:
        references.update(
            match.group(2)[1:]
            for match in _CSS_URL_RE.finditer(declarations)
            if match.group(2).startswith("#")
        )

    definitions_by_id: dict[str, ET.Element] = {}
    for definitions in root.iter():
        if _local_tag(definitions) != "defs":
            continue
        for definition in definitions.iter():
            definition_id = (definition.get("id") or "").strip()
            if definition_id:
                definitions_by_id[definition_id] = definition

    pending = list(references)
    resolved: set[str] = set()
    while pending:
        reference = pending.pop()
        if reference in resolved:
            continue
        resolved.add(reference)
        definition = definitions_by_id.get(reference)
        if definition is not None:
            pending.extend(_svg_reference_ids(definition) - resolved)
    definition_signatures = tuple(
        (
            reference,
            _element_tree_signature(
                definitions_by_id[reference],
                include_skin=True,
                include_text=True,
                svg_path=svg_path,
                asset_identity=True,
            ) if reference in definitions_by_id else ("missing", reference),
        )
        for reference in sorted(resolved)
    )
    return root_attrs, css_rules, definition_signatures


def _structure_subtree_signature(
    svg_path: Path,
    elements: tuple[TemplateElementSpec, ...],
    *,
    include_skin: bool = False,
    include_text: bool = True,
    asset_identity: bool = False,
    ignore_json_native_preview: bool = False,
) -> tuple[tuple[str, tuple[object, ...]], ...]:
    """Read structural or literal-visual signatures for direct SVG children."""
    try:
        root = _parse_svg_root(svg_path)
        materialize_inline_geometry_properties(root)
    except (OSError, ET.ParseError, NativePayloadError, GeometryStyleError) as exc:
        raise TemplateStructureError(
            f"{svg_path.name}: unable to compare template prototype structure: {exc}"
        ) from exc
    direct_by_id = {
        (child.get("id") or "").strip(): child
        for child in root
        if (child.get("id") or "").strip()
    }
    signatures: list[tuple[str, tuple[object, ...]]] = []
    for item in elements:
        child = direct_by_id.get(item.element_id)
        if child is None:
            raise TemplateStructureError(
                f"{svg_path.name}: structure element {item.element_id!r} is no "
                "longer a direct SVG child"
            )
        signatures.append((
            item.element_id,
            _element_tree_signature(
                child,
                include_skin=include_skin,
                include_text=include_text,
                svg_path=svg_path,
                asset_identity=asset_identity,
                ignore_json_native_preview=ignore_json_native_preview,
            ),
        ))
    if include_skin:
        selected = tuple(
            direct_by_id[item.element_id]
            for item in elements
            if item.element_id in direct_by_id
        )
        signatures.append((
            "__visual_resources__",
            _scope_visual_resources_signature(
                root,
                selected,
                svg_path,
                ignore_json_native_preview=ignore_json_native_preview,
            ),
        ))
    return tuple(signatures)


def _mirror_ordinary_slide_ids(spec: TemplateSlideSpec) -> set[str]:
    """Return stable ids that are ordinary Slide content in one mirror page."""
    try:
        root = _parse_svg_root(spec.svg_path)
    except (OSError, ET.ParseError, NativePayloadError) as exc:
        raise TemplateStructureError(
            f"{spec.svg_path.name}: unable to inspect mirror page ownership: {exc}"
        ) from exc
    inherited_ids = {
        item.element_id
        for item in (
            *spec.master_elements,
            *spec.layout_elements,
            *spec.placeholders,
        )
    }
    return {
        element_id
        for child in root
        if _local_tag(child) not in _NON_VISUAL_TAGS
        if (element_id := (child.get("id") or "").strip())
        if element_id not in inherited_ids
    }


def _mirror_slide_local_signature(
    spec: TemplateSlideSpec,
    protected_ids: set[str],
) -> tuple[tuple[object, ...], tuple[object, ...]]:
    """Capture literal mirror visuals that are Slide-local on either page.

    Visible text values and JSON-first native preview children may change, but
    other element topology, attributes, grouping, paint, geometry, and
    referenced asset bytes remain literal.
    Structure metadata may change when adaptive template authoring assigns an
    evolved Layout identity to the same stable SVG id.
    """
    try:
        root = _parse_svg_root(spec.svg_path)
        materialize_inline_geometry_properties(root)
    except (OSError, ET.ParseError, NativePayloadError, GeometryStyleError) as exc:
        raise TemplateStructureError(
            f"{spec.svg_path.name}: unable to compare mirror page visuals: {exc}"
        ) from exc
    slide_elements: list[ET.Element] = []
    slide_visuals: list[tuple[object, ...]] = []
    for child in root:
        tag = _local_tag(child)
        if tag in _NON_VISUAL_TAGS:
            continue
        element_id = (child.get("id") or "").strip()
        if element_id and element_id not in protected_ids:
            continue
        slide_elements.append(child)
        slide_visuals.append(
            _element_tree_signature(
                child,
                include_skin=True,
                include_text=False,
                svg_path=spec.svg_path,
                asset_identity=True,
                ignore_structure_attrs=True,
                ignore_json_native_preview=True,
            )
        )
    resources = _scope_visual_resources_signature(
        root,
        tuple(slide_elements),
        spec.svg_path,
        ignore_json_native_preview=True,
    )
    return resources, tuple(slide_visuals)


def _prototype_placeholder_contract(
    spec: TemplateSlideSpec,
) -> tuple[tuple[object, ...], ...]:
    """Return the strict template placeholder contract without slide content."""
    return tuple(item.contract_signature() for item in spec.placeholders)


def _layout_contract_difference(
    actual: tuple[TemplateElementSpec, ...],
    expected: tuple[TemplateElementSpec, ...],
) -> str:
    """Describe the smallest actionable difference in a Layout atom roster."""
    actual_ids = tuple(item.element_id for item in actual)
    expected_ids = tuple(item.element_id for item in expected)
    actual_id_set = set(actual_ids)
    expected_id_set = set(expected_ids)
    missing = tuple(item for item in expected_ids if item not in actual_id_set)
    unexpected = tuple(item for item in actual_ids if item not in expected_id_set)
    details: list[str] = []
    if missing:
        details.append(
            "missing generated Layout element id(s): "
            + ", ".join(repr(item) for item in missing)
        )
    if unexpected:
        details.append(
            "unexpected generated Layout element id(s): "
            + ", ".join(repr(item) for item in unexpected)
        )
    if not details and actual_ids != expected_ids:
        details.append("generated Layout element order differs")
    if not details:
        details.append(
            "shared Layout element metadata (data-pptx-* attributes), geometry, "
            "topology, or content differs; fills, strokes, and gradients may be "
            "repainted"
        )
    return "; ".join(details)


def _mirror_comparable_attributes(
    element: ET.Element,
    svg_path: Path,
    *,
    ignore_structure_attrs: bool,
) -> dict[str, str]:
    """Return literal mirror attributes using the validator's normalization."""
    return {
        name: _signature_attr_value(
            name,
            value,
            svg_path=svg_path,
            asset_identity=True,
        )
        for name, value in element.attrib.items()
        if not (
            ignore_structure_attrs
            and name.rsplit("}", 1)[-1] in _STRUCTURE_ATTRS
        )
    }


def _mirror_node_label(element: ET.Element, index: int) -> str:
    """Return a compact stable-enough path segment for one SVG node."""
    tag = _local_tag(element)
    element_id = (element.get("id") or "").strip()
    return f"{tag}#{element_id}" if element_id else f"{tag}[{index}]"


def _mirror_element_difference(
    expected: ET.Element,
    actual: ET.Element,
    *,
    expected_svg: Path,
    actual_svg: Path,
    path: str,
    ignore_structure_attrs: bool,
) -> str | None:
    """Describe the first literal mirror subtree difference."""
    expected_tag = _local_tag(expected)
    actual_tag = _local_tag(actual)
    if expected_tag != actual_tag:
        return f"{path}: expected <{expected_tag}>, found <{actual_tag}>"
    if (
        expected_tag == "metadata"
        and (expected.text or "") != (actual.text or "")
    ):
        return f"{path}: metadata payload differs"

    expected_attrs = _mirror_comparable_attributes(
        expected,
        expected_svg,
        ignore_structure_attrs=ignore_structure_attrs,
    )
    actual_attrs = _mirror_comparable_attributes(
        actual,
        actual_svg,
        ignore_structure_attrs=ignore_structure_attrs,
    )
    if expected_attrs != actual_attrs:
        for name in sorted(set(expected_attrs) | set(actual_attrs)):
            expected_value = expected_attrs.get(name)
            actual_value = actual_attrs.get(name)
            if expected_value != actual_value:
                return (
                    f"{path}: attribute {name.rsplit('}', 1)[-1]!r} expected "
                    f"{expected_value!r}, found {actual_value!r}"
                )

    expected_children = list(_mirror_comparison_children(expected))
    actual_children = list(_mirror_comparison_children(actual))
    if len(expected_children) != len(actual_children):
        expected_tspans = sum(
            _local_tag(child) == "tspan" for child in expected_children
        )
        actual_tspans = sum(
            _local_tag(child) == "tspan" for child in actual_children
        )
        if expected_tspans != actual_tspans:
            return (
                f"{path}: expected {expected_tspans} direct <tspan> child(ren), "
                f"found {actual_tspans}; mirror text node count/order must stay "
                "unchanged"
            )
        return (
            f"{path}: expected {len(expected_children)} child node(s), found "
            f"{len(actual_children)}"
        )

    for index, (expected_child, actual_child) in enumerate(
        zip(expected_children, actual_children),
        start=1,
    ):
        child_path = f"{path}/{_mirror_node_label(expected_child, index)}"
        difference = _mirror_element_difference(
            expected_child,
            actual_child,
            expected_svg=expected_svg,
            actual_svg=actual_svg,
            path=child_path,
            ignore_structure_attrs=ignore_structure_attrs,
        )
        if difference:
            return difference
    return None


def _mirror_slide_local_difference(
    expected_spec: TemplateSlideSpec,
    actual_spec: TemplateSlideSpec,
    protected_ids: set[str],
) -> str | None:
    """Describe the first Slide-local mirror difference."""
    expected_root = _parse_svg_root(expected_spec.svg_path)
    actual_root = _parse_svg_root(actual_spec.svg_path)
    materialize_inline_geometry_properties(expected_root)
    materialize_inline_geometry_properties(actual_root)

    def selected(root: ET.Element) -> list[ET.Element]:
        output: list[ET.Element] = []
        for child in root:
            if _local_tag(child) in _NON_VISUAL_TAGS:
                continue
            element_id = (child.get("id") or "").strip()
            if element_id and element_id not in protected_ids:
                continue
            output.append(child)
        return output

    expected_children = selected(expected_root)
    actual_children = selected(actual_root)
    if len(expected_children) != len(actual_children):
        return (
            f"svg: expected {len(expected_children)} Slide-local top-level "
            f"element(s), found {len(actual_children)}"
        )
    for index, (expected, actual) in enumerate(
        zip(expected_children, actual_children),
        start=1,
    ):
        difference = _mirror_element_difference(
            expected,
            actual,
            expected_svg=expected_spec.svg_path,
            actual_svg=actual_spec.svg_path,
            path=f"svg/{_mirror_node_label(expected, index)}",
            ignore_structure_attrs=True,
        )
        if difference:
            return difference
    if _scope_visual_resources_signature(
        expected_root,
        tuple(expected_children),
        expected_spec.svg_path,
        ignore_json_native_preview=True,
    ) != _scope_visual_resources_signature(
        actual_root,
        tuple(actual_children),
        actual_spec.svg_path,
        ignore_json_native_preview=True,
    ):
        return "svg: referenced defs, CSS, root styling, or asset identity differs"
    return None


def _mirror_structure_difference(
    expected_spec: TemplateSlideSpec,
    actual_spec: TemplateSlideSpec,
    elements: tuple[TemplateElementSpec, ...],
) -> str | None:
    """Describe the first mirror difference in named structural elements."""
    expected_root = _parse_svg_root(expected_spec.svg_path)
    actual_root = _parse_svg_root(actual_spec.svg_path)
    materialize_inline_geometry_properties(expected_root)
    materialize_inline_geometry_properties(actual_root)
    expected_by_id = {
        (child.get("id") or "").strip(): child
        for child in expected_root
        if (child.get("id") or "").strip()
    }
    actual_by_id = {
        (child.get("id") or "").strip(): child
        for child in actual_root
        if (child.get("id") or "").strip()
    }
    for item in elements:
        expected = expected_by_id.get(item.element_id)
        actual = actual_by_id.get(item.element_id)
        if expected is None or actual is None:
            return (
                f"svg/{item.element_id}: expected direct structural element is "
                "missing from one side"
            )
        difference = _mirror_element_difference(
            expected,
            actual,
            expected_svg=expected_spec.svg_path,
            actual_svg=actual_spec.svg_path,
            path=f"svg/{_mirror_node_label(expected, 1)}",
            ignore_structure_attrs=False,
        )
        if difference:
            return difference
    return None


def template_prototype_errors(
    specs: list[TemplateSlideSpec],
    structure_lock: PptxStructureLock,
    *,
    require_complete_roster: bool = True,
) -> list[str]:
    """Compare structured template pages with their selected SVG prototypes."""
    if structure_lock.mode != "structured" or not structure_lock.prototypes:
        return []
    errors: list[str] = []
    prototypes = {
        reference.slide_num: reference
        for reference in structure_lock.prototypes
    }
    adherence = structure_lock.template_adherence or "strict"
    actual_slides = {spec.slide_num for spec in specs}
    prototype_slides = set(prototypes)
    missing_prototypes = sorted(actual_slides - prototype_slides)
    extra_prototypes = sorted(prototype_slides - actual_slides)
    if missing_prototypes:
        errors.append(
            "spec_lock.md page_layouts is missing generated page(s): "
            + ", ".join(f"P{slide_num:02d}" for slide_num in missing_prototypes)
        )
    if require_complete_roster and extra_prototypes:
        errors.append(
            "spec_lock.md page_layouts references absent page(s): "
            + ", ".join(f"P{slide_num:02d}" for slide_num in extra_prototypes)
        )
    for spec in specs:
        reference = prototypes.get(spec.slide_num)
        if reference is None:
            errors.append(
                f"{spec.svg_path.name}: spec_lock.md page_layouts is missing "
                f"prototype P{spec.slide_num:02d}"
            )
            continue
        try:
            prototype = parse_template_slide(reference.svg_path, spec.slide_num)
        except TemplateStructureError as exc:
            errors.append(str(exc))
            continue

        try:
            literal_visual = (
                structure_lock.template_reuse_scope == "mirror"
                if structure_lock.template_reuse_scope is not None
                else reference.replication_mode == "mirror"
            )
            expected_master_structure = _structure_subtree_signature(
                prototype.svg_path,
                prototype.master_elements,
                include_skin=literal_visual,
                asset_identity=literal_visual,
                ignore_json_native_preview=literal_visual,
            )
            actual_master_structure = _structure_subtree_signature(
                spec.svg_path,
                spec.master_elements,
                include_skin=literal_visual,
                asset_identity=literal_visual,
                ignore_json_native_preview=literal_visual,
            )
        except TemplateStructureError as exc:
            errors.append(str(exc))
            continue
        if (
            spec.master_key != prototype.master_key
            or spec.master_name != prototype.master_name
            or tuple(item.contract_signature() for item in spec.master_elements)
            != tuple(
                item.contract_signature() for item in prototype.master_elements
            )
            or actual_master_structure != expected_master_structure
        ):
            master_difference = (
                _mirror_structure_difference(
                    prototype,
                    spec,
                    prototype.master_elements,
                )
                if literal_visual
                else None
            )
            errors.append(
                f"{spec.svg_path.name}: template Master structure differs "
                f"from prototype {reference.svg_path.name}; strict and adaptive "
                "routes must retain its ids, topology, geometry, data-pptx-* "
                "metadata, and content"
                + (
                    " including mirror visual styling"
                    if literal_visual
                    else "; fills, strokes, and gradients may be repainted"
                )
                + (
                    f"; first difference: {master_difference}"
                    if master_difference else ""
                )
            )

        if literal_visual:
            try:
                protected_slide_ids = (
                    _mirror_ordinary_slide_ids(prototype)
                    | _mirror_ordinary_slide_ids(spec)
                )
                expected_slide_visual = _mirror_slide_local_signature(
                    prototype,
                    protected_slide_ids,
                )
                actual_slide_visual = _mirror_slide_local_signature(
                    spec,
                    protected_slide_ids,
                )
            except TemplateStructureError as exc:
                errors.append(str(exc))
                continue
            if actual_slide_visual != expected_slide_visual:
                difference = _mirror_slide_local_difference(
                    prototype,
                    spec,
                    protected_slide_ids,
                )
                errors.append(
                    f"{spec.svg_path.name}: mirror Slide-local non-text visuals "
                    f"differ from prototype {reference.svg_path.name}; preserve "
                    "grouping, geometry, paint, effects, and referenced asset "
                    "identity; only visible text content and JSON-first derived "
                    "preview children may change"
                    + (f"; first difference: {difference}" if difference else "")
                )

        try:
            expected_layout_structure = _structure_subtree_signature(
                prototype.svg_path,
                prototype.layout_elements,
                include_skin=literal_visual,
                asset_identity=literal_visual,
                ignore_json_native_preview=literal_visual,
            )
            actual_layout_structure = _structure_subtree_signature(
                spec.svg_path,
                spec.layout_elements,
                include_skin=literal_visual,
                asset_identity=literal_visual,
                ignore_json_native_preview=literal_visual,
            )
            if literal_visual:
                expected_placeholder_visual = _structure_subtree_signature(
                    prototype.svg_path,
                    prototype.placeholders,
                    include_skin=True,
                    include_text=False,
                    asset_identity=True,
                    ignore_json_native_preview=True,
                )
                actual_placeholder_visual = _structure_subtree_signature(
                    spec.svg_path,
                    spec.placeholders,
                    include_skin=True,
                    include_text=False,
                    asset_identity=True,
                    ignore_json_native_preview=True,
                )
            else:
                expected_placeholder_visual = ()
                actual_placeholder_visual = ()
        except TemplateStructureError as exc:
            errors.append(str(exc))
            continue

        placeholder_contract_same = (
            _prototype_placeholder_contract(spec)
            == _prototype_placeholder_contract(prototype)
        )
        layout_contract_same = (
            spec.layout_show_master_shapes
            == prototype.layout_show_master_shapes
            and tuple(item.contract_signature() for item in spec.layout_elements)
            == tuple(
                item.contract_signature() for item in prototype.layout_elements
            )
            and actual_layout_structure == expected_layout_structure
        )
        placeholder_visual_same = (
            actual_placeholder_visual == expected_placeholder_visual
        )
        reusable_contract_same = (
            placeholder_contract_same
            and layout_contract_same
            and placeholder_visual_same
        )

        reuses_prototype_key = spec.layout_key == prototype.layout_key
        if adherence == "adaptive" and not reuses_prototype_key:
            if spec.layout_name == prototype.layout_name:
                errors.append(
                    f"{spec.svg_path.name}: adaptive template authoring created "
                    f"new layout key {spec.layout_key!r} but reused prototype picker "
                    f"name {prototype.layout_name!r}; assign a new key and name to "
                    "the evolved Layout contract"
                )
            if reusable_contract_same:
                errors.append(
                    f"{spec.svg_path.name}: adaptive template authoring changed "
                    "only the Layout key/name while the reusable static, "
                    "placeholder, and default-bounds contract is unchanged; "
                    f"reuse prototype identity {prototype.layout_key!r} / "
                    f"{prototype.layout_name!r}"
                )
            continue

        missing_bounds = [
            item.element_id
            for item in prototype.placeholders
            if item.placeholder_bounds is None
        ]
        if missing_bounds:
            if adherence == "strict":
                errors.append(
                    f"{reference.svg_path.name}: deferred strict template "
                    "authoring requires explicit data-pptx-bounds "
                    "on every prototype placeholder; missing: "
                    + ", ".join(missing_bounds)
                )
            else:
                errors.append(
                    f"{spec.svg_path.name}: adaptive output reused prototype layout "
                    f"key {prototype.layout_key!r}, but that prototype lacks explicit "
                    "placeholder bounds; assign a new key and name to the evolved "
                    "Layout contract"
                )
            continue
        if spec.layout_key != prototype.layout_key:
            errors.append(
                f"{spec.svg_path.name}: strict template use must keep "
                f"prototype layout key {prototype.layout_key!r}, found "
                f"{spec.layout_key!r}"
            )
        if spec.layout_name != prototype.layout_name:
            if adherence == "strict":
                errors.append(
                    f"{spec.svg_path.name}: strict template use must keep "
                    f"prototype layout name {prototype.layout_name!r}, found "
                    f"{spec.layout_name!r}"
                )
            else:
                errors.append(
                    f"{spec.svg_path.name}: adaptive output reused prototype layout "
                    f"key {prototype.layout_key!r} but changed its picker name from "
                    f"{prototype.layout_name!r} to {spec.layout_name!r}; assign a "
                    "new key and name to the evolved Layout contract"
                )
        if (
            spec.slide_show_inherited_shapes
            != prototype.slide_show_inherited_shapes
        ):
            errors.append(
                f"{spec.svg_path.name}: inherited-shape visibility differs from "
                f"prototype {reference.svg_path.name}; keep root "
                "data-pptx-show-inherited-shapes unchanged"
            )
        if not placeholder_contract_same:
            if adherence == "strict":
                errors.append(
                    f"{spec.svg_path.name}: strict placeholder id/type/index/default-"
                    f"bounds contract differs from prototype "
                    f"{reference.svg_path.name}"
                )
            else:
                errors.append(
                    f"{spec.svg_path.name}: adaptive output reused prototype layout "
                    f"key {prototype.layout_key!r} but changed its placeholder "
                    "contract; assign a new key and name"
                )
        if literal_visual and not placeholder_visual_same:
            difference = _mirror_structure_difference(
                prototype,
                spec,
                prototype.placeholders,
            )
            errors.append(
                f"{spec.svg_path.name}: mirror placeholder geometry or visual "
                f"styling differs from prototype {reference.svg_path.name}; "
                "only visible text content may change under the reused Layout"
                + (f"; first difference: {difference}" if difference else "")
            )
        if not layout_contract_same:
            qualifier = "mirror visual/structural" if literal_visual else "structural"
            difference = _layout_contract_difference(
                spec.layout_elements,
                prototype.layout_elements,
            )
            if literal_visual:
                literal_difference = _mirror_structure_difference(
                    prototype,
                    spec,
                    prototype.layout_elements,
                )
                if literal_difference:
                    difference += f"; first difference: {literal_difference}"
            if adherence == "strict":
                errors.append(
                    f"{spec.svg_path.name}: strict Layout {qualifier} contract "
                    f"differs from prototype {reference.svg_path.name}; {difference}"
                )
            else:
                errors.append(
                    f"{spec.svg_path.name}: adaptive output reused prototype layout "
                    f"key {prototype.layout_key!r} but changed its {qualifier} "
                    f"contract; {difference}; assign a new key and name"
                )
    return errors


_PRESERVE_PLACEHOLDER_TYPE_ORDER = {
    "title": ("title", "ctrTitle"),
    "subtitle": ("subTitle", "body", "obj"),
    "body": ("body", "obj", "subTitle"),
    "picture": ("pic", "obj"),
    "chart": ("chart", "obj"),
    "table": ("tbl", "obj"),
    "object": ("obj",),
    "media": ("media", "obj", "pic"),
    "date": ("dt",),
    "footer": ("ftr",),
    "slide-number": ("sldNum",),
}


def match_native_placeholders(
    spec: TemplateSlideSpec,
    layout: NativeLayoutSpec,
) -> tuple[tuple[TemplateElementSpec, NativePlaceholderSpec], ...]:
    """Match slide placeholder markers to source layout placeholder identities."""
    available = list(layout.placeholders)
    matches: list[tuple[TemplateElementSpec, NativePlaceholderSpec]] = []
    for item in spec.placeholders:
        allowed_types = _PRESERVE_PLACEHOLDER_TYPE_ORDER.get(
            item.placeholder or "",
            (),
        )
        candidate_index = None
        for placeholder_type in allowed_types:
            for index, candidate in enumerate(available):
                if candidate.placeholder_type != placeholder_type:
                    continue
                if (
                    item.placeholder_idx is not None
                    and candidate.effective_idx != item.placeholder_idx
                ):
                    continue
                candidate_index = index
                break
            if candidate_index is not None:
                break
        if candidate_index is None:
            idx_note = (
                f" idx={item.placeholder_idx}"
                if item.placeholder_idx is not None
                else ""
            )
            raise TemplateStructureError(
                f"{spec.svg_path.name}: placeholder {item.element_id!r} "
                f"({item.placeholder}{idx_note}) has no compatible source placeholder "
                f"in layout {layout.key!r}"
            )
        matches.append((item, available.pop(candidate_index)))
    return tuple(matches)


def native_structure_lock_errors(
    specs: list[TemplateSlideSpec],
    structure_lock: PptxStructureLock,
    contract: NativeStructureContract,
) -> list[str]:
    """Return preserve-mode mismatches against the imported source contract."""
    if structure_lock.mode != "preserve":
        return []
    errors: list[str] = []
    references = {item.slide_num: item for item in structure_lock.layouts}
    contract_layouts = {layout.key: layout for layout in contract.layouts}

    for reference in structure_lock.layouts:
        layout = contract_layouts.get(reference.layout_key)
        if layout is None:
            errors.append(
                f"spec_lock.md P{reference.slide_num:02d} references unknown source "
                f"layout key {reference.layout_key!r}"
            )
            continue
        if reference.layout_name and reference.layout_name != layout.name:
            errors.append(
                f"spec_lock.md P{reference.slide_num:02d} layout name "
                f"{reference.layout_name!r} does not match source name {layout.name!r}"
            )

    master_contracts: dict[str, tuple[tuple[object, ...], ...]] = {}
    layout_contracts: dict[str, tuple[tuple[object, ...], ...]] = {}
    for spec in specs:
        reference = references.get(spec.slide_num)
        if reference is None:
            continue
        layout = contract_layouts.get(reference.layout_key)
        if layout is None:
            continue
        master_contract = tuple(
            item.contract_signature() for item in spec.master_elements
        )
        expected_master = master_contracts.setdefault(
            layout.master_key,
            master_contract,
        )
        if master_contract != expected_master:
            errors.append(
                f"{spec.svg_path.name}: preview master layer differs from another "
                f"page using source master {layout.master_key!r}"
            )
        expected_layout = layout_contracts.setdefault(
            layout.key,
            spec.layout_contract,
        )
        if spec.layout_contract != expected_layout:
            errors.append(
                f"{spec.svg_path.name}: preview layout/placeholder contract differs "
                f"from another page using source layout {layout.key!r}"
            )
        try:
            match_native_placeholders(spec, layout)
        except TemplateStructureError as exc:
            errors.append(str(exc))
    return errors


def _placement_lint_errors(svg_path: Path) -> list[str]:
    """Enumerate every placement/paint-order violation in one pass.

    ``parse_template_slide`` fails fast on the first error, which discloses
    violations one whole fix-cycle at a time. The quality checker runs this
    pre-lint first so a single run reports every offender of the two
    highest-frequency classes: structure metadata below the root, and
    template paint-order violations.
    """
    try:
        root = _parse_svg_root(svg_path)
    except (OSError, ET.ParseError, NativePayloadError):
        return []
    if _local_tag(root) != "svg":
        return []
    errors: list[str] = []
    direct_children = set(root)
    allowed_carriers = {
        carrier
        for slot in root
        if (slot.get("data-pptx-placeholder") or "").strip()
        for carrier in slot
        if carrier.get("data-pptx-carrier") is not None
    }
    for elem in root.iter():
        if elem is root or elem in direct_children:
            continue
        attrs = _structure_attrs(elem)
        if elem in allowed_carriers:
            attrs = [
                attr for attr in attrs
                if attr != "data-pptx-carrier"
            ]
        if attrs:
            element_id = elem.get("id") or _local_tag(elem) or "<unnamed>"
            errors.append(
                f"{svg_path.name}: {element_id} uses template metadata below the SVG "
                "root; only a direct slot child may declare its carrier marker"
            )
    try:
        canvas = _svg_canvas(root)
    except CanvasContractError:
        # Root-canvas validation is owned by parse_template_slide and the
        # page Checker; placement lint should not duplicate that diagnosis.
        return errors
    last_order_rank = -1
    for elem in root:
        tag = _local_tag(elem)
        if tag in _NON_VISUAL_TAGS:
            continue
        layer = (elem.get("data-pptx-layer") or "").strip().lower() or None
        if layer not in _LAYERS:
            layer = None
        is_background = _is_full_canvas_solid_rect(elem, canvas, root=root)
        effective_layer = layer or ("slide" if is_background else None)
        if is_background and effective_layer is not None:
            order_rank = {"master": 0, "layout": 1, "slide": 2}[effective_layer]
        elif effective_layer == "master":
            order_rank = 3
        elif effective_layer == "layout":
            order_rank = 4
        else:
            order_rank = 5
        if order_rank < last_order_rank:
            errors.append(
                f"{svg_path.name}: {elem.get('id') or tag} violates template paint "
                "order; use Master background, Layout background, Slide background, "
                "Master shapes, Layout shapes, then Slide content/placeholders. "
                "Full-canvas solid rects are treated as backgrounds; translucent overlays are not backgrounds"
            )
            continue
        last_order_rank = order_rank
    return errors


def validate_template_svg(svg_path: Path) -> list[str]:
    """Return per-file template metadata errors for quality-check integration."""
    errors = _placement_lint_errors(svg_path)
    try:
        parse_template_slide(svg_path, 1)
    except TemplateStructureError as exc:
        message = str(exc)
        if message not in errors:
            errors.append(message)
    return errors
