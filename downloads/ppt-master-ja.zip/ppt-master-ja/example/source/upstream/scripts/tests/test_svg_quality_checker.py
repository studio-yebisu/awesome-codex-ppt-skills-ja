#!/usr/bin/env python3
"""Focused regression tests for SVG text and module-bound checks."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch
from xml.etree import ElementTree as ET


SCRIPTS_DIR = Path(__file__).resolve().parents[1]
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

from svg_quality import checker as checker_module  # noqa: E402
from svg_quality.checker import SVGQualityChecker  # noqa: E402


SVG_NS = 'http://www.w3.org/2000/svg'


def _parse_svg(
    body: str,
    root_attributes: str = '',
    view_box: str = '0 0 1000 1000',
) -> ET.Element:
    return ET.fromstring(
        f'<svg xmlns="{SVG_NS}" viewBox="{view_box}" '
        f'{root_attributes}>{body}</svg>'
    )


def _empty_result() -> dict:
    return {'errors': [], 'warnings': []}


class LeadingInlineRunParagraphTests(unittest.TestCase):
    def test_first_line_opening_with_an_inline_run_is_a_paragraph(self) -> None:
        svg = (
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720">'
            '<text x="460" y="318" font-size="18">'
            '<tspan font-weight="bold">Trigger</tspan> — already chronically absent'
            '<tspan x="460" dy="26"><tspan font-weight="bold">Action</tspan> — case review</tspan>'
            '<tspan x="460" dy="26"><tspan font-weight="bold">Owner</tspan> — coordinator</tspan>'
            '</text></svg>'
        )
        root = ET.fromstring(svg)
        text_el = next(iter(root))
        classified = checker_module._classify_paragraph_block(text_el, preserve_line_breaks=True)
        self.assertIsNotNone(classified)
        _base, _extras, _breaks, line_groups, synthetic_first = classified
        self.assertEqual(len(line_groups), 3)
        self.assertIsNotNone(synthetic_first)


class TextPictureFillReferenceTests(unittest.TestCase):
    def test_text_picture_fill_pattern_image_counts_as_a_rendered_reference(self) -> None:
        svg = (
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720">'
            '<defs>'
            '<pattern id="titleTexture" data-pptx-text-image-fill="stretch" '
            'patternUnits="objectBoundingBox" patternContentUnits="objectBoundingBox" '
            'width="1" height="1">'
            '<image href="../images/title_fill.png" x="0" y="0" width="1" height="1" '
            'preserveAspectRatio="none"/></pattern>'
            '<pattern id="unused" data-pptx-text-image-fill="stretch" '
            'patternUnits="objectBoundingBox" width="1" height="1">'
            '<image href="../images/unused.png" width="1" height="1"/></pattern>'
            '</defs>'
            '<text x="80" y="200" font-size="96" fill="url(#titleTexture)">Title</text>'
            '</svg>'
        )
        root = ET.fromstring(svg)
        images = SVGQualityChecker._text_image_fill_images(root)
        self.assertEqual(
            [image.get('href') for image in images],
            ['../images/title_fill.png'],
        )
        # The generic visible-image scan still ignores <defs>, so the
        # pattern image is a placement only through the text fill path.
        _root, _parents, visible = SVGQualityChecker._visible_image_elements(root)
        self.assertEqual(visible, [])


class SVGQualityCheckerBoundsTests(unittest.TestCase):
    @staticmethod
    def _text_bounds(root: ET.Element, *, include_headroom: bool = False) -> tuple:
        text = root.find(f'.//{{{SVG_NS}}}text')
        parents = {id(child): parent for parent in root.iter() for child in parent}
        sizes = checker_module._resolve_project_font_sizes(root)
        spacings = checker_module._resolve_project_letter_spacings(root, sizes)
        return SVGQualityChecker._estimated_text_bounds(
            text, parents, sizes, spacings, include_headroom=include_headroom,
        )

    def test_inline_dx_triggers_module_and_canvas_overflow_for_each_anchor(self) -> None:
        for anchor, x in (('start', 1200), ('middle', 1200), ('end', 100)):
            with self.subTest(anchor=anchor):
                root = _parse_svg(
                    '<g id="title" data-pptx-bounds="80 70 1190 80">'
                    f'<text x="{x}" y="110" text-anchor="{anchor}" font-size="24">'
                    'A<tspan dx="400">B</tspan></text></g>',
                    'font-family="Arial"', view_box='0 0 1280 720',
                )
                result = _empty_result()
                SVGQualityChecker()._check_text_bounds(root, result)
                self.assertTrue(any('root viewBox on the horizontal axis' in error
                                    for error in result['errors']), result)
                self.assertFalse(any('Cannot verify' in warning for warning in result['warnings']), result)
                root.find(f'.//{{{SVG_NS}}}text').set('x', '600')
                root.find(f'{{{SVG_NS}}}g').set('data-pptx-bounds', '580 70 90 80')
                module_result = _empty_result()
                SVGQualityChecker()._check_text_bounds(root, module_result)
                self.assertTrue(any('data-pptx-bounds on the horizontal axis' in error
                                    for error in module_result['errors']), module_result)

    def test_inline_dx_uses_signed_advances_and_preserves_anchor(self) -> None:
        for anchor in ('start', 'middle', 'end'):
            for headroom in (False, True):
                with self.subTest(anchor=anchor, headroom=headroom):
                    template = (
                        f'<text x="600" y="110" text-anchor="{anchor}" font-size="24">'
                        'A<tspan dx="{dx}">B</tspan></text>'
                    )
                    bounds = {}
                    for dx in (0, 400, -400):
                        root = _parse_svg(template.format(dx=dx), 'font-family="Arial"')
                        bounds[dx] = self._text_bounds(root, include_headroom=headroom)
                        self.assertIsNotNone(bounds[dx])
                    left0, _top, right0, _bottom = bounds[0]
                    left, _top, right, _bottom = bounds[400]
                    self.assertAlmostEqual((right - left) - (right0 - left0), 400)
                    if anchor == 'start':
                        self.assertAlmostEqual(left, 600)
                    elif anchor == 'middle':
                        self.assertAlmostEqual((left + right) / 2, 600)
                    else:
                        self.assertAlmostEqual(right, 600)
                    single = _parse_svg(
                        f'<text x="600" y="110" text-anchor="{anchor}" font-size="24">A</text>',
                        'font-family="Arial"',
                    )
                    self.assertEqual(bounds[-400], self._text_bounds(single, include_headroom=headroom))

    def test_end_anchor_negative_dx_has_no_false_overflow(self) -> None:
        root = _parse_svg(
            '<g id="title" data-pptx-bounds="1100 70 180 80">'
            '<text x="1270" y="110" text-anchor="end" font-size="24">'
            'ABCD<tspan dx="-20">EFGH</tspan></text></g>',
            'font-family="Arial"', view_box='0 0 1280 720',
        )
        result = _empty_result()
        SVGQualityChecker()._check_text_bounds(root, result)
        self.assertEqual(result, _empty_result())

    def test_inline_dx_measures_cjk_links_empty_spans_and_line_start(self) -> None:
        for content in (
            '中<tspan dx="400">文</tspan>',
            'A<a href="https://example.com"><tspan dx="400">B</tspan></a>',
            '<tspan dx="400">B</tspan>',
            '<tspan dx="400"/><tspan>B</tspan>',
            '<tspan dx="250">A<tspan dx="150">B</tspan>C</tspan>D',
        ):
            with self.subTest(content=content):
                root = _parse_svg(
                    f'<text x="1200" y="110" font-size="24">{content}</text>',
                    'font-family="Arial"', view_box='0 0 1280 720',
                )
                bounds = self._text_bounds(root)
                self.assertIsNotNone(bounds)
                self.assertGreater(bounds[2], 1600)
                result = _empty_result()
                SVGQualityChecker()._check_text_bounds(root, result)
                self.assertTrue(any('root viewBox' in error for error in result['errors']), result)

    def test_non_scalar_and_percentage_dx_remain_unmeasurable(self) -> None:
        for dx in ('20%', '10 20', '10,20', 'calc(20 + 30)'):
            with self.subTest(dx=dx):
                root = _parse_svg(
                    f'<text x="1200" y="110" font-size="24">A<tspan dx="{dx}">B</tspan></text>',
                    'font-family="Arial"', view_box='0 0 1280 720',
                )
                self.assertIsNone(self._text_bounds(root))
                result = _empty_result()
                SVGQualityChecker()._check_text_bounds(root, result)
                self.assertTrue(any('Cannot verify root viewBox bounds' in warning
                                    for warning in result['warnings']), result)

    def test_positioned_lines_count_starter_and_inline_dx_once(self) -> None:
        root = _parse_svg(
            '<text x="100" y="110" font-size="24">'
            '<tspan x="100" dx="10">A</tspan><tspan dx="400">B</tspan>'
            '<tspan x="100" dx="-5" dy="30">C</tspan><tspan dx="-20">D</tspan></text>',
            'font-family="Arial"',
        )
        parents = {id(child): parent for parent in root.iter() for child in parent}
        sizes = checker_module._resolve_project_font_sizes(root)
        spacings = checker_module._resolve_project_letter_spacings(root, sizes)
        lines = SVGQualityChecker._resolved_text_lines(root[0], parents, sizes, spacings)
        self.assertIsNotNone(lines)
        self.assertEqual([(line[1], line[2]) for line in lines], [(110, 110), (95, 140)])
        self.assertEqual([
            [run['_inline_dx'] for run in line[3] if '_inline_dx' in run] for line in lines
        ], [[400], [-20]])

    def test_leading_direct_text_and_positioned_tspans_are_estimable(self) -> None:
        root = _parse_svg(
            '<g id="module" data-pptx-bounds="0 0 1000 1000">'
            '<text id="mixed" x="10" y="30" font-size="20">'
            'Leading <tspan font-weight="700">bold</tspan>'
            '<tspan x="10" dy="28">Second line</tspan>'
            '</text></g>'
        )
        text_element = root.find(f'.//{{{SVG_NS}}}text')
        self.assertIsNotNone(text_element)
        parent_by_id = {
            id(child): parent
            for parent in root.iter()
            for child in list(parent)
        }
        font_sizes = checker_module._resolve_project_font_sizes(root)
        letter_spacings = checker_module._resolve_project_letter_spacings(
            root,
            font_sizes,
        )

        lines = SVGQualityChecker._positioned_text_lines(
            text_element,
            parent_by_id,
            font_sizes,
            letter_spacings,
        )

        self.assertIsNotNone(lines)
        self.assertEqual(len(lines), 2)
        self.assertEqual(
            [''.join(run['text'] for run in line[3]) for line in lines],
            ['Leading bold', 'Second line'],
        )
        result = _empty_result()
        SVGQualityChecker()._check_text_bounds(root, result)
        self.assertFalse(
            any('Cannot verify' in warning for warning in result['warnings'])
        )

    def test_existing_all_tspan_and_inline_single_line_forms_still_resolve(self) -> None:
        cases = {
            'all_tspan': (
                '<text x="10" y="30" font-size="20">'
                '<tspan x="10">First</tspan>'
                '<tspan x="10" dy="28">Second</tspan>'
                '</text>',
                2,
            ),
            'single_inline': (
                '<text x="10" y="30" font-size="20">'
                'First <tspan font-weight="700">line</tspan>'
                '</text>',
                1,
            ),
        }
        for name, (text_svg, expected_lines) in cases.items():
            with self.subTest(name=name):
                root = _parse_svg(
                    '<g id="module" data-pptx-bounds="0 0 1000 1000">'
                    f'{text_svg}</g>'
                )
                text_element = root.find(f'.//{{{SVG_NS}}}text')
                parent_by_id = {
                    id(child): parent
                    for parent in root.iter()
                    for child in list(parent)
                }
                font_sizes = checker_module._resolve_project_font_sizes(root)
                letter_spacings = checker_module._resolve_project_letter_spacings(
                    root,
                    font_sizes,
                )
                bounds = SVGQualityChecker._estimated_text_bounds(
                    text_element,
                    parent_by_id,
                    font_sizes,
                    letter_spacings,
                )
                self.assertIsNotNone(bounds)
                if expected_lines == 2:
                    lines = SVGQualityChecker._positioned_text_lines(
                        text_element,
                        parent_by_id,
                        font_sizes,
                        letter_spacings,
                    )
                    self.assertEqual(len(lines), expected_lines)
                else:
                    runs = SVGQualityChecker._resolved_single_line_text_runs(
                        text_element,
                        parent_by_id,
                        font_sizes,
                        letter_spacings,
                    )
                    self.assertIsNotNone(runs)

    def test_module_bounds_use_headroom_but_page_bounds_do_not(self) -> None:
        root = _parse_svg(
            '<g id="module" data-pptx-bounds="0 0 100 100">'
            '<text id="text" x="0" y="20" font-size="12">Text</text>'
            '</g>'
        )
        include_headroom_calls = []

        def estimated_bounds(*_args, include_headroom=True, **_kwargs):
            include_headroom_calls.append(include_headroom)
            right = 106.0 if include_headroom else 100.0
            return (0.0, 0.0, right, 20.0)

        result = _empty_result()
        checker = SVGQualityChecker()
        with patch.object(
            checker,
            '_estimated_text_bounds',
            side_effect=estimated_bounds,
        ):
            checker._check_text_bounds(root, result)

        self.assertEqual(include_headroom_calls, [True, False])
        self.assertTrue(
            any('data-pptx-bounds' in error for error in result['errors'])
        )
        self.assertFalse(
            any('root viewBox' in error for error in result['errors'])
        )

    def test_horizontal_overflow_reports_per_cluster_width_and_capacity(
        self,
    ) -> None:
        cjk_text = '天地玄黄宇宙洪荒日月盈昃辰宿列张寒来暑往秋收冬藏'
        module_root = _parse_svg(
            '<g id="module" data-pptx-bounds="0 0 540 100">'
            f'<text x="0" y="30" font-size="24">{cjk_text}</text>'
            '</g>'
        )
        module_result = _empty_result()
        SVGQualityChecker()._check_text_bounds(module_root, module_result)
        module_error = next(
            error
            for error in module_result['errors']
            if 'data-pptx-bounds on the horizontal axis' in error
        )
        self.assertTrue(
            module_error.endswith(
                '≈25.4 px per CJK char at 24px incl. headroom; '
                '≈21 chars fit in 540 px'
            ),
            module_error,
        )

        page_root = _parse_svg(
            '<g id="module" data-pptx-bounds="0 0 1000 100">'
            f'<text x="0" y="30" font-size="24">{cjk_text}</text>'
            '</g>',
            view_box='0 0 540 100',
        )
        page_result = _empty_result()
        SVGQualityChecker()._check_text_bounds(page_root, page_result)
        page_error = next(
            error
            for error in page_result['errors']
            if 'exceeds the root viewBox on the horizontal axis' in error
        )
        self.assertTrue(
            page_error.endswith(
                '≈24.0 px per CJK char at 24px without headroom; '
                '≈22 chars fit in 540 px'
            ),
            page_error,
        )

    def test_root_module_overlap_is_error_with_minimal_exemptions(self) -> None:
        cases = (
            (
                'overlap_above_tolerance',
                _parse_svg(
                    '<g id="first" data-pptx-bounds="0 0 100 100"/>'
                    '<g id="second" data-pptx-bounds="98.9 0 100 100"/>'
                ),
                True,
            ),
            (
                'overlap_at_tolerance',
                _parse_svg(
                    '<g id="first" data-pptx-bounds="0 0 100 100"/>'
                    '<g id="second" data-pptx-bounds="99 0 100 100"/>'
                ),
                False,
            ),
            (
                'static_page_frame',
                _parse_svg(
                    '<g id="background" data-pptx-role="background" '
                    'data-pptx-bounds="0 0 1000 1000"/>'
                    '<g id="content" data-pptx-bounds="100 100 200 200"/>'
                ),
                False,
            ),
            (
                'structured_slots',
                _parse_svg(
                    '<g id="picture" data-pptx-placeholder="picture" '
                    'data-pptx-bounds="0 0 500 500"/>'
                    '<g id="title" data-pptx-placeholder="title" '
                    'data-pptx-bounds="100 100 300 100"/>',
                    'data-pptx-master="master" '
                    'data-pptx-master-name="Master" '
                    'data-pptx-layout="layout" '
                    'data-pptx-layout-name="Layout"',
                ),
                False,
            ),
            (
                'structured_ordinary_modules',
                _parse_svg(
                    '<g id="first" data-pptx-bounds="0 0 100 100"/>'
                    '<g id="second" data-pptx-bounds="50 0 100 100"/>',
                    'data-pptx-master="master" '
                    'data-pptx-master-name="Master" '
                    'data-pptx-layout="layout" '
                    'data-pptx-layout-name="Layout"',
                ),
                True,
            ),
            (
                'off_canvas_morph_staging',
                _parse_svg(
                    '<g id="morph-a" data-pptx-morph-staging="true" '
                    'data-pptx-bounds="1100 0 100 100"/>'
                    '<g id="morph-b" data-pptx-morph-staging="true" '
                    'data-pptx-bounds="1100 0 100 100"/>'
                ),
                False,
            ),
        )
        checker = SVGQualityChecker()
        for name, root, expects_overlap_error in cases:
            with self.subTest(name=name):
                result = _empty_result()
                checker._check_module_bounds_contract(root, result)
                overlap_errors = [
                    error
                    for error in result['errors']
                    if 'data-pptx-bounds overlaps' in error
                ]
                self.assertEqual(bool(overlap_errors), expects_overlap_error)


if __name__ == '__main__':
    unittest.main()


class NoCropStretchMeasurementTests(unittest.TestCase):
    def test_nested_crop_frame_geometry_and_measured_deviation(self) -> None:
        root = ET.fromstring(
            '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720">'
            '<svg x="140" y="60" width="180" height="180" '
            'viewBox="0.6 0.3 0.24 0.16" preserveAspectRatio="none" '
            'overflow="hidden">'
            '<image href="../images/tree.jpg" x="0" y="0" width="1" height="1" '
            'preserveAspectRatio="none"/></svg>'
            '<image href="../images/tree.jpg" x="0" y="0" width="405" '
            'height="720" preserveAspectRatio="none"/>'
            '</svg>'
        )
        parent_by_id = {
            id(child): parent for parent in root.iter() for child in list(parent)
        }
        images = list(root.iter('{http://www.w3.org/2000/svg}image'))
        nested = SVGQualityChecker._image_frame_geometry(images[0], root, parent_by_id)
        plain = SVGQualityChecker._image_frame_geometry(images[1], root, parent_by_id)
        self.assertEqual(nested, (180.0, 180.0, 0.24, 0.16))
        self.assertEqual(plain, (405.0, 720.0, 1.0, 1.0))
        # A 900x1600 source: the 0.24x0.16 crop is 216x256 px, so a square
        # frame distorts it, while the plain 405x720 frame keeps 9:16 exactly.
        self.assertGreater(
            SVGQualityChecker._stretch_deviation(nested, (900, 1600)), 0.1
        )
        self.assertAlmostEqual(
            SVGQualityChecker._stretch_deviation(plain, (900, 1600)), 0.0
        )
        self.assertIsNone(SVGQualityChecker._stretch_deviation(nested, None))
