param([switch]$Render)
$ErrorActionPreference = "Stop"
$taskRoot = Join-Path $PSScriptRoot "workspace"
Push-Location -LiteralPath $taskRoot
try {
    & python -m venv .build/ppt-master-venv
    if ($LASTEXITCODE) { throw "Python environment failed" }
    $taskPy = Join-Path $taskRoot ".build/ppt-master-venv/Scripts/python.exe"
    & $taskPy -m pip install -r requirements-reproduce.txt
    if ($LASTEXITCODE) { throw "Python dependencies failed" }
    & npm --prefix examples/repositories/cyberppt/source ci --ignore-scripts
    if ($LASTEXITCODE) { throw "CyberPPT Node dependencies failed" }
    & $taskPy examples/repositories/cyberppt/source/reproduce.py --input examples/repositories/cyberppt/input/data.json --render
    if ($LASTEXITCODE) { throw "Generation failed" }
    & $taskPy tools/mark_reproduced.py
    Write-Host "Generated: $taskRoot/examples/repositories/cyberppt"
    Write-Host "Open the actual output and review all pages before using it."
} finally { Pop-Location }
