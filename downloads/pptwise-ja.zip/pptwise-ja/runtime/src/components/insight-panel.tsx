import { markedLineSegments, paintMarkedLine, stripEmphasis } from "../render/emphasis"
import { cardGround, HAIRLINE, hairlineInk, isRuled } from "./surfaces"
import type { Component } from "@/ir"
import { fitSvgLine, layoutSvgText, measureTextUnits } from "../lib/svg-text-layout"
import { accessibleInk, graphicInk } from "../render/ink"
import { Icon } from "../render/icons"
import { formTextClipMarker } from "./legibility"
import type { RenderDef, SvgComponent } from "./types"

type InsightPanelComponent = Extract<Component, { type: "insight_panel" }>

/**
 * 带标题的策略/观点面板（2026-07-14 用户 showcase deck 借鉴，取代手绘补
 * 页）：圆角面板 + accent 字重标题 + 若干 `label / 描述` 行 + 可选贴底脚
 * 注。常作 aside 侧栏块与数据并置。**全文实测**决定面板高度，脚注恒在卡
 * 内（修手绘脚本假设固定行数导致的溢出）。
 */
const PAD_X = 22
const PAD_TOP = 20
const PAD_BOTTOM = 18
const CARD_RADIUS = 10

const TITLE_SIZE = 17
const TITLE_LH = Math.round(TITLE_SIZE * 1.4)
const GAP_TITLE_ROWS = 18

const LABEL_SIZE = 16
const TEXT_SIZE = 16
const TEXT_LH = Math.round(TEXT_SIZE * 1.45)
const ROW_GAP = 16
const LABEL_COL_MIN = 56

const FOOT_SIZE = 16
const GAP_ROWS_FOOT = 16

/** The panel's icon stands before its title, on the title's line, and the title moves right of it. */
const ICON_SIZE = 20
const ICON_GAP = 8
const ICON_SHIFT = ICON_SIZE + ICON_GAP

/**
 * `truncated` travels with the wrapped text on both fields below. The panel
 * caps a row at three lines and its footnote at two, so long copy is cut;
 * the flag was dropped on the floor here, and the cut reached the page with
 * no `data-truncated` on it — invisible to the audit and to the content
 * scan alike.
 */
interface WrappedText {
  lines: string[]
  fontSize: number
  lineHeight: number
  truncated: boolean
}
interface RowLayout {
  label: { text: string; fontSize: number; truncated: boolean }
  text: WrappedText
  height: number
}
interface PanelLayout {
  title: { text: string; fontSize: number; truncated: boolean }
  rows: RowLayout[]
  labelColW: number
  foot: WrappedText | null
  contentH: number
}

// `fontFamily` (bold-metrics fix, round 2, 2026-07-24): `title`/`label`
// both render `fontWeight="700"` below (`title` in `ctx.fonts.heading`,
// `label` in `ctx.fonts.body`) -- bold-aware fitting needed for both,
// same as every other bold heading-faced text this task's audit-baseline
// sweep found and fixed. Both params optional/default `undefined`
// (envelope fallback) -- `measure()` never reads either fitted result,
// only `contentH`, itself derived from fixed constants (`TITLE_LH`/
// `TEXT_LH`), never `title.fontSize`/`label.fontSize` -- so measure/render
// can't disagree regardless of which callers pass a real value.
function panelLayout(
  component: InsightPanelComponent,
  w: number,
  headingFontFamily?: string,
  bodyFontFamily?: string,
): PanelLayout {
  const contentW = w - PAD_X * 2
  const title = fitSvgLine(stripEmphasis(component.title), {
    maxWidth: contentW - (component.icon ? ICON_SHIFT : 0),
    fontSize: TITLE_SIZE,
    minFontSize: 16,
    bold: true,
    fontFamily: headingFontFamily,
  })
  const labelColW = Math.min(
    Math.max(LABEL_COL_MIN, Math.max(...component.rows.map((r) => measureTextUnits(r.label) * LABEL_SIZE)) + 14),
    Math.round(contentW * 0.4),
  )
  const textW = Math.max(60, contentW - labelColW)
  const rows: RowLayout[] = component.rows.map((r) => {
    const label = fitSvgLine(r.label, {
      maxWidth: labelColW,
      fontSize: LABEL_SIZE,
      minFontSize: 16,
      bold: true,
      fontFamily: bodyFontFamily,
    })
    const text = layoutSvgText(r.text, {
      maxWidth: textW,
      fontSize: TEXT_SIZE,
      maxLines: 3,
      lineHeightRatio: 1.45,
    })
    return { label, text, height: Math.max(TEXT_LH, text.lines.length * text.lineHeight) }
  })
  const foot = component.footnote
    ? layoutSvgText(component.footnote, {
        maxWidth: contentW,
        fontSize: FOOT_SIZE,
        maxLines: 2,
        lineHeightRatio: 1.4,
      })
    : null
  const rowsH = rows.reduce((s, r) => s + r.height, 0) + Math.max(0, rows.length - 1) * ROW_GAP
  const contentH =
    PAD_TOP +
    TITLE_LH +
    GAP_TITLE_ROWS +
    rowsH +
    (foot ? GAP_ROWS_FOOT + foot.lines.length * foot.lineHeight : 0) +
    PAD_BOTTOM
  return { title, rows, labelColW, foot, contentH }
}

export const insightPanel: SvgComponent<InsightPanelComponent> = {
  measure(component, w) {
    return panelLayout(component, w).contentH
  },
  render(component, box, ctx) {
    const layout = panelLayout(component, box.w, ctx.fonts.heading, ctx.fonts.body)
    const r = ctx.shape?.radius ?? CARD_RADIUS
    // 面板高度取实测与分配的较大者——脚注按内容实测底定位，恒在卡内。
    const panelH = Math.max(layout.contentH, box.h ?? layout.contentH)
    const titleBaseline = box.y + PAD_TOP + TITLE_SIZE
    // Rows open below the title's full line box, the same rhythm row_cards
    // uses (`contentTop + TITLE_LH + GAP_TITLE_NEXT`) and the same budget
    // `panelLayout` above already spends on `contentH`. Advancing from the
    // title's *baseline* instead spent 7px less than the panel had reserved,
    // which both crowded the first row against the title and left the block
    // floating short of the shell it was measured into.
    let rowY = box.y + PAD_TOP + TITLE_LH + GAP_TITLE_ROWS
    // Ruled: no panel. The insight is set on the paper between two hairlines.
    const ruled = isRuled(ctx)
    const ground = cardGround(ctx)
    return (
      <g>
        {ruled ? (
          <>
            <line x1={box.x} y1={box.y + HAIRLINE / 2} x2={box.x + box.w} y2={box.y + HAIRLINE / 2} stroke={hairlineInk(ctx)} strokeWidth={HAIRLINE} />
            <line x1={box.x} y1={box.y + panelH - HAIRLINE / 2} x2={box.x + box.w} y2={box.y + panelH - HAIRLINE / 2} stroke={hairlineInk(ctx)} strokeWidth={HAIRLINE} />
          </>
        ) : (
          <rect
            x={box.x}
            y={box.y}
            width={box.w}
            height={panelH}
            rx={r}
            fill={ctx.colors.surface}
            {...(ctx.colors.cardStroke ? { stroke: ctx.colors.cardStroke, strokeWidth: 1 } : {})}
          />
        )}
        {component.icon ? (
          <Icon
            name={component.icon}
            x={box.x + PAD_X}
            y={titleBaseline - TITLE_SIZE * 0.85 - (ICON_SIZE - TITLE_SIZE) / 2}
            size={ICON_SIZE}
            color={graphicInk(ctx.colors.accent, ground)}
          />
        ) : null}
        {paintMarkedLine(
          ctx,
          markedLineSegments(component.title, [layout.title.text])[0]!,
          { baseFill: accessibleInk(ctx.colors.accent, ground, layout.title.fontSize), fontWeight: "700", fontFamily: ctx.fonts.heading, bg: ground },
          <text
            data-truncated={layout.title.truncated ? "1" : undefined}
            x={box.x + PAD_X + (component.icon ? ICON_SHIFT : 0)}
            y={titleBaseline}
            fontSize={layout.title.fontSize}
            fontWeight="700"
            fill={accessibleInk(ctx.colors.accent, ground, layout.title.fontSize)}
            fontFamily={ctx.fonts.heading}
            dominantBaseline="alphabetic"
          >
            {layout.title.text}
          </text>,
        )}
        {layout.rows.map((row, ri) => {
          const rowTop = rowY
          rowY += row.height + ROW_GAP
          return (
            <g key={ri}>
              <text
                data-truncated={row.label.truncated ? "1" : undefined}
                x={box.x + PAD_X}
                y={rowTop + LABEL_SIZE}
                fontSize={row.label.fontSize}
                fontWeight="700"
                fill={ctx.colors.text}
                fontFamily={ctx.fonts.body}
                dominantBaseline="alphabetic"
              >
                {row.label.text}
              </text>
              {row.text.lines.map((line, li) => (
                <text
                  key={li}
                  data-truncated={formTextClipMarker(row.text, li)}
                  x={box.x + PAD_X + layout.labelColW}
                  y={rowTop + TEXT_SIZE + li * row.text.lineHeight}
                  fontSize={row.text.fontSize}
                  fill={ctx.colors.text}
                  fontFamily={ctx.fonts.body}
                  dominantBaseline="alphabetic"
                >
                  {line}
                </text>
              ))}
            </g>
          )
        })}
        {layout.foot
          ? layout.foot.lines.map((line, li) => (
              <text
                key={`f${li}`}
                data-truncated={formTextClipMarker(layout.foot!, li)}
                x={box.x + PAD_X}
                y={box.y + panelH - PAD_BOTTOM - (layout.foot!.lines.length - 1 - li) * layout.foot!.lineHeight - 2}
                fontSize={FOOT_SIZE}
                fill={ctx.colors.muted}
                fontFamily={ctx.fonts.body}
                dominantBaseline="alphabetic"
              >
                {line}
              </text>
            ))
          : null}
      </g>
    )
  },
}

export const renderDef: RenderDef<InsightPanelComponent> = { type: "insight_panel", measure: insightPanel.measure, render: insightPanel.render }
