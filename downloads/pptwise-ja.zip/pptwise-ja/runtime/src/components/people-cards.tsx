import type React from "react"
import type { Component } from "@/ir"
import { fitSvgLine, layoutSvgText, truncateToUnits } from "../lib/svg-text-layout"
import { DroppedContentMarker } from "../render/drop-marker"
import { accessibleInk, readableOn } from "../render/ink"
import { anyCut } from "./declared-fit"
import { deriveInitials } from "./people-initials"
import { HAIRLINE, hairlineInk, isRuled, markInk, paperOf } from "./surfaces"
import type { ComponentCtx, RenderDef, SvgComponent } from "./types"

type PeopleCardsComponent = Extract<Component, { type: "people_cards" }>
type PersonItem = PeopleCardsComponent["people"][number]

/**
 * Equal-weight people-card grid (people_cards wave, `.issues/
 * 2026-08-05-component-waves/plan-people-cards.md`): a team roster/speaker
 * lineup/panel/author list, each person an initials badge (no photo
 * needed) + name + optional role/org. Reuses row-cards.tsx/icon-cards.tsx's
 * own scaling technique verbatim (裁定 3 — no new mechanism): `fitSvgLine`
 * shrink-then-truncate for single lines, `layoutSvgText` wrap-then-
 * truncate for the up-to-2-line role, the tallest card in the set wins
 * `cardH` (`icon-cards.tsx`'s `cardGeometry`), and box.h density-stretch
 * grows every card evenly (`STRETCHABLE_TYPES`, same posture as
 * row_cards/icon_cards).
 */
// Sizing constants are deliberately compact — chosen so that even the
// schema-maximum 12-person, 3-row tier stays comfortably inside the
// tightest real content-rect budget this codebase's own layouts grant a
// single component (`content-tone-adaptive-content.tsx`'s `contentH = 420`
// with a footnote present is the tightest observed), verified empirically
// against `stress-fixtures.ts`'s own `people_cards` pathological entry
// (12 people, every field at CJK_LONG length) across all 16 themes in
// `audit-baseline.test.ts` — not merely eyeballed. A generous, larger set
// of constants was tried first and overflowed the tightest layouts at
// n=12; unlike flowchart.tsx/cycle.tsx's own self-bounding proportional
// `fitScale`, this component uses one fixed compact profile rather than a
// dynamic scale factor (裁定 3 — no new mechanism: `fitSvgLine`/
// `layoutSvgText`'s own shrink-then-truncate already absorbs most of the
// per-tier size pressure as `contentW` narrows with more columns; these
// constants only needed to shrink the *fixed* per-card cost — badge/
// padding/gaps — that doesn't already shrink with width).
const GAP = 16
const CARD_RADIUS = 8
const PAD_X = 14
const PAD_TOP = 12
const PAD_BOTTOM = 10

const BADGE_R = 16
const BADGE_D = BADGE_R * 2
const BADGE_FONT_SIZE = 16
// Same "cy + round(fontSize * 0.32)" single-line vertical-centering trick
// as steps.tsx's own numbered badge (that file's BASELINE_FUDGE_RATIO
// comment) — lands the initials' baseline visually centered on the
// badge's cy.
const BASELINE_FUDGE_RATIO = 0.32

const GAP_BADGE_NAME = 6
const NAME_FONT_SIZE = 16
const NAME_MIN_FONT_SIZE = 16
const NAME_LINE_HEIGHT_RATIO = 1.25
const NAME_LINE_HEIGHT = Math.round(NAME_FONT_SIZE * NAME_LINE_HEIGHT_RATIO)

const GAP_NAME_ROLE = 2
const ROLE_FONT_SIZE = 16
const ROLE_LINE_HEIGHT_RATIO = 1.3

const GAP_ROLE_ORG = 2
const ORG_FONT_SIZE = 16
const ORG_MIN_FONT_SIZE = 16
const ORG_LINE_HEIGHT_RATIO = 1.25
const ORG_LINE_HEIGHT = Math.round(ORG_FONT_SIZE * ORG_LINE_HEIGHT_RATIO)

/**
 * Lines each field may wrap onto before its last line is cut. The type is
 * already at the floor, so a card too narrow for a name used to cut the
 * name short ("Yanqing" for Yanqing Chen, "萤火乡村阅读" for a foundation
 * whose name runs two characters longer). A name or an affiliation now
 * wraps like the role always did, and a three-word title such as Chief
 * Technology Officer gets the third line it needs. The card measures the
 * lines it really draws. A grid that grows too tall for its slot, or holds a
 * word too long even for these lines, declines, and the page steps aside
 * for one that can hold it rather than keep a card that says less than the
 * author wrote.
 */
const NAME_MAX_LINES = 2
const ROLE_MAX_LINES = 3
const ORG_MAX_LINES = 2

// Optional overall `title` (裁定 1: "可选整体 title 按惯例") — same posture
// as cycle.tsx's own optional title: a fixed band reserved above the card
// grid, present in both measure() and render() only when the field is set
// (an absent title costs nothing, no dead band).
const TITLE_FONT_SIZE = 16
const TITLE_MIN_FONT_SIZE = 16
// Raised from 24 on 2026-08-15, back when the title's baseline sat at
// TITLE_FONT_SIZE (round 4 hung it off the band's bottom edge instead —
// see TITLE_TOP_PAD). A 24px band left barely 4px between the title's
// descenders and the top of the first card — the visual review read the
// two as one glued block ("标题距离卡片太近了，没有呼吸感"). 36 leaves the
// title its own line of air, the same relationship cycle.tsx's band
// already has at its larger type size.
//
// 36 is the *natural* band — what `measure()` reserves. It stopped being
// enough as soon as the layout stretched the cards: `box.h` growth used to
// go entirely into the card shells, which split it into top and bottom
// padding, so a page with 163px of leftover gave every card ~40px of extra
// internal air while the band stayed at 36 and the title's own clearance
// stayed at 20. The 2026-08-19 review read the result as "标题贴卡片" — a
// relative measurement: the tightest air on the page was directly under the
// title, at a third of what the cards had inside them. So the band takes a
// share of that growth too (see `TITLE_BAND_GROW_SHARE` at the render site).
const TITLE_BAND = 36
/** Share of the density-stretch increment that widens the title's band
 * rather than the card shells, so the title gets air of its own as the
 * cards' internal padding grows instead of staying frozen. The extra band
 * lands under the title (see `TITLE_TOP_PAD`). */
const TITLE_BAND_GROW_SHARE = 0.25
/** Ceiling on that widening — past this the title stops reading as a label
 * on the grid below it and starts floating on its own. */
const TITLE_BAND_MAX_GROW = 16
/**
 * Top padding inside the title band. The title hangs off the *top* of the
 * band so leftover height from a density stretch lands between the label
 * and the cards (gallery review 2026-08-22: "标题贴卡片"). Hanging it off
 * the bottom put that growth above the label instead, which left the
 * title-to-card gap frozen at 12px.
 */
const TITLE_TOP_PAD = 4

interface WrappedField {
  lines: string[]
  fontSize: number
  lineHeight: number
  truncated: boolean
}

interface PersonCardLayout {
  name: WrappedField
  role: WrappedField | null
  org: WrappedField | null
}

/** Fit a person's name/role/org within `contentW` — same technique as
 * icon-cards.tsx's `layoutIconCard`/steps.tsx's `layoutStepItem`: name
 * shrink-then-truncate (never wraps), role wrap-then-truncate (up to 2
 * lines, with the same defensive post-wrap `truncateToUnits` those two
 * files apply for the case `layoutSvgText`'s own font-shrink floors out
 * before the merged tail line actually fits), org shrink-then-truncate
 * (a second single line, smaller and lower-priority than name). */
function layoutPersonCard(person: PersonItem, contentW: number): PersonCardLayout {
  // A short name or affiliation keeps its one line at the full size, the
  // same line `fitSvgLine` used to give it. Only one too wide for the card
  // wraps, balanced so a seven-character name does not leave one character
  // alone on its second line.
  const name = layoutSvgText(person.name, {
    maxWidth: contentW,
    fontSize: NAME_FONT_SIZE,
    maxLines: NAME_MAX_LINES,
    lineHeightRatio: NAME_LINE_HEIGHT_RATIO,
    minPt: NAME_MIN_FONT_SIZE,
    bold: true,
    balanceLines: true,
  })
  const role = person.role
    ? (() => {
        const wrapped = layoutSvgText(person.role, {
          maxWidth: contentW,
          fontSize: ROLE_FONT_SIZE,
          maxLines: ROLE_MAX_LINES,
          lineHeightRatio: ROLE_LINE_HEIGHT_RATIO,
        })
        const maxUnits = contentW / wrapped.fontSize
        const lines = wrapped.lines.map((line) => truncateToUnits(line, maxUnits))
        return { ...wrapped, lines, truncated: wrapped.truncated || lines.some((line, li) => line !== wrapped.lines[li]) }
      })()
    : null
  const org = person.org
    ? layoutSvgText(person.org, {
        maxWidth: contentW,
        fontSize: ORG_FONT_SIZE,
        maxLines: ORG_MAX_LINES,
        lineHeightRatio: ORG_LINE_HEIGHT_RATIO,
        minPt: ORG_MIN_FONT_SIZE,
        balanceLines: true,
      })
    : null
  return { name, role, org }
}

/** Pure content height (badge + gaps + name's line + role's 1-2 lines +
 * org's line) — excludes PAD_TOP/PAD_BOTTOM, mirroring icon-cards.tsx's
 * `iconCardContentHeight`/steps.tsx's `stepContentHeight` split. */
function personCardContentHeight(person: PersonItem, contentW: number): number {
  const { name, role, org } = layoutPersonCard(person, contentW)
  return (
    BADGE_D +
    GAP_BADGE_NAME +
    name.lines.length * NAME_LINE_HEIGHT +
    (role ? GAP_NAME_ROLE + role.lines.length * role.lineHeight : 0) +
    (org ? GAP_ROLE_ORG + org.lines.length * ORG_LINE_HEIGHT : 0)
  )
}

/**
 * Grid tiers by person count (裁定 3, BINDING): 2-4 people single row,
 * 5-8 two rows, 9-12 three rows — measured against a 1280x720 slide's real
 * content width, verified zero-overflow for the 12-person + long-CJK-name
 * + long-role pathological fixture across all 16 themes
 * (`stress-fixtures.ts`'s own `people_cards` entry,
 * `audit-baseline.test.ts`). Columns per row = ceil(n / rows), same
 * "row-major grid, last row left-aligned if underfull" geometry as
 * icon-cards.tsx's `cardGeometry` — no new mechanism.
 */
function tierRows(n: number): number {
  if (n <= 4) return 1
  if (n <= 8) return 2
  return 3
}

function cardGeometry(component: PeopleCardsComponent, w: number) {
  const n = component.people.length
  const rows = tierRows(n)
  const cols = Math.ceil(n / rows)
  const cardW = (w - GAP * (cols - 1)) / cols
  const contentW = Math.max(1, cardW - PAD_X * 2)
  const cardH = Math.max(
    ...component.people.map((p) => PAD_TOP + personCardContentHeight(p, contentW) + PAD_BOTTOM),
  )
  return { rows, cols, cardW, contentW, cardH }
}

/**
 * Initials badge — fill color is `ctx.colors.chartPalette[i % length]`,
 * `i` the person's own *list index* (裁定 2: deterministic, seed-
 * independent — list order is visual order). Deliberately does not read
 * `ctx.chartPaletteOffset` (chart.tsx's own seed-derived rotation seam;
 * see chart-palette.ts's header on why every *other* `chartPalette` reader
 * stays unrotated) — a roster's badge colors shouldn't drift with the
 * deck's seed the way a chart series color intentionally does.
 *
 * Ink is `readableOn(fill)` computed against *this exact fill*, not a
 * fixed "#FFFFFF" preference (unlike steps.tsx's `accessibleInk("#FFFFFF",
 * ...)`, which keeps white when it already clears the ratio) — theme
 * chartPalettes range from near-white (e.g. bulletin's `#C9D3E8`) to
 * near-black (e.g. runway's `#0A0A0A`), so a single assumed preference
 * would fail contrast on roughly half of any given theme's palette
 * entries. Always resolving per-entry is the correct, not merely
 * simpler, choice here.
 */
function renderBadge(
  cx: number,
  cy: number,
  initials: string,
  fill: string,
  ctx: ComponentCtx,
): React.ReactElement {
  // Ruled: a ring round the initials, both in the muted ink, as
  // a printed roster marks a face it has no photograph for. The palette
  // colour that told the badges apart has nothing to fill.
  const ruled = isRuled(ctx)
  const ink = ruled ? accessibleInk(ctx.colors.muted, paperOf(ctx), BADGE_FONT_SIZE) : readableOn(fill)
  return (
    <>
      {ruled ? (
        <circle cx={cx} cy={cy} r={BADGE_R - HAIRLINE / 2} fill="none" stroke={markInk(ctx)} strokeWidth={HAIRLINE} />
      ) : (
        <circle cx={cx} cy={cy} r={BADGE_R} fill={fill} />
      )}
      <text
        x={cx}
        y={cy + Math.round(BADGE_FONT_SIZE * BASELINE_FUDGE_RATIO)}
        textAnchor="middle"
        fontSize={BADGE_FONT_SIZE}
        fontWeight="700"
        fill={ink}
        fontFamily={ctx.fonts.body}
        dominantBaseline="alphabetic"
      >
        {initials}
      </text>
    </>
  )
}

export const peopleCards: SvgComponent<PeopleCardsComponent> = {
  measure(component, w) {
    const { rows, cardH } = cardGeometry(component, w)
    const titleBand = component.title?.trim() ? TITLE_BAND : 0
    return titleBand + rows * cardH + (rows - 1) * GAP
  },
  render(component, box, ctx) {
    const { cols, rows, cardW, contentW, cardH } = cardGeometry(component, box.w)
    const hasTitle = !!component.title?.trim()
    const titleBand = hasTitle ? TITLE_BAND : 0
    // 密度拉伸（box.h 由布局分配）：每行卡壳均分增量，内容组垂直居中——同
    // icon-cards.tsx render() 的 perRowGrow/contentShift 写法。增量先按
    // TITLE_BAND_GROW_SHARE 切一小块给 title band（有 title 时），其余才进
    // 卡壳池：band 曾是纯固定预留，卡片越长它越显得贴。
    const measuredH = titleBand + rows * cardH + (rows - 1) * GAP
    // A person's name or affiliation with characters cut off is somebody
    // else's, and a budget shorter than the grid measures would cut lines
    // off the bottom of the cards. Either way the grid declines rather than
    // print less than the author wrote, and the face steps aside for a page
    // with the room to draw every card whole (`./declared-fit.ts`).
    const layouts = component.people.map((person) => layoutPersonCard(person, contentW))
    if (
      anyCut(layouts.flatMap(({ name, role, org }) => [name, role, org])) ||
      (box.h != null && box.h + 1 < measuredH)
    ) {
      return <DroppedContentMarker count={component.people.length} kind="card" />
    }
    const grow = Math.max(0, (box.h ?? measuredH) - measuredH)
    const bandGrow = hasTitle
      ? Math.min(grow * TITLE_BAND_GROW_SHARE, TITLE_BAND_MAX_GROW)
      : 0
    const grownTitleBand = titleBand + bandGrow
    const perRowGrow = (grow - bandGrow) / rows
    const budgetH = box.h ?? measuredH
    const rowBudget =
      rows > 0 ? Math.max(1, (budgetH - grownTitleBand - Math.max(0, rows - 1) * GAP) / rows) : cardH
    const shellH = Math.min(cardH + perRowGrow, rowBudget)
    const contentShift = Math.max(0, (shellH - cardH) / 2)
    const palette = ctx.colors.chartPalette
    // Ruled: no card, a hairline over each person (`./surfaces.ts`).
    const ruled = isRuled(ctx)
    return (
      <g transform={`translate(${box.x},${box.y})`}>
        {hasTitle &&
          (() => {
            const title = fitSvgLine(component.title!, {
              maxWidth: box.w,
              fontSize: TITLE_FONT_SIZE,
              minFontSize: TITLE_MIN_FONT_SIZE,
              bold: true,
              fontFamily: ctx.fonts.heading,
            })
            // Hung off the top of the band so leftover height widens the
            // title-to-card gap (gallery review 2026-08-22) instead of
            // piling up above the label while the cards stay glued.
            const baselineY = TITLE_TOP_PAD + title.fontSize
            return (
              <text
                data-truncated={title.truncated ? "1" : undefined}
                x={0}
                y={baselineY}
                fontFamily={ctx.fonts.heading}
                fontSize={title.fontSize}
                fontWeight="700"
                fill={ctx.colors.text}
                dominantBaseline="alphabetic"
              >
                {title.text}
              </text>
            )
          })()}
        {component.people.map((person, i) => {
          const cardX = (i % cols) * (cardW + GAP)
          const cardY = grownTitleBand + Math.floor(i / cols) * (shellH + GAP)
          const { name, role, org } = layouts[i]!
          const badgeCx = cardX + cardW / 2
          const badgeCy = cardY + PAD_TOP + contentShift + BADGE_R
          const nameTopY = badgeCy + BADGE_R + GAP_BADGE_NAME
          const nameBaselineY = nameTopY + NAME_FONT_SIZE
          let cursorY = nameTopY + name.lines.length * NAME_LINE_HEIGHT
          const roleTopY = cursorY + (role ? GAP_NAME_ROLE : 0)
          const shellBottom = cardY + shellH - 2
          const roleLines = role
            ? role.lines.filter((_, li) => roleTopY + li * role.lineHeight + role.fontSize <= shellBottom)
            : []
          if (role) cursorY = roleTopY + roleLines.length * role.lineHeight
          const orgBaselineY = cursorY + (org ? GAP_ROLE_ORG : 0) + (org ? org.fontSize : 0)
          const orgLines = org
            ? org.lines.filter((_, li) => orgBaselineY + li * ORG_LINE_HEIGHT <= shellBottom)
            : []
          const fill = palette.length > 0 ? palette[i % palette.length] : ctx.colors.primary
          return (
            <g key={i} data-audit-box={`${cardX},${cardY},${cardW}`}>
              {ruled ? (
                <line x1={cardX} y1={cardY + HAIRLINE / 2} x2={cardX + cardW} y2={cardY + HAIRLINE / 2} stroke={hairlineInk(ctx)} strokeWidth={HAIRLINE} />
              ) : (
                <rect
                  x={cardX}
                  y={cardY}
                  width={cardW}
                  height={shellH}
                  rx={ctx.shape?.radius ?? CARD_RADIUS}
                  fill={ctx.colors.surface}
                  {...(ctx.colors.cardStroke
                    ? { stroke: ctx.colors.cardStroke, strokeWidth: 1 }
                    : {})}
                />
              )}
              {renderBadge(badgeCx, badgeCy, deriveInitials(person.name), fill, ctx)}
              {name.lines.map((line, li) => (
                <text
                  key={`name-${li}`}
                  data-truncated={name.truncated ? "1" : undefined}
                  x={badgeCx}
                  y={nameBaselineY + li * NAME_LINE_HEIGHT}
                  textAnchor="middle"
                  fontSize={name.fontSize}
                  fontWeight="700"
                  fill={ctx.colors.text}
                  fontFamily={ctx.fonts.heading}
                  dominantBaseline="alphabetic"
                >
                  {line}
                </text>
              ))}
              {role
                ? roleLines.map((line, li) => (
                    <text
                      key={li}
                      data-truncated={role.truncated || roleLines.length < role.lines.length ? "1" : undefined}
                      x={badgeCx}
                      y={roleTopY + li * role.lineHeight + role.fontSize}
                      textAnchor="middle"
                      fontSize={role.fontSize}
                      fill={ctx.colors.muted}
                      fontFamily={ctx.fonts.body}
                      dominantBaseline="alphabetic"
                    >
                      {line}
                    </text>
                  ))
                : null}
              {org
                ? orgLines.map((line, li) => (
                    <text
                      key={`org-${li}`}
                      data-truncated={org.truncated || orgLines.length < org.lines.length ? "1" : undefined}
                      x={badgeCx}
                      y={orgBaselineY + li * ORG_LINE_HEIGHT}
                      textAnchor="middle"
                      fontSize={org.fontSize}
                      fill={ctx.colors.muted}
                      fontFamily={ctx.fonts.body}
                      dominantBaseline="alphabetic"
                    >
                      {line}
                    </text>
                  ))
                : null}
            </g>
          )
        })}
      </g>
    )
  },
}

export const renderDef: RenderDef<PeopleCardsComponent> = {
  type: "people_cards",
  measure: peopleCards.measure,
  render: peopleCards.render,
}
