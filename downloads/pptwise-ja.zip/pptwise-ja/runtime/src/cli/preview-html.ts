/**
 * Pure string builder for `pptwise preview --html`'s self-contained review
 * bundle (v0.3 W7 task 1, spec §7 workflow ⑤): one `preview.html` with every
 * slide's already-rendered SVG (`renderSlideSvg`, `../api.ts`) inlined
 * directly into the markup, a bottom thumbnail filmstrip, keyboard (←/→) and
 * click navigation, and a page counter. No `fs` here on purpose — this
 * module only assembles a string; `runPreview` (`./commands.ts`) is the only
 * caller and the only place that touches disk, which keeps this file
 * trivially unit-testable (feed it slide data, assert on the returned
 * string) despite living under the Node-only `src/cli*` tree (AGENTS.md's
 * "no Node-only deps" layout rule is about `src/index.ts`'s own dependency
 * closure, not every file under `src/cli` — this one just happens to need
 * none anyway).
 *
 * Self-containment (the plan's hard requirement): every slide's SVG is
 * embedded as raw markup — never `<img src>`, never any other reference to
 * an external file — and the only CSS/JS in the document is inlined in
 * `<style>`/`<script>`. Local image assets are already `data:` URIs by the
 * time `runPreview` calls `renderSlideSvg` (`resolveLocalAssets`'s job,
 * `./load-ir.ts` — this module never touches assets itself) — *assuming*
 * every image asset the deck references is local or already a `data:` URI.
 * Known limitation: `resolveLocalAssets` deliberately passes a remote
 * `http(s):` asset `src` through untouched (the export pipeline inlines
 * those itself), so that src is left un-inlined and lands verbatim in this
 * bundle's embedded SVG as a live network reference, not a namespace URI —
 * breaking the zero-network-request guarantee for that one slide. Barring
 * that case, the only `http(s)` substrings that can appear anywhere in the
 * output are SVG namespace URIs (`xmlns="http://www.w3.org/2000/svg"`,
 * emitted by `../render/serialize.ts` on every slide) — XML namespace
 * identifiers, not network requests.
 *
 * Embed strategy (one `<svg>` per slide, not two): the thumbnail filmstrip
 * and the large "stage" view share the exact same DOM node per slide rather
 * than each holding its own copy — duplicating every slide's SVG (including
 * any inlined `data:` image payloads) would double the file's byte size for
 * an image-heavy deck for zero benefit, since only one size is ever on
 * screen for a given slide at a time. The one node that exists for a slide
 * lives in exactly one of two homes: `#pf-stage` (the slide currently being
 * viewed large) or its own `.pf-thumb-slot` (every other slide, shown small
 * in the filmstrip) — `<script>`'s `activate()` moves it between the two
 * with a plain `appendChild` (which detaches a node from its previous parent
 * automatically) when the viewer clicks a thumbnail or presses ←/→. Because
 * an inactive slide's badge travels with its node, and the active slide's
 * thumbnail button carries its own always-present badge, a placeholder page
 * still shows its "unfilled" mark in both places even though only one copy
 * of the slide's markup ever exists.
 *
 * Audit overlay + annotations (notes+preview wave, task 2): `buildPreviewHtml`
 * is still a pure renderer — `findings` (`../audit/deck-audit.ts`'s
 * `AuditFinding`, reshaped locally as {@link PreviewHtmlFinding} so this file
 * still has no `../ir`/`../render` import) and the placeholder-skip
 * {@link PreviewHtmlInput.auditNote} both arrive as plain input, the same way
 * `slides` already does; the caller (`runPreview`, `./commands.ts`) decides
 * *whether* to run `auditDeck` at all (skipped whenever the deck has any
 * placeholder page — a placeholder has nothing to audit and `auditDeck`
 * itself silently skips it, so surfacing a half-audited deck as if it were
 * clean would be misleading; the plan's contract is "any placeholder present
 * → skip the whole overlay, one-line notice instead"). Per-page finding
 * counts (thumbnail/stage badges) and the findings panel are rendered as
 * static markup at build time, not computed by client-side JS from the
 * embedded JSON — `findings` is known up front here, so there is nothing for
 * the browser to compute; the embedded `<script type="application/json"
 * id="pf-audit-findings">` blob exists only so a saved `preview.html` still
 * carries the structured findings for later tooling, not to drive the UI.
 * User content still flows through {@link escapeHtml} everywhere it lands in
 * HTML (a finding's `message` embeds a truncated quote of the offending
 * slide's own text) — the JSON blob instead goes through {@link embedJson},
 * which additionally neutralizes any literal `</script` sequence a slide's
 * text could contain (escaping every `<` to its unicode escape — valid
 * inside a JSON string, and the only character the HTML tokenizer would
 * otherwise use to end the `<script>` element early), the standard technique
 * for safely inlining untrusted JSON into a script tag.
 *
 * Annotations were removed on 2026-08-16, along with the "Export revision
 * requests" download and the `window.__pptwiseBuildExportBlob` seam that
 * `pptwise serve` used to POST the same payload to disk. The page shows the
 * deck and nothing else: a reviewer who wants something changed says so in
 * the conversation, usually with a screenshot, which reaches the agent
 * faster than typing into a panel whose output then has to be exported and
 * read back. `preview-html.test.ts` pins the absence so it cannot return as
 * a half-feature.
 */

export interface PreviewHtmlSlideInput {
  /** Authoritative page number (1-based labels derive from this, not array
   *  position, so a caller that filters/reorders `slides` still gets
   *  correct output). */
  index: number
  /** Stable slide id (`slide.id`, `../ir/index.ts`'s `SlideSchema`) when the
   *  deck sets one. User content — HTML-escaped wherever it is shown. */
  id?: string
  /** `slide.type` — `cover`/`chapter`/`content`/`ending` in practice, kept
   *  as a plain `string` here so this module has no dependency on `../ir`. */
  type: string
  /** Already-rendered standalone SVG markup for this slide (`renderSlideSvg`,
   *  `../api.ts`) — embedded verbatim: trusted, self-produced markup, never
   *  escaped (escaping it would corrupt the SVG/XML syntax itself). */
  svg: string
  /** `slide.placeholder` — an unfilled page (assemble's stand-in for content
   *  nobody has written yet, W5 task 1). Renders a visible "unfilled" badge:
   *  this bundle exists for a human/agent visual review, so an unfilled page
   *  must never look indistinguishable from a finished one. */
  placeholder?: boolean
}

/**
 * One `auditDeck` finding (`AuditFinding`, `../audit/deck-audit.ts`),
 * reshaped to this module's own minimal fields only — dropping `detail`
 * (never shown) keeps this file dependency-free of `../render` the same way it
 * is already dependency-free of `../ir` (see the module doc comment). `page`
 * is 1-based, matching `PreviewHtmlSlideInput.index + 1` for the slide it
 * belongs to (both ultimately trace back to the same `ir.slides` array
 * position in `runPreview`, `./commands.ts`). User content — `message`
 * embeds a truncated quote of the offending slide's own text — HTML-escaped
 * wherever it is shown, same as every other user-content field in this file.
 */
export interface PreviewHtmlFinding {
  page: number
  slideId?: string
  code: string
  message: string
}

/**
 * `AuditChecks` (`../audit/deck-audit.ts`), reshaped locally the same
 * way `findings` is reshaped to {@link PreviewHtmlFinding} — keeps this file
 * free of a `../render` import (see the module doc comment). Literal state
 * words only, mirroring the source type exactly: this wave's soul
 * constraint is "not checked must never read as passed", so `pixels` being
 * `"not-requested"` has to survive unchanged all the way into the rendered
 * line — no checkmark, no "passed"/"ok" substitute that could be misread as
 * a completed pixel pass.
 */
export interface PreviewHtmlChecks {
  svg: "completed"
  pixels: "not-requested" | "completed"
}

export interface PreviewHtmlInput {
  /** Deck title (`ir.filename`) — shown in the `<title>` tag and the header.
   *  User content — HTML-escaped wherever it is shown. */
  title: string
  slides: PreviewHtmlSlideInput[]
  /** `auditDeck(ir).findings` (`../audit/deck-audit.ts`), reshaped to
   *  {@link PreviewHtmlFinding} — omit or pass `[]` when the caller skipped
   *  the audit (no findings to show at all, e.g. the deck has a placeholder
   *  page, see {@link auditNote}) or the deck audited clean. Drives the
   *  thumbnail/stage finding-count badges and the findings panel — see the
   *  module doc comment for why those are rendered as static markup here
   *  rather than computed by client-side JS from the embedded JSON blob. */
  findings?: PreviewHtmlFinding[]
  /** One-line notice shown in the header in place of any findings UI — the
   *  plan's placeholder-skip contract: `runPreview` sets this (and passes no
   *  `findings`) whenever the deck has any placeholder page, since
   *  `auditDeck` itself silently skips a placeholder (nothing to audit) and
   *  showing a placeholder-heavy deck as audit-clean would be misleading.
   *  User content only in the sense that it is caller-supplied prose, not
   *  deck content — HTML-escaped like everything else in this file
   *  regardless. */
  auditNote?: string
  /** `auditDeck(...).checks` (`../audit/deck-audit.ts`), reshaped to
   *  {@link PreviewHtmlChecks} — omit whenever the caller skipped the audit
   *  (the same condition {@link auditNote}/{@link findings} already use: a
   *  deck with a placeholder page never calls `auditDeck` at all, so there
   *  is nothing to report here either). Rendered as one line, independent of
   *  `findings.length` — a clean 0-finding report and a report where
   *  `pixels` never ran would otherwise look identical once the findings
   *  panel is empty in both cases, and the whole point of surfacing `checks`
   *  here is to keep that distinction visible even then. */
  checks?: PreviewHtmlChecks
}

import { slideEdgeFill } from "../lib/slide-edge"
import { namespaceSvgIds, svgIdPrefix } from "../lib/svg-ids"

export function escapeHtml(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#39;")
}

/**
 * `JSON.stringify(value)`, with every `<` escaped to `<` — safe to
 * inline inside a `<script>` element's text content (this file's
 * `#pf-audit-findings` data blob): the HTML tokenizer looks only for the
 * literal byte sequence `</script` to end a script element, regardless of
 * the script's `type` or of what its content actually parses as, so a
 * finding `message` that happens to contain that substring (it embeds a
 * truncated quote of the offending slide's own text — user content) could
 * otherwise truncate the document early. `<` never appears in JSON outside a
 * string value (the syntax has no structural use for it), so this blanket
 * replace only ever touches characters that were already inside string
 * content — the standard technique for embedding untrusted JSON in a page.
 */
function embedJson(value: unknown): string {
  return JSON.stringify(value).replace(/</g, "\\u003c")
}

/** `"3"` (a finding-count badge) or `""` when the slide has no findings —
 *  shared by {@link slideNode} (the moving node's own badge) and
 *  {@link thumbButton} (the thumbnail's always-present one), same
 *  "one class for the node's own copy, one for the thumbnail button's"
 *  split the existing `pf-badge`/`pf-thumb-badge` pair already uses. In
 *  practice a slide never carries both this badge and the "unfilled" one —
 *  `runPreview` only ever passes non-empty `findings` when *no* slide in the
 *  deck is a placeholder (the plan's skip-the-whole-overlay contract, see
 *  `PreviewHtmlInput.auditNote`'s doc comment) — but nothing here assumes
 *  that invariant: the two badges use different classes and corners (this
 *  one top-left, "unfilled" top-right) specifically so a caller that did
 *  pass both for one slide would still render two distinct, non-overlapping
 *  marks rather than a garbled stack. */
function findingBadge(count: number, className: string): string {
  if (count === 0) return ""
  return `<div class="${className}" aria-hidden="true">${count}</div>`
}

/** The one `.pf-slide` node this slide will ever have — moved between
 *  `#pf-stage` and its `.pf-thumb-slot` by `<script>` at runtime, never
 *  duplicated (see this module's own doc comment). Carries its own
 *  "unfilled" badge so the badge travels with it wherever it currently is,
 *  plus (independently) a finding-count badge when `findingCount > 0`. */
function slideNode(slide: PreviewHtmlSlideInput, findingCount: number): string {
  const idAttr = slide.id !== undefined ? ` data-id="${escapeHtml(slide.id)}"` : ""
  const badge = slide.placeholder ? `<div class="pf-badge" aria-hidden="true">unfilled</div>` : ""
  const fBadge = findingBadge(findingCount, "pf-finding-badge")
  // Every slide's SVG lands in one shared document here, so its internal
  // ids get a per-slide namespace first — otherwise a `url(#…)` on a later
  // slide resolves against an earlier slide's definition of the same id.
  // See `../lib/svg-ids.ts` for the defect this prevents.
  const svg = namespaceSvgIds(slide.svg, svgIdPrefix(slide.index))
  // What the box under this slide must be painted with while the slide sits
  // on it. `<script>` reads it back on every stage change; the thumbnail slot
  // gets the same value as a static inline style. Leaving the box its own
  // neutral grey leaves a pale hairline down the page edge — see
  // `../lib/slide-edge.ts` for the measurement.
  const edgeAttr = edgeAttribute(slide, "data-edge")
  return `<div class="pf-slide" id="pf-slide-${slide.index}" data-index="${slide.index}"${idAttr}${edgeAttr}>${badge}${fBadge}${svg}</div>`
}

/** ` data-edge="#1F1C18"` or ` style="background:#1F1C18"`, and `""` when the
 *  slide's edge has no single answer (a photo background) and the box should
 *  keep whatever neutral it already had. */
function edgeAttribute(slide: PreviewHtmlSlideInput, name: "data-edge" | "style"): string {
  const edge = slideEdgeFill(slide.svg)
  if (!edge) return ""
  return ` ${name}="${escapeHtml(name === "style" ? `background:${edge}` : edge)}"`
}

/** `"slide 3 · content · p-body · unfilled"` — shared by the thumbnail
 *  button's `title`/`aria-label` (raw pieces joined, then escaped once —
 *  escaping each piece separately and joining after would be equally
 *  correct, but this reads simpler and is exactly as safe). */
function thumbDescription(slide: PreviewHtmlSlideInput): string {
  const parts = [`slide ${slide.index + 1}`, slide.type]
  if (slide.id !== undefined) parts.push(slide.id)
  if (slide.placeholder) parts.push("unfilled")
  return escapeHtml(parts.join(" · "))
}

/** `"3 · p-body"` (or just `"3"` without an id) — the thumbnail's small
 *  printed label, and (via {@link counterText}) the page counter's format. */
function positionLabel(slide: PreviewHtmlSlideInput): string {
  const idPart = slide.id !== undefined ? ` · ${slide.id}` : ""
  return escapeHtml(`${slide.index + 1}${idPart}`)
}

/** `"1 / 8 · p-cover"` — the page counter's initial text (rendered directly
 *  into the static markup so it is correct even before `<script>` runs;
 *  `<script>`'s own `updateCounter()` keeps it in sync after that). */
function counterText(slide: PreviewHtmlSlideInput, total: number): string {
  const idPart = slide.id !== undefined ? ` · ${slide.id}` : ""
  return escapeHtml(`${slide.index + 1} / ${total}${idPart}`)
}

/** One always-present thumbnail button. `slotContent` is the slide's own
 *  {@link slideNode} markup when this slide starts inactive (every slide but
 *  the first), or `""` when it starts active (the first slide — its node
 *  lives in `#pf-stage` instead, see {@link buildPreviewHtml}). Either way
 *  the button itself, its label, its own "unfilled" badge (if the slide is a
 *  placeholder), and its own finding-count badge (if `findingCount > 0`) are
 *  always rendered — only the slot's content moves. */
function thumbButton(slide: PreviewHtmlSlideInput, isActive: boolean, slotContent: string, findingCount: number): string {
  const description = thumbDescription(slide)
  const badge = slide.placeholder ? `<span class="pf-thumb-badge" aria-hidden="true">unfilled</span>` : ""
  const fBadge = findingBadge(findingCount, "pf-thumb-finding-badge")
  return (
    `<button type="button" class="pf-thumb${isActive ? " pf-thumb-active" : ""}" id="pf-thumb-${slide.index}" ` +
    `data-index="${slide.index}" title="${description}" aria-label="${description}">` +
    `<span class="pf-thumb-slot" id="pf-slot-${slide.index}"${edgeAttribute(slide, "style")}>${slotContent}</span>` +
    `<span class="pf-thumb-label">${positionLabel(slide)}</span>` +
    `${badge}${fBadge}</button>`
  )
}

/** One row in the audit findings panel — `data-page-index` is the finding's
 *  owning slide's 0-based array index (`f.page - 1`, `PreviewHtmlFinding.page`
 *  is 1-based), the same identity `<script>`'s existing `activate(i)` already
 *  navigates by, so a click just calls the same function every thumbnail
 *  click already does. */
function findingPanelEntry(f: PreviewHtmlFinding): string {
  const idPart = f.slideId !== undefined ? ` · ${escapeHtml(f.slideId)}` : ""
  return (
    `<button type="button" class="pf-finding" data-page-index="${f.page - 1}">` +
    `<span class="pf-finding-loc">page ${f.page}${idPart}</span>` +
    `<span class="pf-finding-code">[${escapeHtml(f.code)}]</span> ` +
    `<span class="pf-finding-msg">${escapeHtml(f.message)}</span>` +
    `</button>`
  )
}

const CSS = `
:root{
  --bg:#f4f4f2;--panel:#fff;--line:#d9d9d4;--ink:#1b1b19;--ink-dim:#6d6d66;
  --stage:#e8e8e4;--warn:#9a6b16;--bad:#a8342d;--radius:10px;
  color-scheme:light
}
body[data-surround="dark"]{
  --bg:#17181a;--panel:#1f2124;--line:#34373c;--ink:#e9eaec;--ink-dim:#9195a0;--stage:#101113;
  color-scheme:dark
}
*{box-sizing:border-box}
html,body{height:100%;margin:0}
body{display:flex;flex-direction:column;background:var(--bg);color:var(--ink);
  font:14px/1.55 -apple-system,BlinkMacSystemFont,"Segoe UI","PingFang SC","Hiragino Sans GB",sans-serif;
  -webkit-font-smoothing:antialiased}

header{display:flex;align-items:center;gap:14px;padding:11px 18px;background:var(--panel);
  border-bottom:1px solid var(--line);flex:0 0 auto}
#pf-title{font-weight:650;letter-spacing:-.01em;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#pf-counter{font-variant-numeric:tabular-nums;color:var(--ink-dim);white-space:nowrap;font-size:13px}
.pf-spacer{flex:1 1 auto}
#pf-audit-note{color:var(--warn);font-size:12px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:46ch}
#pf-audit-checks{color:var(--ink-dim);font-size:12px;white-space:nowrap}

.pf-seg{display:inline-flex;border:1px solid var(--line);border-radius:8px;overflow:hidden;flex:0 0 auto}
.pf-seg button{appearance:none;border:0;border-right:1px solid var(--line);background:transparent;color:var(--ink);
  font:inherit;font-size:13px;padding:4px 10px;cursor:pointer}
.pf-seg button:last-child{border-right:0}
.pf-seg button[aria-pressed="true"]{background:var(--ink);color:var(--panel)}
.pf-seg button:hover:not([aria-pressed="true"]){background:var(--stage)}

/* container-type:size so the stage below can ask this box how tall it is
   instead of guessing. Legal here because the box's own size never depends on
   its contents: it is a flex item stretched to the body's width and given the
   leftover height by flex:1 1 auto. */
#pf-stage-wrap{container-type:size;flex:1 1 auto;min-height:0;display:flex;align-items:center;
  justify-content:center;gap:16px;padding:18px}
/* The stage has to fit both ways: as wide as its height allows, never wider
   than the room left beside the findings panel. Sizing it off its height and
   capping the width is the only arrangement that holds in both directions.
   Measured, not reasoned about: height-driven rules (height:100%) overflow
   when width is the tighter axis, and width-driven ones
   (width:100%;max-height:100%) stop being 16:9 when height is.
   100cqh is the wrap's real content height. It used to be 100vh - 210px, a
   guess at what the header and filmstrip take. Guess high and the slide comes
   out smaller than the window allows; guess low and the box comes out wider
   than 16:9, which aspect-ratio cannot correct once both width and max-height
   are set -- the slide then letterboxes inside its own stage and paints a grey
   bar down each side. The first declaration is that old guess, left in as the
   fallback a browser without container query units will land on. */
#pf-stage{position:relative;background:var(--stage);box-shadow:0 10px 40px rgba(0,0,0,.18);
  aspect-ratio:16/9;max-height:100%;
  width:min(100%,calc((100vh - 210px) * 16 / 9));
  width:min(100%,calc(100cqh * 16 / 9))}
#pf-stage,.pf-thumb-slot{position:relative}
.pf-slide{position:absolute;inset:0}
.pf-slide svg{display:block;width:100%;height:100%}

#pf-side{flex:0 0 250px;align-self:stretch;overflow-y:auto;background:var(--panel);
  border:1px solid var(--line);border-radius:var(--radius);padding:12px 13px;font-size:13px}
#pf-side h2{margin:0 0 8px;font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--ink-dim)}
.pf-finding{display:block;width:100%;text-align:left;background:transparent;border:1px solid var(--line);
  border-radius:8px;padding:7px 9px;margin-bottom:7px;cursor:pointer;font:inherit;color:var(--ink)}
.pf-finding:hover{background:var(--stage)}
.pf-finding-loc{display:block;font-size:11px;color:var(--ink-dim)}
.pf-finding-code{display:inline-block;font-size:11px;font-weight:700;color:var(--bad)}
.pf-finding-msg{display:block;font-size:12px;color:var(--ink-dim);margin-top:2px}

/* The strip is cut off by its own right edge when it scrolls, which reads as
   a clipping bug rather than as "there is more this way" -- the last thumbnail
   is simply sliced, and inside an embedder's rounded frame it is sliced on a
   curve. The two widths are driven from script (see fadeStrip) and are 0 until
   there is really something hidden on that side, so a strip that fits is
   untouched: at 0 the gradient is opaque from edge to edge. */
#pf-filmstrip{display:flex;gap:10px;padding:11px 18px;overflow-x:auto;background:var(--panel);
  border-top:1px solid var(--line);flex:0 0 auto;--pf-fade-l:0px;--pf-fade-r:0px;
  -webkit-mask-image:linear-gradient(to right,transparent 0,#000 var(--pf-fade-l),
    #000 calc(100% - var(--pf-fade-r)),transparent 100%);
  mask-image:linear-gradient(to right,transparent 0,#000 var(--pf-fade-l),
    #000 calc(100% - var(--pf-fade-r)),transparent 100%)}
.pf-thumb{flex:0 0 auto;width:154px;padding:0;margin:0;border:1px solid var(--line);background:var(--panel);
  cursor:pointer;border-radius:8px;overflow:hidden;position:relative;font:inherit;text-align:left}
.pf-thumb:hover{border-color:var(--ink-dim)}
.pf-thumb-active,.pf-thumb-active:hover{border-color:var(--ink);box-shadow:0 0 0 1px var(--ink)}
.pf-thumb-slot{display:block;width:100%;aspect-ratio:16/9;background:var(--stage)}
/* The active slide's SVG lives in the stage, not here — one node per slide,
   moved between the two homes. Without this the vacated slot reads as a
   broken empty box, so it states what it is instead. */
.pf-thumb-active .pf-thumb-slot::after{content:"on stage";position:absolute;inset:0;display:flex;
  align-items:center;justify-content:center;font-size:10px;letter-spacing:.08em;text-transform:uppercase;
  color:var(--ink-dim)}
.pf-thumb-label{display:block;font-size:11px;line-height:1.5;padding:4px 7px;color:var(--ink-dim);
  white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.pf-badge,.pf-thumb-badge{position:absolute;top:5px;right:5px;background:var(--warn);color:#fff;font-size:10px;
  font-weight:700;letter-spacing:.03em;padding:2px 6px;border-radius:999px;text-transform:uppercase;z-index:2;pointer-events:none}
.pf-finding-badge,.pf-thumb-finding-badge{position:absolute;top:5px;left:5px;background:var(--bad);color:#fff;
  font-size:10px;font-weight:700;padding:2px 6px;border-radius:999px;z-index:2;pointer-events:none}
`.trim()

const JS = `
(function () {
  var stage = document.getElementById('pf-stage')
  var counter = document.getElementById('pf-counter')
  var thumbs = Array.prototype.slice.call(document.querySelectorAll('.pf-thumb'))
  var total = thumbs.length
  if (total === 0) return
  var current = parseInt(thumbs[0].getAttribute('data-index'), 10)

  function slideEl(i) { return document.getElementById('pf-slide-' + i) }
  function slotEl(i) { return document.getElementById('pf-slot-' + i) }
  function thumbEl(i) { return document.getElementById('pf-thumb-' + i) }
  function thumbPos(i) {
    for (var t = 0; t < thumbs.length; t++) {
      if (parseInt(thumbs[t].getAttribute('data-index'), 10) === i) return t
    }
    return -1
  }

  function updateCounter(i) {
    var el = slideEl(i)
    if (!el) return
    var text = (thumbPos(i) + 1) + ' / ' + total
    var id = el.getAttribute('data-id')
    if (id) text += ' · ' + id
    counter.textContent = text
  }

  function activate(i) {
    if (i === current) return
    var nextSlide = slideEl(i)
    var nextThumb = thumbEl(i)
    if (!nextSlide || !nextThumb) return
    var prevSlide = slideEl(current)
    var prevSlot = slotEl(current)
    if (prevSlide && prevSlot) prevSlot.appendChild(prevSlide)
    var prevThumb = thumbEl(current)
    if (prevThumb) prevThumb.classList.remove('pf-thumb-active')
    stage.appendChild(nextSlide)
    stage.style.background = nextSlide.getAttribute('data-edge') || ''
    nextThumb.classList.add('pf-thumb-active')
    nextThumb.scrollIntoView({ block: 'nearest', inline: 'nearest' })
    current = i
    updateCounter(i)
  }

  thumbs.forEach(function (t) {
    t.addEventListener('click', function () {
      activate(parseInt(t.getAttribute('data-index'), 10))
    })
  })

  document.addEventListener('keydown', function (e) {
    var pos = thumbPos(current)
    if (e.key === 'ArrowRight' && pos < total - 1) {
      activate(parseInt(thumbs[pos + 1].getAttribute('data-index'), 10))
    } else if (e.key === 'ArrowLeft' && pos > 0) {
      activate(parseInt(thumbs[pos - 1].getAttribute('data-index'), 10))
    }
  })

  // Click a finding, jump to its page — the same activate() a thumbnail uses.
  Array.prototype.slice.call(document.querySelectorAll('.pf-finding')).forEach(function (b) {
    b.addEventListener('click', function () {
      activate(parseInt(b.getAttribute('data-page-index'), 10))
    })
  })

  // Fade whichever end of the strip has more thumbnails behind it. Driven
  // from here rather than left to CSS because no CSS rule can ask whether a
  // box currently overflows. See the #pf-filmstrip rule for why it matters.
  var strip = document.getElementById('pf-filmstrip')
  function fadeStrip() {
    if (!strip || thumbs.length === 0) return
    // Measured off the thumbnails, not off scrollWidth. The strip's own
    // 18px of padding counts as scrollable width, so scrollWidth says there
    // is more to the right while a reader is already looking at the last
    // thumbnail — and activate()'s scrollIntoView stops exactly there,
    // leaving the padding unscrolled. The fade would then claim there is
    // more to see and dim the selected thumbnail's own ring to do it. Asking
    // whether a thumbnail is actually cut off is what the fade means anyway.
    var box = strip.getBoundingClientRect()
    var hiddenLeft = box.left - thumbs[0].getBoundingClientRect().left
    var hiddenRight = thumbs[thumbs.length - 1].getBoundingClientRect().right - box.right
    // A pixel of slack: sub-pixel layout leaves a fraction of overflow on
    // strips that visibly fit, and fading those is the bug in reverse.
    strip.style.setProperty('--pf-fade-l', (hiddenLeft > 1 ? 28 : 0) + 'px')
    strip.style.setProperty('--pf-fade-r', (hiddenRight > 1 ? 28 : 0) + 'px')
  }
  if (strip) {
    fadeStrip()
    strip.addEventListener('scroll', fadeStrip, { passive: true })
    // The strip also stops and starts overflowing as the window changes width,
    // and scrollIntoView moves it without a resize.
    window.addEventListener('resize', fadeStrip)
    if (window.ResizeObserver) new ResizeObserver(fadeStrip).observe(strip)
  }

  // Open on a given page: #page=3 is the third thumbnail, not slide index 3.
  // A reader who clicks page 3 in a harness that embeds this file expects to
  // land on page 3, and the embedder has no other way to say so — it holds a
  // URL, not a handle on this script. Reading the position rather than the
  // index keeps that promise honest for a deck whose slides are not numbered
  // 0..n-1. Silently ignored when it names a page this deck does not have.
  function fromHash() {
    var m = /(?:^|[#&])page=(\\d+)/.exec(location.hash || '')
    if (!m) return
    var pos = parseInt(m[1], 10) - 1
    // >= 0, not > 0. Page 1 is a no-op on first load, but not afterwards: a
    // reader who pages forward and then hits Back gets #page=1 in the URL,
    // and skipping it leaves the address bar and the deck disagreeing.
    // activate() already returns early when it is handed the current page.
    if (pos >= 0 && pos < total) activate(parseInt(thumbs[pos].getAttribute('data-index'), 10))
  }
  fromHash()
  window.addEventListener('hashchange', fromHash)

  // Light/dark surround. A deck is judged on color and weight, and the
  // surround it sits on changes both — a dark theme reads muddy on a light
  // page and vice versa, so the reviewer picks rather than the page deciding.
  var seg = document.getElementById('pf-surround')
  if (seg) {
    seg.addEventListener('click', function (e) {
      var btn = e.target.closest('button')
      if (!btn) return
      document.body.setAttribute('data-surround', btn.getAttribute('data-surround'))
      Array.prototype.slice.call(seg.children).forEach(function (b) {
        b.setAttribute('aria-pressed', String(b === btn))
      })
    })
  }
})()
`.trim()


/**
 * Build the self-contained `preview.html` bundle. Pure — no `fs`, safe to
 * unit-test directly (`./preview-html.test.ts`). See this module's own doc
 * comment for the self-containment and single-embed-per-slide design notes.
 */
export function buildPreviewHtml(input: PreviewHtmlInput): string {
  const { title, slides, findings = [], auditNote, checks } = input
  const total = slides.length
  const escapedTitle = escapeHtml(title)

  // Group findings by the 1-based page number they belong to, so each
  // slide's badge count is a single map lookup rather than an O(findings)
  // scan per slide.
  const findingsByPage = new Map<number, PreviewHtmlFinding[]>()
  for (const f of findings) {
    const list = findingsByPage.get(f.page)
    if (list) list.push(f)
    else findingsByPage.set(f.page, [f])
  }
  const countFor = (slide: PreviewHtmlSlideInput) => findingsByPage.get(slide.index + 1)?.length ?? 0

  const stageSlide = total > 0 ? slideNode(slides[0]!, countFor(slides[0]!)) : ""
  // The first slide starts on the stage, so its edge paint has to be in the
  // static markup — `<script>` only repaints from the next change onward.
  const stageEdge = total > 0 ? edgeAttribute(slides[0]!, "style") : ""
  const thumbs = slides
    .map((s, i) => thumbButton(s, i === 0, i === 0 ? "" : slideNode(s, countFor(s)), countFor(s)))
    .join("")
  const initialCounter = total > 0 ? counterText(slides[0]!, total) : "0 / 0"

  // Findings panel + embedded JSON blob (see this module's own doc comment
  // for why the panel is static markup, not client-computed from the blob)
  // — both entirely omitted when there is nothing to show, so a clean or
  // audit-skipped deck's preview.html carries no trace of either (matches
  // the pre-existing "never shows an 'unfilled' badge when no slide is a
  // placeholder" precedent for the badge markup itself).
  const auditPanel =
    findings.length > 0
      ? `<section id="pf-audit-panel"><h2>Audit findings (${findings.length})</h2><div id="pf-audit-list">${findings.map(findingPanelEntry).join("")}</div></section>`
      : ""
  const findingsDataScript =
    findings.length > 0
      ? `<script type="application/json" id="pf-audit-findings">${embedJson(findings)}</script>`
      : ""
  const auditNoteHtml = auditNote !== undefined ? `<span id="pf-audit-note">${escapeHtml(auditNote)}</span>` : ""

  // One-line "which check families actually ran" summary (fix round,
  // Important-1: the task brief's own scope for this wave, missed in the
  // first pass) — independent of `auditPanel`'s `findings.length > 0` gate
  // on purpose, see `PreviewHtmlInput.checks`'s own doc comment for why.
  // Renders the literal state words straight out of `PreviewHtmlChecks`
  // (`"completed"` / `"not-requested"`) with no checkmark/tick substitute —
  // the soul constraint this whole wave is built on is "not checked must
  // never read as passed", and a glyph here would be exactly that misread
  // for a `pixels: "not-requested"` report.
  const checksLine =
    checks !== undefined
      ? `<span id="pf-audit-checks">audit: svg ${checks.svg} · pixels ${checks.pixels}</span>`
      : ""

  // The findings rail only exists when there is something in it. An empty
  // panel used to sit there taking a quarter of the width on every clean
  // deck, which is most of them.
  const sideHtml = auditPanel ? `<aside id="pf-side">${auditPanel}</aside>` : ""

  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapedTitle} — pptwise preview</title>
<style>${CSS}</style>
</head>
<body data-surround="light">
<header>
<span id="pf-title">${escapedTitle}</span>
<span id="pf-counter">${initialCounter}</span>
<span class="pf-spacer"></span>
${auditNoteHtml}
${checksLine}
<div class="pf-seg" id="pf-surround" role="group" aria-label="surround">
<button type="button" data-surround="light" aria-pressed="true">Light</button>
<button type="button" data-surround="dark" aria-pressed="false">Dark</button>
</div>
</header>
<div id="pf-stage-wrap"><div id="pf-stage"${stageEdge}>${stageSlide}</div>${sideHtml}</div>
<nav id="pf-filmstrip" aria-label="slides">${thumbs}</nav>
${findingsDataScript}
<script>${JS}</script>
</body>
</html>
`
}

export interface ContactSheetSlide {
  type: string
  svg: string
  /** Row label. Kind rows use the kind so they do not collapse. */
  label?: string
}

export interface ContactSheetColumn {
  id: string
  slides: ContactSheetSlide[]
}

export interface ContactSheetInput {
  title: string
  themes: ContactSheetColumn[]
}

const CONTACT_SHEET_CSS = `
:root { color-scheme: light; }
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body {
  font: 14px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
  color: #111;
  background: #f4f4f1;
  padding: 24px;
}
h1 { font-size: 18px; font-weight: 600; margin: 0 0 16px; }
table.cs { width: 100%; border-collapse: collapse; table-layout: fixed; }
table.cs th, table.cs td { vertical-align: top; padding: 8px; }
table.cs td.cs-missing { color: #8a8a85; vertical-align: middle; text-align: center; }
table.cs thead th { text-align: left; font-size: 13px; font-weight: 600; }
table.cs tbody th { text-align: left; font-weight: 500; color: #555; width: 88px; }
.cs-cell svg { display: block; width: 100%; height: auto; background: #fff; }
`.trim()

/** Self-contained HTML comparison: columns = themes, rows = cover / first content. */
export function buildContactSheetHtml(input: ContactSheetInput): string {
  const { title, themes } = input
  const rowLabels: string[] = []
  for (const col of themes) {
    for (const slide of col.slides) {
      const label = slide.label ?? slide.type
      if (!rowLabels.includes(label)) rowLabels.push(label)
    }
  }
  const head = themes.map((t) => `<th scope="col">${escapeHtml(t.id)}</th>`).join("")
  const body = rowLabels
    .map((label) => {
      const cells = themes
        .map((t, colIdx) => {
          const slide = t.slides.find((s) => (s.label ?? s.type) === label)
          if (!slide) return `<td class="cs-missing">not in ${escapeHtml(t.id)}'s menu</td>`
          const svg = namespaceSvgIds(slide.svg, `t${colIdx}-${label}-`)
          return `<td class="cs-cell">${svg}</td>`
        })
        .join("")
      return `<tr><th scope="row">${escapeHtml(label)}</th>${cells}</tr>`
    })
    .join("")
  const escapedTitle = escapeHtml(title)
  return `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapedTitle} — theme comparison</title>
<style>${CONTACT_SHEET_CSS}</style>
</head>
<body>
<h1>${escapedTitle}</h1>
<table class="cs">
<thead><tr><th></th>${head}</tr></thead>
<tbody>${body}</tbody>
</table>
</body>
</html>
`
}

export interface ThemeWallSheetRow {
  id: string
  label: string
  /** The drawn pages, in order, or the reason a page was left out. */
  cells: ({ type: string; svg: string } | { type: string; reason: string })[]
}

const THEME_WALL_CSS = `
:root { color-scheme: light; }
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body {
  font: 14px/1.4 -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif;
  color: #111;
  background: #f4f4f1;
  padding: 24px;
}
h1 { font-size: 18px; font-weight: 600; margin: 0 0 16px; }
table.tw { width: 100%; max-width: 1200px; border-collapse: collapse; table-layout: fixed; }
table.tw th, table.tw td { vertical-align: top; padding: 8px; }
table.tw thead th { text-align: left; font-size: 13px; font-weight: 600; color: #555; }
table.tw tr > th:first-child { text-align: left; width: 120px; }
table.tw tbody th span { display: block; font-weight: 600; }
table.tw tbody th code { font-size: 12px; color: #777; }
td.tw-missing { color: #8a8a85; font-size: 12px; }
.tw-cell svg { display: block; width: 100%; height: auto; background: #fff; }
`.trim()

/**
 * Self-contained HTML for `theme try --title`: one row per theme, the
 * caller's cover and content page side by side. Rows rather than the fixed
 * sample's columns, because a wall can hold every installed theme and a
 * column each would leave every page a few dozen pixels wide.
 */
export function buildThemeWallHtml(input: { title: string; columns: readonly string[]; rows: readonly ThemeWallSheetRow[] }): string {
  const head = input.columns.map((column) => `<th scope="col">${escapeHtml(column)}</th>`).join("")
  const body = input.rows
    .map((row, rowIdx) => {
      const cells = row.cells
        .map((cell) => {
          if ("reason" in cell) return `<td class="tw-missing">${escapeHtml(cell.reason)}</td>`
          return `<td class="tw-cell">${namespaceSvgIds(cell.svg, `w${rowIdx}-${cell.type}-`)}</td>`
        })
        .join("")
      return `<tr><th scope="row"><span>${escapeHtml(row.label)}</span><code>${escapeHtml(row.id)}</code></th>${cells}</tr>`
    })
    .join("")
  const escapedTitle = escapeHtml(input.title)
  return `<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>${escapedTitle} — themes</title>
<style>${THEME_WALL_CSS}</style>
</head>
<body>
<h1>${escapedTitle}</h1>
<table class="tw">
<thead><tr><th></th>${head}</tr></thead>
<tbody>${body}</tbody>
</table>
</body>
</html>
`
}
