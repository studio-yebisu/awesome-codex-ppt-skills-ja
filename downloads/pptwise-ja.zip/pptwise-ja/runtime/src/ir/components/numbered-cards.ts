import { z } from "zod"
import { IconNameSchema } from "./shared"
import type { ComponentAliasSpec, ComponentTraits } from "./types"
import type { DesignStory } from "../../design-story"

export const schema = z
  .object({
    type: z.literal("numbered_cards"),
    /** 编号卡片列表（编辑部大数字目录）：3-10 项自上而下排成一列（9 项起分两列），每项一张
     * 卡片，卡内左端是自动编号徽章 01..N，右边是标题和可选正文，`sub` 限定语
     * 右对齐贴在卡片右端。列表左侧一枚大圆标出条目总数。适合并列名录、作品集、
     * 要点集。 */
    items: z
      .array(
        z
          .object({
            title: z.string(),
            text: z.string().optional(),
            sub: z.string().optional(),
            /** A symbol for the item. See the describe below. */
            icon: IconNameSchema.optional().describe(
              "A symbol for the item, drawn between its number and its title, such as pill or hospital. Run `pptwise icons` for the names.",
            ),
            /** The one item the page lands on. See the describe below. */
            emphasis: z
              .boolean()
              .optional()
              .describe(
                "Marks the one item the page lands on, such as the answer the other items lead to. Its card is filled in the primary colour. At most one item.",
              ),
          })
          .strict()
      )
      .min(3)
      .max(10),
  })
  .strict()
  .superRefine((c, ctx) => {
    // A filled card singles one item out, so two filled cards single out
    // nothing.
    const marked = c.items.flatMap((item, i) => (item.emphasis === true ? [i] : []))
    if (marked.length > 1) {
      ctx.addIssue({
        code: "custom",
        path: ["items", marked[1]!, "emphasis"],
        message: `numbered_cards marks ${marked.length} items with emphasis, and a filled card singles out one. Keep emphasis on the item the page lands on.`,
      })
    }
  })

export const aliases = {
  items: [{ itemsKey: "items", aliases: { description: "text", desc: "text" } }],
} satisfies ComponentAliasSpec

export const traits = {
  stretchable: false,
  scalable: false,
  fullBody: false,
  evidence: false,
} as const satisfies ComponentTraits

export const story: DesignStory = {
  name: "Numbered Index",
  story: "Items numbered from 01 upward, each on its own card in one column, or two past eight, beside a disc that counts them. The contents page of a magazine, where the numbers are how you refer to things.",
  positioning: "Choose it when each item carries its own title and a stable number it will be referred to by. Use bullets when short lines with no titles are enough, and steps when the order is a procedure to follow.",
  audience: "Readers who will point at item three later.",
  notFor: "A procedure to be carried out in order, which belongs in steps.",
}
