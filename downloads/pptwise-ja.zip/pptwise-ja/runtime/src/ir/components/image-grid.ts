import { z } from "zod"
import { CropSchema, IconNameSchema, TagSchema } from "./shared"
import type { ComponentAliasSpec, ComponentTraits } from "./types"
import type { DesignStory } from "../../design-story"

// 图片排版 P2（2026-07-08）：多图网格与双图对比。
export const schema = z
  .object({
    type: z.literal("image_grid"),
    items: z
      .array(
        z
          .object({
            asset_id: z.string(),
            caption: z.string().optional(),
            /** A symbol for the caption. See the describe below. */
            icon: IconNameSchema.optional().describe(
              "A symbol drawn before the picture's caption, such as zap or map-pin. Only with a caption. Run `pptwise icons` for the names.",
            ),
            tag: TagSchema.optional().describe('A few words on the picture, such as "选配" or "Optional".'),
            crop: CropSchema.optional(),
          })
          .strict()
      )
      .min(2)
      .max(8),
    emphasis: z.enum(["none", "first"]).optional(),
  })
  .strict()
  .superRefine((c, ctx) => {
    c.items.forEach((item, i) => {
      if (item.icon !== undefined && !item.caption?.trim()) {
        ctx.addIssue({
          code: "custom",
          path: ["items", i, "icon"],
          message: `image_grid items[${i}] has an icon and no caption, and the icon is drawn before the caption. Give the picture a caption, or remove icon.`,
        })
      }
    })
  })
  .describe(
    "A 2-8 photo/screenshot grid with cover-crop cells.",
  )

export const aliases = {} satisfies ComponentAliasSpec

export const traits = {
  stretchable: false,
  scalable: false,
  fullBody: false,
  evidence: false,
} as const satisfies ComponentTraits

export const story: DesignStory = {
  name: "Contact Sheet",
  story: "Two to eight pictures cropped into a grid, working as one set. The contact sheet a photographer lays out to show a whole shoot at once.",
  positioning: "Choose it when a set of images works together and no single one carries the page. Use image for one picture and image_compare for a pair set against each other.",
  audience: "Viewers taking in a body of work rather than a single frame.",
  notFor: "One picture that deserves the page, which belongs in image.",
  lineage: "The photographer's contact sheet, frames laid out in rows.",
}
