# 制作依頼

SlideFlyの原典morph-engine/nav/frames/free-layoutとinline-assets.pyを使い、日本語6枚「街を歩く、寄り道を選ぶ。」を制作。架空の散歩企画で実在地点・営業情報・天気・実績は主張しない。同じnamed actorの旅人・道・目印が6poseで動き、道の分岐はSVGで説明。暖かな紙・朱橙・深緑、大きな和文とSpace Groteskの英数字。日本語は意味の切れ目で明示改行。カード反復なし。原典の標準Python export-pptxで文字/actor編集とMorph設定を作り、実再生を確かめた範囲と区別する。