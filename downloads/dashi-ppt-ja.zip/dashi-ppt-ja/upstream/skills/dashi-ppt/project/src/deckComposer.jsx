// @ts-check
import { DEFAULT_THEME_PACK, THEME_PACK_OPTIONS, slide } from './options.jsx';
import { THEME_PAGES } from './components/themes/index.jsx';
import { isMediaArrayKey } from './prop-contract-core.mjs';
import {
  BESPOKE_SCHEMA_VERSION,
  TEMPLATE_VARIANT_COUNT,
  TOTAL_VARIANT_COUNT,
  isBespokeVariant,
  isTemplateVariant,
} from './variant-contract.mjs';

export const ROLE_KEYWORDS = {
  cover: ['cover', '封面', '首页'],
  statement: ['statement', 'summary', 'overview', 'manifesto', 'quote', '摘要', '主张', '观点', '结论'],
  breakdown: ['contents', 'agenda', 'index', 'directory', '目录', '结构', '纲目'],
  transition: ['section', 'chapter', 'divider', '章节', '序章', '篇章'],
  context: ['market', 'method', 'context', 'industry', '全景', '背景', '方法', '行业'],
  metrics: ['metric', 'stat', 'number', 'score', 'gauge', 'meter', '指标', '数字', '大势', '仪表'],
  trend: ['trend', 'timeline', 'curve', 'area', 'slope', 'stream', '走势', '趋势', '时间', '曲线', '季度'],
  comparison: ['compare', 'versus', 'matrix', 'quadrant', 'delta', 'dumbbell', '对比', '矩阵', '象限', '差距'],
  distribution: ['donut', 'treemap', 'heatmap', 'ranking', 'rank', 'waterfall', 'funnel', 'allocation', 'share', '分布', '占比', '排行', '瀑布', '漏斗'],
  relationship: ['chain', 'flow', 'sankey', 'network', 'orbit', 'ecosystem', 'map', '关系', '链', '流向', '生态', '网络'],
  case: ['case', 'spotlight', 'profile', 'story', '案例', '聚焦', '档案'],
  image: ['image', 'gallery', 'mosaic', 'photo', 'film', 'album', 'poster', 'showcase', '影像', '图景', '图集', '图片', '海报'],
  process: ['process', 'roadmap', 'journey', 'steps', 'gantt', '路径', '流程', '路线', '进程'],
  risks: ['risk', 'faq', 'checklist', '风险', '异议', '问答', '清单'],
  observation: ['quote', 'insight', 'takeaway', 'conclusion', 'statement', 'manifesto', '观点', '洞察', '要点', '结论'],
  actions: ['action', 'roadmap', 'plan', 'join', 'contact', 'next', '行动', '策略', '计划', '套餐'],
  result: ['result', 'outcome', 'score', 'closing', 'conclusion', '成果', '结果', '完成', '结论'],
  team: ['team', 'roster', 'testimonial', 'voice', '团队', '人物', '见证', '证言'],
  closing: ['closing', 'contact', 'join', 'end', 'colophon', '结语', '封底', '行动'],
};

export const ROLE_ALIASES = {
  agenda: 'breakdown',
  summary: 'statement',
  insight: 'observation',
  quote: 'observation',
  chart: 'metrics',
  data: 'metrics',
  timeline: 'trend',
  compare: 'comparison',
  flow: 'process',
  roadmap: 'actions',
  visual: 'image',
  gallery: 'image',
  media: 'image',
  picture: 'image',
  photo: 'image',
};

const DEFAULT_ROLE_SEQUENCE = [
  'cover',
  'statement',
  'breakdown',
  'context',
  'metrics',
  'comparison',
  'distribution',
  'relationship',
  'case',
  'image',
  'trend',
  'process',
  'risks',
  'actions',
  'result',
  'closing',
];

export const THEME_ROLE_LAYOUT_POOLS = Object.fromEntries(
  Object.keys(THEME_PACK_OPTIONS).map(themeKey => [themeKey, buildRoleLayoutPools(themeKey)]),
);

export const ROLE_LAYOUT_POOLS = THEME_ROLE_LAYOUT_POOLS[DEFAULT_THEME_PACK] || {};

export const ROLE_LAYOUTS = Object.fromEntries(
  Object.entries(ROLE_LAYOUT_POOLS).map(([role, layouts]) => [role, layouts[0]]),
);

const THEME_PAGE_BY_KEY = new Map(THEME_PAGES.map(page => [page.key, page]));
const VARIANT_STATE_ID_SEPARATOR = '::';

export function composeDeck(spec = {}) {
  const expandedVariants = spec.schemaVersion === BESPOKE_SCHEMA_VERSION;
  if (spec.schemaVersion != null && !expandedVariants) {
    throw new Error(`Unsupported deck schemaVersion "${spec.schemaVersion}".`);
  }
  const goal = spec.goal || spec.title || '主题汇报';
  const title = spec.title || goal;
  const randomSeed = spec.randomSeed || `${title}:${goal}`;
  const themePack = normalizeThemePack(spec.themePack) || DEFAULT_THEME_PACK;
  const sourceSlides = spec.slides?.length
    ? spec.slides
    : defaultSlides({ title, goal, pageCount: getPageCount(spec) });
  const usedLayouts = new Set();
  const slides = sourceSlides.map((page, index) => composeSlide(page, {
    randomSeed,
    index,
    usedLayouts,
    rolePools: THEME_ROLE_LAYOUT_POOLS[themePack] || ROLE_LAYOUT_POOLS,
    expandedVariants,
  }));
  assertSlideIdentities(slides);
  return {
    ...(expandedVariants ? {
      schemaVersion: BESPOKE_SCHEMA_VERSION,
      variantPresentation: 'expanded',
      variantOutputMode: spec.variantOutputMode ?? 'comparison',
    } : {}),
    themePack,
    title,
    language: spec.language,
    text: spec.text || {},
    media: spec.media || {},
    props: spec.props || {},
    preview: spec.preview || {},
    slides,
  };
}

function composeSlide(page, context) {
  if (context.expandedVariants) {
    return composeExpandedVariantSlide(page, context);
  }
  if (typeof page === 'string') {
    context.usedLayouts.add(page);
    return slide(page, {});
  }
  if (Object.prototype.hasOwnProperty.call(page || {}, 'variants')) {
    const variants = Array.isArray(page.variants) ? page.variants : [];
    if (variants.length !== TEMPLATE_VARIANT_COUNT) {
      throw new Error('Slide variants must contain exactly 3 entries.');
    }
    const normalizedVariants = variants.map((variant, variantIndex) => {
      const layout = variant?.layout || chooseLayout(variant || {}, normalizeRole(variant?.role || page.role), context);
      context.usedLayouts.add(layout);
      return {
        ...slide(layout, variant?.props || {}),
        id: variant?.id || `variant-${variantIndex + 1}`,
        key: variant?.key || variant?.slideKey,
        label: variant?.label,
        media: variant?.media,
      };
    });
    return {
      id: page.id || page.key || page.slideKey || `slide-${context.index + 1}`,
      key: page.key || page.slideKey,
      label: page.label,
      logicalIndex: page.logicalIndex,
      selectedVariant: page.selectedVariant || normalizedVariants[0].id,
      variants: normalizedVariants,
    };
  }
  const role = normalizeRole(page.role);
  const layout = page.layout || chooseLayout(page, role, context);
  context.usedLayouts.add(layout);
  return {
    ...slide(layout, page.props || {}),
    id: page.id,
    key: page.key || page.slideKey,
    label: page.label,
    logicalIndex: page.logicalIndex,
    copy: page.copy,
  };
}

function composeExpandedVariantSlide(page, context) {
  if (!isPlainRecord(page) || !Array.isArray(page.variants) || page.variants.length !== TOTAL_VARIANT_COUNT) {
    throw new Error(`schemaVersion ${BESPOKE_SCHEMA_VERSION} slides must contain exactly ${TOTAL_VARIANT_COUNT} variants.`);
  }
  if (!isPlainRecord(page.content)) {
    throw new Error(`schemaVersion ${BESPOKE_SCHEMA_VERSION} slide ${context.index + 1} must define logical content as an object.`);
  }

  const normalizedVariants = page.variants.map((variant, variantIndex) => {
    if (!isPlainRecord(variant)) {
      throw new Error(`Slide ${context.index + 1} variant ${variantIndex + 1} must be an object.`);
    }
    if (Object.prototype.hasOwnProperty.call(variant, 'content')) {
      throw new Error(`Slide ${context.index + 1} variant ${variantIndex + 1} must reference logical slide content through contentMap.`);
    }
    if (variantIndex < TEMPLATE_VARIANT_COUNT) {
      return composeExpandedTemplateVariant(variant, variantIndex, context);
    }
    return composeBespokeVariant(variant, variantIndex, context);
  });

  return {
    id: page.id || page.key || page.slideKey || `slide-${context.index + 1}`,
    key: page.key || page.slideKey,
    label: page.label,
    logicalIndex: page.logicalIndex,
    content: page.content,
    selectedVariant: page.selectedVariant || normalizedVariants[0].id,
    variants: normalizedVariants,
  };
}

function composeExpandedTemplateVariant(variant, variantIndex, context) {
  if (
    variant.kind !== 'template'
    || !isTemplateVariant(variant)
    || typeof variant.layout !== 'string'
    || !variant.layout.trim()
  ) {
    throw new Error(`schemaVersion ${BESPOKE_SCHEMA_VERSION} slide ${context.index + 1} variant ${variantIndex + 1} must be an explicit template variant with a layout.`);
  }
  if (variant.props === undefined
    ? !isPlainRecord(variant.projection?.structure)
    : !isPlainRecord(variant.props)) {
    throw new Error(`Slide ${context.index + 1} template variant ${variantIndex + 1} requires object props or projection.structure.`);
  }
  if (!isPlainRecord(variant.contentMap)) {
    throw new Error(`Slide ${context.index + 1} template variant ${variantIndex + 1} contentMap must be an object.`);
  }

  context.usedLayouts.add(variant.layout);
  return {
    ...slide(variant.layout, variant.props || {}),
    id: variant.id || `variant-${variantIndex + 1}`,
    kind: 'template',
    key: variant.key || variant.slideKey,
    label: variant.label,
    media: variant.media,
    contentMap: variant.contentMap,
    projection: variant.projection,
  };
}

function composeBespokeVariant(variant, variantIndex, context) {
  if (variant.kind !== 'bespoke' || !isBespokeVariant(variant)) {
    throw new Error(`schemaVersion ${BESPOKE_SCHEMA_VERSION} slide ${context.index + 1} variant ${variantIndex + 1} must be a bespoke variant.`);
  }
  for (const forbidden of ['layout', 'props', 'controls']) {
    if (Object.prototype.hasOwnProperty.call(variant, forbidden)) {
      throw new Error(`Slide ${context.index + 1} bespoke variant must not define ${forbidden}.`);
    }
  }
  if (variant.adjustable !== false) {
    throw new Error(`Slide ${context.index + 1} bespoke variant must set adjustable to false.`);
  }
  if (!isPlainRecord(variant.composition)) {
    throw new Error(`Slide ${context.index + 1} bespoke variant composition must be an object.`);
  }
  if (!isPlainRecord(variant.contentMap)) {
    throw new Error(`Slide ${context.index + 1} bespoke variant contentMap must be an object.`);
  }

  return {
    id: variant.id || `variant-${variantIndex + 1}`,
    kind: 'bespoke',
    key: variant.key || variant.slideKey,
    label: variant.label,
    media: variant.media,
    adjustable: false,
    composition: variant.composition,
    contentMap: variant.contentMap,
    projection: variant.projection,
  };
}

function isPlainRecord(value) {
  return value != null && typeof value === 'object' && !Array.isArray(value);
}

function assertSlideIdentities(slides) {
  const logicalIdUsages = new Map();
  slides.forEach((page, slideIndex) => {
    const logicalId = resolveLogicalSlideId(page, slideIndex);
    if (logicalId.includes(VARIANT_STATE_ID_SEPARATOR)) {
      throw new Error(`Slide ${slideIndex + 1} logical slide id "${logicalId}" contains reserved delimiter "${VARIANT_STATE_ID_SEPARATOR}" used by stateId.`);
    }
    const positions = logicalIdUsages.get(logicalId) || [];
    positions.push(slideIndex + 1);
    logicalIdUsages.set(logicalId, positions);

    if (!Array.isArray(page?.variants)) return;
    const variantIdUsages = new Map();
    page.variants.forEach((variant, variantIndex) => {
      const variantId = String(variant?.id || `variant-${variantIndex + 1}`);
      if (variantId.includes(VARIANT_STATE_ID_SEPARATOR)) {
        throw new Error(`Slide ${slideIndex + 1} variant ${variantIndex + 1} variant id "${variantId}" contains reserved delimiter "${VARIANT_STATE_ID_SEPARATOR}" used by stateId.`);
      }
      const variantPositions = variantIdUsages.get(variantId) || [];
      variantPositions.push(variantIndex + 1);
      variantIdUsages.set(variantId, variantPositions);
    });
    for (const [variantId, variantPositions] of variantIdUsages.entries()) {
      if (variantPositions.length <= 1) continue;
      throw new Error(`Slide ${slideIndex + 1} has duplicate variant id "${variantId}" on variants ${variantPositions.join(', ')}.`);
    }
  });
  for (const [logicalId, positions] of logicalIdUsages.entries()) {
    if (positions.length <= 1) continue;
    throw new Error(`Deck has duplicate logical slide id "${logicalId}" on slides ${positions.join(', ')}.`);
  }
}

function resolveLogicalSlideId(slideModel, index) {
  if (slideModel?.id != null && slideModel.id !== '') return String(slideModel.id);
  const layout = slideModel?.layout || 'slide';
  return `${layout}-${index + 1}`;
}

function chooseLayout(page, role, { randomSeed, index, usedLayouts, rolePools }) {
  const layouts = normalizeLayoutPool(page.layouts || page.layoutPool || page.candidates || rolePools[role]);
  if (!layouts.length) {
    throw new Error(`Unknown slide role "${page.role}". Use layout directly or choose one of: ${Object.keys(rolePools).join(', ')}`);
  }
  const requestedMediaCount = getRequestedMediaCount(page);
  const mediaReadyLayouts = requestedMediaCount
    ? layouts.filter(layout => layoutHasMediaSlot(layout, requestedMediaCount))
    : layouts;
  if (requestedMediaCount && !mediaReadyLayouts.length) {
    throw new Error(`Slide role "${page.role || role}" requires ${requestedMediaCount} media slot(s), but no candidate layout has a usable media slot.`);
  }
  const sourceLayouts = mediaReadyLayouts.length ? mediaReadyLayouts : layouts;
  const available = sourceLayouts.filter(layout => !usedLayouts.has(layout));
  const pool = available.length ? available : sourceLayouts;
  return pool[hashSeed(`${randomSeed}:${role}:${index}`) % pool.length];
}

function normalizeLayoutPool(layouts) {
  if (!layouts) return [];
  return (Array.isArray(layouts) ? layouts : [layouts]).filter(Boolean);
}

function normalizeRole(role) {
  if (!role) return null;
  return ROLE_ALIASES[role] || role;
}

function normalizeThemePack(themePack) {
  return THEME_PACK_OPTIONS[themePack] ? themePack : null;
}

function buildRoleLayoutPools(themeKey) {
  const pages = THEME_PAGES.filter(page => page.themeKey === themeKey);
  const allLayouts = pages.map(page => page.key);
  return Object.fromEntries(Object.entries(ROLE_KEYWORDS).map(([role, keywords]) => {
    const matched = pages
      .filter(page => {
        if (role === 'cover') return page.pageNumber >= 1 && page.pageNumber <= 5;
        if (role === 'image') return pageHasMediaSlot(page);
        return pageMatches(page, keywords);
      })
      .map(page => page.key);
    return [role, matched.length ? matched : fallbackRoleLayouts(role, allLayouts)];
  }));
}

function pageMatches(page, keywords) {
  const text = `${page.slot || ''} ${page.label || ''}`.toLowerCase();
  return keywords.some(keyword => text.includes(keyword.toLowerCase()));
}

function fallbackRoleLayouts(role, layouts) {
  if (!layouts.length) return [];
  if (role === 'cover') return layouts.slice(0, 5);
  if (role === 'closing') return [layouts[layouts.length - 1]];
  return layouts;
}

function getRequestedMediaCount(page = {}) {
  const explicit = countMediaItems(page.mediaCount);
  if (explicit) return explicit;
  const provided = countMediaItems(page.providedImages);
  if (provided) return provided;
  const providedMedia = countMediaItems(page.providedMedia);
  if (providedMedia) return providedMedia;
  const planned = countMediaItems(page.plannedImages);
  if (planned) return planned;
  if (page.needsVisual === true || page.needsImageGen === true || page.imageGen === true) return 1;
  return 0;
}

function countMediaItems(value) {
  if (Array.isArray(value)) return value.length;
  if (value === true) return 1;
  const number = Number(value);
  if (Number.isFinite(number) && number > 0) return Math.round(number);
  return 0;
}

export function layoutHasMediaSlot(layout, count = 1) {
  const page = THEME_PAGE_BY_KEY.get(layout);
  return page ? pageHasMediaSlot(page, count) : false;
}

function pageHasMediaSlot(page, count = 1) {
  return getMediaSlotCapacities(page).some(capacity => capacity >= Math.max(1, Number(count) || 1));
}

/** @param {import('./types').PageRecord} page */
function getMediaSlotCapacities(page) {
  const props = page.defaultProps || {};
  const controls = page.controls || [];
  const capacities = Object.keys(props)
    .filter(key => Array.isArray(props[key]) && isMediaArrayKey(key))
    .map(key => mediaArrayCapacity(key, props, controls));

  for (const control of controls) {
    if (!isMediaControl(control)) continue;
    const key = control.prop || control.key;
    if (!key || capacities.length) continue;
    capacities.push(mediaControlCapacity(key, props, controls));
  }

  return capacities;
}

function mediaArrayCapacity(key, props, controls) {
  const countControl = mediaCountControlForArrayField(key, controls);
  const max = Number(countControl?.max);
  if (Number.isFinite(max) && max > 0) return max;
  return props[key].length || 1;
}

function mediaControlCapacity(key, props, controls) {
  const countControl = mediaCountControlForArrayField(key, controls);
  const max = Number(countControl?.max);
  if (Number.isFinite(max) && max > 0) return max;
  const value = props[key];
  return Array.isArray(value) ? Math.max(1, value.length) : 1;
}

function mediaCountControlForArrayField(key, controls = []) {
  const countControls = controls.filter(control => {
    const prop = control.prop || control.key;
    return prop && prop.endsWith('Count') && prop.toLowerCase().includes(key.replace(/s$/i, '').toLowerCase());
  });
  if (countControls.length) return countControls[0];
  const visualSlotControls = controls.filter(isVisualSlotCountControl);
  return visualSlotControls.length === 1 ? visualSlotControls[0] : null;
}

function isVisualSlotCountControl(control) {
  const type = String(control.type || '').toLowerCase();
  const key = String(control.prop || control.key || '');
  const text = `${key} ${control.label || ''} ${control.desc || control.description || ''}`;
  return /(count|数量)$/i.test(key)
    && ['number', 'range', 'slider'].includes(type)
    && /(frame|image|media|photo|picture|slot|gallery|画框|画格|图片|图像|媒体|照片|相册)/i.test(text);
}

function isMediaControl(control) {
  const type = String(control.type || '').toLowerCase();
  const key = String(control.prop || control.key || '').toLowerCase();
  const label = String(control.label || '').toLowerCase();
  if (['images', 'image', 'media', 'picture'].includes(type)) return true;
  if (isMediaArrayKey(key)) return true;
  return /图片|图像|视频|媒体/.test(label) && !/^show/.test(key);
}


function getPageCount(spec) {
  const value = Number(spec.pageCount ?? spec.pages ?? spec.slideCount);
  if (!Number.isFinite(value)) return 8;
  return Math.max(3, Math.min(30, Math.round(value)));
}

function defaultSlides({ title, goal, pageCount }) {
  const count = Math.max(3, pageCount);
  const middleCount = count - 2;
  const middle = DEFAULT_ROLE_SEQUENCE.slice(1, -1);
  const roles = ['cover'];
  for (let i = 0; i < middleCount; i += 1) roles.push(middle[i % middle.length]);
  roles.push('closing');
  return roles.map((role, index) => ({
    role,
    props: index === 0
      ? { titleLines: [title, goal].filter(Boolean).slice(0, 2) }
      : {},
  }));
}

function hashSeed(value) {
  let hash = 2166136261;
  for (let i = 0; i < value.length; i += 1) {
    hash ^= value.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  return hash >>> 0;
}
