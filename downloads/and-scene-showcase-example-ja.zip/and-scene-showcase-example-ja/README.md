# 同じ図を保って、説明を次の段階へ進める

一冊の本を、置く・見つける・戻すの8段階で移動させる。同じ図と要素IDを保つので、前の状態との関係を追える。

app/src/presentations/book-exchange/steps/ のpayloadとcaptionを編集。Scene.tsxは共通で使う。app/で npm ci、npm run build。原典 npm run verify と npm run inspect -- book-exchange を実行して表示を確認する。

原典verifyはWindowsのspawn EINVALで止まり、起動方法と既存ブラウザー選択だけの差分で実行した。build/全8段階のrenderとdesktop/narrow inspectは成功。狭い画面では固定canvas全体が小さくなる。独立レビューは別。

入力・原典・利用条件はinput/とPROVENANCE.json、現在の実施範囲はQA.json、元ソースと検査記録はsource/を参照。架空の作例を実績として使わない。作者QAと独立評価、人による採用を分ける。

## 使うための入力と現在の修復

対象の一覧・安定ID・対象同士の関係と、各段階の位置・表示状態・captionを用意します。交換本棚以外でも、同じ対象が段階を通って動く説明へ適用できます。図形は薄くしても、その役割名は判読できる濃さに残します。今回の6・8段階を含む全8段階を再描画しました。
