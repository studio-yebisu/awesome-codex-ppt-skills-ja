---
name: multiagent-ppt-ja
description: johnson7788/MultiAgentPPTの方式で日本語スライドを制作・再現する。原典固有の生成器・テンプレート・実装と個別条件を保ち、実制作例を参考に日本語の資料を作るときに使う。
---

# multiagent-ppt-ja

Studio Yebisuの日本語派生版。原作者の公式翻訳ではありません。

## 原典を読む



同梱references/WORKFLOW.mdで、実作例・入力・環境・コマンドと確認範囲を読む。

## 固有の制作方式

原典のstart_generate_presentationと同梱templateのAPI不要exportを実行する。実関数はdict入力を要求し、本文処理はsectionのindex1/2に限定。通常のmulti-agent、LLM、画像API経路の成功を示さない。shape IDの設定補正、Noto Sans JP・講稿・固定ラベルの局所化を記録する。

## 日本語で完成させる

- 先に読み手、目的、結論、必要なページ、出力形式を決める。
- 入力の出典と数値を確認し、万円・件・%・ポイントを区別する。架空条件と評価目標を実績に見せない。
- 日本語の見出しは意味の区切りで改行し、数字と単位が不自然に分かれないようにする。
- Webは必要文字を収録したOFL書体を埋め込む。PowerPointは受け手の書体環境と全ページの実描画を確認する。
- 原典の方式で実ファイルを生成し、全ページの本文、グラフ、図、ノート、移動を確認する。

## 再現と利用条件

完成例と再現キットはカタログの当該リポに掲載。環境と制約はreferences/WORKFLOW.mdに記載する。上流コードと書体の条件はupstream内の原文を保持し、カタログのCC0を上流へ適用しない。
