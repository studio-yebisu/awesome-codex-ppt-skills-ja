import type {SceneDef} from 'beatdeck';
export const SCENES:SceneDef[]=[
  {
    "id": "01",
    "title": "はじめる",
    "beats": [
      {
        "name": "待機画面",
        "auto": false,
        "ref": "reference/SCRIPT.md / 01 はじめる",
        "source": "架空のパン店の流れを、概念図で見てみよう。",
        "note": "待機画面からクリックで説明を始める。最初は工程の全体像だけを聞いてもらう。"
      },
      {
        "name": "パンが、店先に届くまで。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 01 はじめる",
        "source": "最初のクリックで話を始める。",
        "note": "パンが店先へ届く流れを示し、最初の素材の位置へ進む。"
      }
    ]
  },
  {
    "id": "02",
    "title": "素材",
    "beats": [
      {
        "name": "はじまりは、素材から。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 02 素材",
        "source": "はじまりは、素材から。",
        "note": "図の三つの印は原料名や個数のデータではなく素材の開始位置。次のクリックでつなぎ方を見る。"
      },
      {
        "name": "次の工程へ。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 02 素材",
        "source": "次の工程へ。",
        "note": "素材から次の工程へ矢印を出す。見出しと図が同時に変わったことを指す。"
      }
    ]
  },
  {
    "id": "03",
    "title": "生地",
    "beats": [
      {
        "name": "混ぜる。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 03 生地",
        "source": "素材から生地をつくる。",
        "note": "混ぜる場面では器と線で動作を示す。形を整える場面へ進む。"
      },
      {
        "name": "形づくる。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 03 生地",
        "source": "形づくる。",
        "note": "同じ生地を単独で見せる。次に台へ置いて焼く側へ渡す。"
      },
      {
        "name": "焼く場所へ。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 03 生地",
        "source": "次の工程へ渡す。",
        "note": "台と右向き矢印で、形を整えた生地の送り先を説明する。"
      }
    ]
  },
  {
    "id": "04",
    "title": "焼く",
    "beats": [
      {
        "name": "焼く。",
        "auto": true,
        "ref": "reference/SCRIPT.md / 04 焼く",
        "source": "焼く。条件・時間・温度は含めない。",
        "note": "色の変化は焼く工程を示す演出。実時間や温度を示す計測ではない。"
      },
      {
        "name": "パンとして、店先へ。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 04 焼く",
        "source": "パンとして、店先へ。",
        "note": "出口の矢印を指し、焼く工程から店先へ移る。"
      }
    ]
  },
  {
    "id": "05",
    "title": "店先",
    "beats": [
      {
        "name": "店先に、届く。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 05 店先",
        "source": "店先に、届く。",
        "note": "パンが棚へ届いたことを図の位置で示す。"
      },
      {
        "name": "並べて、見つけやすく。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 05 店先",
        "source": "並べて、見つけやすく。",
        "note": "棚の整列マークに注目し、置き方を整える話へ進む。"
      },
      {
        "name": "選ぶ時間へ。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 05 店先",
        "source": "選ぶ時間へ。",
        "note": "選ぶ対象を枠で示す。作る側から選ぶ側へ視点を切り替える。"
      }
    ]
  },
  {
    "id": "06",
    "title": "手渡す",
    "beats": [
      {
        "name": "選ぶ。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 06 手渡す",
        "source": "選ぶ。",
        "note": "棚を見て、どれを選ぶか考える場面。次に受け渡しを見る。"
      },
      {
        "name": "ひとつを、手渡す。",
        "auto": true,
        "ref": "reference/SCRIPT.md / 06 手渡す",
        "source": "ひとつを、手渡す。",
        "note": "右向き矢印と手元の枠で受け渡しを示す。最後の要点へ進む。"
      },
      {
        "name": "店先から、誰かの手へ。",
        "auto": false,
        "ref": "reference/SCRIPT.md / 06 手渡す",
        "source": "店先から、誰かの手へ。QRなし。",
        "note": "素材から手渡すまでを振り返る。詳しい製造条件はこの概念資料の対象外。"
      }
    ]
  }
];
