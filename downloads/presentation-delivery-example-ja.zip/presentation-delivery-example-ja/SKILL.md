---
name: presentation-delivery-ja
description: HTML deckを正本として視覚構成を作り、概覧とページ操作で読む。PPTXは必要な場合だけ4条件の範囲で派生し、内容と表示の違いを検査する。
---

# HTMLを正本にして資料を作る

原典はHTMLで高精細なプロトタイプ・スライド・アニメーション・可視化を制作する。スライドはHTML deckを正本にPDFを出し、依頼がある場合だけPPTXをbest-effort派生として出す。

原典のHTML-first Path Aで6頁を作り、4条件に合う要素を元DOM変換器でPPTXへ派生。HTMLとPPTXを並べて内容と表示差を確認する。

原典は [ConnorRX56/presentation-delivery-skills](https://github.com/ConnorRX56/presentation-delivery-skills/tree/06ddac077030c62f0118b225860cac46fbf658ea)、固定 commit `06ddac077030c62f0118b225860cac46fbf658ea`。日本語派生であり公式翻訳ではない。

## 用意するもの

- Python、Node22以上、固定Node依存とChromium。
- PPTX確認にはWindows / PowerPoint / PowerShellと公式BIZ UDPGothic。PDF由来RGBプレビューにはpypdfium2。

## 使い方

1. 読者・題材・資料の役割と出力形式を確認する。
2. HTML正本の見本と書式を確認してから残りを作る。
3. 必要な場合だけ4条件に合わせてPPTXを派生する。
4. HTMLとPPTXの実表示と内容を比較し、変換損失を明記する。

## この作例で確認する箇所

- **2頁・HTMLからの派生**：左のHTMLと右のPowerPointを比べ、3項目の本文が一段落の通常行間で読めるか確認。 4条件内のp/h要素を変換し、複数行の段落は外側DIVのdata-pptx-mergeで同じ編集枠へまとめる。
- **3頁・内容に合う図示**：上の例を用途・版・状態の3行へ分けたHTMLとPPTXを比較する。元の3列骨格を繰り返さない。 HTMLの視覚構成を正本にし、頁の役割へ図示を合わせる。対応する図形と本文を派生PPTXにも残す。
- **4頁・正本と派生を照合**：暗色の背景と2欄、本文の意味が両方で残るか確認。字幅や太さのpixel一致は主張しない。 HTMLを先に完成し、変換で保持できる内容と表現を確認する。PPTXはbest-effortとして損失を記録する。

## 適用範囲と未実施

- 原典visual-deck-studioはHTMLを正本とし、PPTXは依頼時のbest-effort派生。PPTXの制約のためにHTML設計を下げない。
- 今回の自律制作では早期の利用者承認と3方向Fallbackを実施していない。2頁showcaseは保持するが利用者の選択済みとは扱わない。
- HTTP入口・字体待ち・日本語ノート・Windows環境継承を局所adapterで補う。原典の寸法・overflow検査は維持。
- file URL、動画、音声/TTS、生産用Webアプリ・バックエンドはこの例の対象外。
- HTML全6頁の寸法・overflow・字体と、PPTX本文・全頁の実画像を確認。pixel一致・利用者採用・独立再評価は未完了。

全頁を制作側が実画像で確認した。修復版の独立再評価・利用者の採用は未完了。検査の内容・現在のPPTX hashは `QA.json`、原典の保持範囲と変更は `PROVENANCE.json` を参照する。

入力と現在の生成器を含む。再実行は [REPRODUCE.md](REPRODUCE.md) を参照する。
