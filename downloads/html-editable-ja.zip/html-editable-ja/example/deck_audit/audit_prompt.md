## 当前审查模式：page

严格逐页审查。忽略 contact sheet 的省 token 分流作用，按 page/detail 模板把所有目标页的 `slide_NN_compare.png` 分 batch 交给 sub-agent。适合最终交付前、客户高风险 deck、或用户明确要求最高覆盖率。

## Contact Sheets

- M:\Codex\Projects\studio-yebisu\workspace\slides\examples\repositories\html-editable-showcase\deck_audit\audit_contact_01_05.png  (pages 01-05)

# Visual Audit

视觉对比 HTML 参考图与 PPT 输出图。本文件专注 sub-agent 调用细节和 findings 格式；**完整工作流（修复纪律 / sticky 规则 / 增量重跑 / 终止条件）见 SKILL.md "工作流" 与 "修复纪律" 章节**。

起手：读 `audit_index.json` 拿页清单、`audit_mode`、`contact_sheets`。`incremental_mode=true` 时只看 `fresh_indices` 列出的页。

## page/detail 审查执行

适用范围：`page` 模式所有目标页、`triage` 模式第 2 轮入围页（`manual` 模式不进入本节）。在适用范围内即使本批只有 1 页也走 sub-agent。

按 SKILL.md "audit 分发与 compare 图读取规则" 章节的页数策略拆 batch。Page/detail sub-agent 调用模板（Claude `Agent(...)` 风格；每个 Agent 一个 batch，全部塞在主 agent 同一条 message 里才并行）：

```
Agent(
  description="Audit slides N1-N2",
  subagent_type="general-purpose",
  run_in_background=True,
  prompt='''你是视觉审计员。看以下这批 compare 图（左=HTML 参考，右=PPT 输出），按顺序逐张应用检查清单。

本批图（每张是一页）：
- <full path to slide_N1_compare.png>
- <full path to slide_N2_compare.png>
- <full path to slide_N3_compare.png>
- <full path to slide_N4_compare.png>

可读参考（只读，不编辑；不要假设主 agent 的 Read/Grep 输出会自动传给你）：
- deck HTML: <full path to template.audited.html or template.html>
- lessons learned: <skill_dir>/references/lessons-learned.md

仅审本批 compare 图，不要读其它页的 compare 图，不要改代码/HTML。只有当定位同一页元素需要时，才只读上面的 HTML / lessons 文件。

**默认 OK 偏置（最重要）**

这是 HTML → PPT 视觉转换审计，不是 pixel-perfect 还原审计。OOXML / PowerPoint / 浏览器之间必然有底层差异（字体 hinting、anti-aliasing、sub-pixel positioning、装饰栅格化、行宽细微差异），**这些不是转换 bug，不要报告**。

期望基线：大多数 deck 的**多数页**应该 `## page NN · OK`。如果你这批 4 页里有 ≥ 3 页有 MID/HIGH finding，几乎一定是你在过度解读细节——停下来重审，把"细看才发现"的全部删掉再交。

**不报告清单（HTML→PPT 自然差异 + 设计偏好，永不报告）**

下面这些是渲染底层自然差异或主观偏好，**永不报告**（哪怕降级到 LOW 也别报）：
- 字体 anti-aliasing / hinting / 字偶距 / 锯齿边 / sub-pixel 渲染差异
- 位置漂移 < 5 px / 装饰线条 / 边框相差几像素（形状、层级、视觉含义一致前提下）
- 字号 / 字距 / 行高 / 字重差异 < 10%（不同字体度量不同，10% 是正常容差）
- 字体 weight 看着略不同但字形一致
- 颜色饱和度 / 色温微差（同色系内）
- 文字行宽多换 1 行 / 标题换行位置不同（除非真溢出 slide 或真叠压邻元素）
- 装饰阴影 / blur / 柔和度的轻微差异
- 上标 / 下标 / 标点的基线漂移 < 5 px
- HTML 半图本身已模糊 / 挤压 / 重叠 / 看不清的区域
- 用"略粗 / 略细 / 略松 / 略紧 / 略偏"形容的无锚定差异
- 设计偏好（"我觉得这里更应该居中 / 更应该大一点"）

**看图须知（避免常见误判）**：
- 每张图是**左右拼图**：左半 = HTML 参考渲染，右半 = PPT 输出，两半之间有窄分隔留白
- 顶部标题栏（"HTML 参考 / PPT 输出 / slide NN"）和中间灰色分隔线是审计 UI，**不是 slide 内容**，不要报告这些区域的问题
- 判断居中 / 对齐 / 偏移**只看每一半内部**的相对位置——不要跨左右半比较 x 坐标
- 同理判断字号 / 间距 / 段宽时，只比"HTML 半图里的元素 vs PPT 半图里**同一**元素"
- 只报告 PPT 半图相对 HTML 半图**新增或放大**的视觉问题；HTML 半图本身已有的问题不算转换 finding
- **报 finding 前必须先看 HTML 半图、描述它的实际像素态**（颜色 / 填充 / 形状 / 位置），再讲 PPT 半图差异。写不出 HTML 半图实际像素 = 没看清 = 不报。不要靠"HTML 应该是 X 因为它叫 .filled / 命名暗示 X"脑补。

**严重度阈值**（不允许"显著 / 明显 / 大幅 / 略小"等模糊词单独构成级别）

- **HIGH**（用户瞄一眼就能看出来，必须修）：
  - 关键元素缺失或被错误形状 / 错误颜色取代
  - 文字被遮盖、裁切、溢出 slide，或压住其它正文
  - 字号 / 尺寸差 ≥ 50%
  - 颜色跨明暗关系或跨色相，影响阅读 / 含义

- **MID**（细看 5 秒能确认，**且必须能量化**）：
  - 字号 / 尺寸差 20-50%
  - 位置差 20-50 px
  - 颜色明显偏移但仍同色系
  - HTML 不叠压而 PPT 产生文字 / 元素叠压

- **LOW**（设计师 nice-to-have，可选；多数情况下应**不报**）：
  - 量化差异 10-20%，且确实影响局部观感
  - 不确定 LOW 还是不报时，**选不报**

检查清单（按重要度排序）：
1. 文字被线条 / 形状边界 / 图片角穿过 / 覆盖
2. 文字之间不该有的重叠 / 叠压（HTML 不叠压前提下）
3. 文字溢出 slide 边界 / 被裁切 / 溢入相邻列
4. 元素相对 HTML 参考图大幅错位（≥ 20 px）
5. 字体回退到完全不同的字形家族（如 serif → 等宽 / 衬线 → 无衬线）
6. 图片拉伸 / 错位 / 缺失，装饰色块变形
7. 颜色错误（取反 / 跨色系）

输出**纯文本**（不要 markdown code fence 包装）：为本批每一页输出一个块，严格用以下格式：

有问题的页：
## page NN
- [HIGH] <稳定元素短名>：HTML 半图 <实际状态>；PPT 半图 <差异 + 量化>
- [MID]  <稳定元素短名>：HTML 半图 <实际状态>；PPT 半图 <差异 + 量化>

无问题的页：
## page NN · OK

每条 finding 必须点名稳定元素短名，方便主 agent 做 sticky key；不要写原因猜测、修复方案或总结。

**输出前自检（必须）**

写好 findings 后，对每一条问自己 5 题（任一不过都删）：
1. 全页可见、且影响阅读 / 含义 / 布局？看不出 / 不影响 → 删
2. 落入上方"不报告清单"？是 → 删
3. HIGH：普通观众瞄一眼能看出？不能 → 降到 MID 或删
4. MID：细看 5 秒能确认且能量化 20-50%？不能 → 删
5. HTML 半图实际像素状态写清楚了吗（颜色 / 填充 / 形状 / 位置）？没有 → 可能在脑补 → 删

批量 sanity check：每个 batch 通常 0-2 条 finding。超过 3 条 → 先假设自己过度审查，合并同类项并删掉所有不影响阅读 / 结构 / 含义的细节。'''
)
```

sub-agent 只返回 findings 文本，**不要让它直接写 audit_findings.md**——并发写会互相覆盖，主 agent 收齐后统一合并。

同一条 message 里跟着发并行准备：

```
Read(file_path="<deck>/template.html")
Read(file_path="<skill_dir>/references/lessons-learned.md")
Grep(pattern='class="slide |data-slide=', path="<deck>/template.html",
     output_mode="content", -n=true)
```

只发"无论 findings 是什么都用得上"的准备，不要预测 findings 提前改 HTML。详见 SKILL.md "与 sub-agent 并行的主 agent 准备"。

findings 格式与级别口径见上方 sub-agent prompt 模板（"严重度阈值" + "输出前自检"）。
