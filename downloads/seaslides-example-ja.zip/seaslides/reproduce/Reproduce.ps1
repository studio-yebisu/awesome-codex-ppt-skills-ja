param([switch]$Render)
$ErrorActionPreference = "Stop"
$taskRoot = Join-Path $PSScriptRoot "workspace"
Push-Location -LiteralPath $taskRoot
try {
    & python -m venv .build/ppt-master-venv
    if ($LASTEXITCODE) { throw "Python environment failed" }
    $taskPy = Join-Path $taskRoot ".build/ppt-master-venv/Scripts/python.exe"
    & $taskPy -m pip install -r requirements-reproduce.txt
    if ($LASTEXITCODE) { throw "Python dependencies failed" }
    $taskFont = Join-Path $taskRoot ".build/fonts/NotoSansJP[wght].ttf"
    if (-not (Test-Path -LiteralPath $taskFont)) {
        New-Item -ItemType Directory -Path (Split-Path $taskFont) -Force | Out-Null
        Invoke-WebRequest -Uri "https://raw.githubusercontent.com/google/fonts/66928797f271fed5ee428544e7229685e2d90127/ofl/notosansjp/NotoSansJP%5Bwght%5D.ttf" -OutFile $taskFont
    }
    if ((Get-FileHash -LiteralPath $taskFont -Algorithm SHA256).Hash.ToLower() -ne "c2f3b4d463500a2ddcd3849cded1fceeb9fd6d1c32e6cbecd568453ba50fc68f") { throw "Pinned font hash mismatch" }
    $taskRenderer = ".build/actual-upstreams/touying-typ__seaslides/skills/seaslides-html-slides-skill/scripts/html_to_svg"
    & npm --prefix $taskRenderer ci --ignore-scripts
    if ($LASTEXITCODE) { throw "SeaSlides renderer dependencies failed" }
    & npm --prefix $taskRenderer exec -- playwright install chromium --only-shell
    if ($LASTEXITCODE) { throw "SeaSlides browser setup failed" }
    & $taskPy tools/build_seaslides_repository_example.py 
    if ($LASTEXITCODE) { throw "Generation failed" }
    & $taskPy tools/mark_reproduced.py
    Write-Host "Generated: $taskRoot/examples/repositories/seaslides"
    Write-Host "Open the actual output and review all pages before using it."
} finally { Pop-Location }
