# 制作依頼

LearnAIHubC/LearnDeckの原典HTML-to-PPT方式を実行して、架空の花の定期便サービス「花を、一本から。」を5枚の編集可能PPTXにしてください。日本語HTMLのDOM位置を原典html_to_ppt.js/html_to_editable_pptx.jsで実測し、文字と背景/図形をnative object、花のSVGを個別画像として組み立てる。紙色・強い朱赤・墨黒、巨大な文字、一輪と花束を大胆に置く。表紙の短い日本語はDela Gothic One、余韻のある見出しはShippori Mincho、本文はBIZ UDPGothic。角丸カード反復を避け、ページごとに見出しの位置と構図を変える。価格/実績を捏造せず、提供案と未確定事項を短く明示。原典の--no-previewで余分なQAを省略し、PowerPointで一度PNG/PDFを書き出して主な完成物を初回表示。SVG元・原典MIT・実TTF/OFLを保全。元converterの単一フォント制約を局所的にcomputed font-familyへ拡張した場合は差分を記録する。
