from pathlib import Path
import json, hashlib
p=Path('examples/repositories/pradaslides')
artifact=p/'output/deck.pptx'
(p/'QA.json').write_text(json.dumps({'status':'generated_awaiting_review','artifact_sha256':hashlib.sha256(artifact.read_bytes()).hexdigest(),'visual_review':'Review your reproduced output; the original catalog QA is not transferred to a new run.'},ensure_ascii=False,indent=2),encoding='utf-8')
