param([switch]$Render, [string]$NodePath="")
$ErrorActionPreference = "Stop"
$taskRoot = Join-Path $PSScriptRoot "workspace"
Push-Location -LiteralPath $taskRoot
try {
    & python -m venv .build/ppt-master-venv
    if ($LASTEXITCODE) { throw "Python environment failed" }
    $taskPy = Join-Path $taskRoot ".build/ppt-master-venv/Scripts/python.exe"
    & $taskPy -m pip install -r requirements-reproduce.txt
    if ($LASTEXITCODE) { throw "Python dependencies failed" }
    & $taskPy examples/repositories/pradaslides/source/reproduce.py
    if ($LASTEXITCODE) { throw "PradaSlides generation failed" }
    if ($Render) {
        $taskArgs = @()
        if ($NodePath) { $taskArgs += @("--node",$NodePath) }
        & $taskPy examples/repositories/pradaslides/source/qa.py @taskArgs
    }
    if ($LASTEXITCODE) { throw "Generation failed" }
    & $taskPy tools/mark_reproduced.py
    Write-Host "Generated: $taskRoot/examples/repositories/pradaslides"
    Write-Host "Open the actual output and review all pages before using it."
} finally { Pop-Location }
