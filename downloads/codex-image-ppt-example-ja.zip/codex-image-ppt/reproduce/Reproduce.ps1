param([switch]$Render)
$ErrorActionPreference = "Stop"
$taskRoot = Join-Path $PSScriptRoot "workspace"
Push-Location -LiteralPath $taskRoot
try {
    & python -m venv .build/ppt-master-venv
    if ($LASTEXITCODE) { throw "Python environment failed" }
    $taskPy = Join-Path $taskRoot ".build/ppt-master-venv/Scripts/python.exe"
    & $taskPy -m pip install -r requirements-reproduce.txt
    if ($LASTEXITCODE) { throw "Python dependencies failed" }
    & $taskPy tools/build_codex_image_repository_example.py assemble
    if ($Render) { & pwsh -NoProfile -File tools/render_powerpoint.ps1 -PresentationPath examples/repositories/codex-image-ppt/codex-image-ppt.pptx -OutputDirectory examples/repositories/codex-image-ppt/render }
    if ($LASTEXITCODE) { throw "Generation failed" }
    & $taskPy tools/mark_reproduced.py
    Write-Host "Generated: $taskRoot/examples/repositories/codex-image-ppt"
    Write-Host "Open the actual output and review all pages before using it."
} finally { Pop-Location }
