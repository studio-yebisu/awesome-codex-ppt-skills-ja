param([switch]$Render)
$ErrorActionPreference = "Stop"
$taskRoot = Join-Path $PSScriptRoot "workspace"
Push-Location -LiteralPath $taskRoot
try {
    & python -m venv .build/ppt-master-venv
    if ($LASTEXITCODE) { throw "Python environment failed" }
    $taskPy = Join-Path $taskRoot ".build/ppt-master-venv/Scripts/python.exe"
    & $taskPy -m pip install -r requirements-reproduce.txt
    if ($LASTEXITCODE) { throw "Python dependencies failed" }
    $taskArgs = @("--input","examples/repositories/hands-on-deck/input/data.json")
    if ($Render) { $taskArgs += "--render" }
    & $taskPy examples/repositories/hands-on-deck/source/reproduce.py @taskArgs
    if ($LASTEXITCODE) { throw "Generation failed" }
    & $taskPy tools/mark_reproduced.py
    Write-Host "Generated: $taskRoot/examples/repositories/hands-on-deck"
    Write-Host "Open the actual output and review all pages before using it."
} finally { Pop-Location }
